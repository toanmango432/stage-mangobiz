import React from 'react';
import { SalonCenter } from './components/SalonCenter';
export function App() {
  return <div className="w-full h-screen bg-gray-50">
      <SalonCenter />
    </div>;
}