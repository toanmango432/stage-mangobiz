import React, { useEffect, useState, useRef } from 'react';
import Tippy from '@tippyjs/react';
import 'tippy.js/dist/tippy.css';
import { MoreVertical, Search, Filter, Maximize2, ChevronRight, Check, Users, LayoutGrid, Layers, Sparkles, UserCircle, Clock, ChevronUp, ChevronDown } from 'lucide-react';
import { StaffCard } from './StaffCard';
export function StaffSidebar() {
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearch, setShowSearch] = useState(false);
  const [statusFilter, setStatusFilter] = useState<string | null>(null);
  // Initialize view mode from localStorage, default to 'normal'
  const [viewMode, setViewMode] = useState<'normal' | 'compact'>(() => {
    const saved = localStorage.getItem('staffSidebarViewMode');
    return saved === 'normal' || saved === 'compact' ? saved as 'normal' | 'compact' : 'normal';
  });
  const [showMoreOptions, setShowMoreOptions] = useState(false);
  // Initialize sidebar width from localStorage to ensure persistence
  const [sidebarWidth, setSidebarWidth] = useState(() => {
    const savedWidth = localStorage.getItem('staffSidebarWidth');
    return savedWidth ? parseInt(savedWidth) : 256; // Default width in pixels
  });
  // Initialize width type from localStorage
  const [widthType, setWidthType] = useState(() => {
    const savedWidthType = localStorage.getItem('staffSidebarWidthType');
    return savedWidthType || 'fixed'; // Default to 'fixed'
  });
  // Initialize width percentage from localStorage
  const [widthPercentage, setWidthPercentage] = useState(() => {
    const savedPercentage = localStorage.getItem('staffSidebarWidthPercentage');
    return savedPercentage ? parseInt(savedPercentage) : 0;
  });
  // Add states for custom width popup and temporary width preview
  const [showCustomWidthPopup, setShowCustomWidthPopup] = useState(false);
  const [customWidthInput, setCustomWidthInput] = useState('');
  // Add states to store the original width values before preview
  const [originalWidth, setOriginalWidth] = useState(0);
  const [originalWidthType, setOriginalWidthType] = useState('');
  const [originalWidthPercentage, setOriginalWidthPercentage] = useState(0);
  const [isPreviewMode, setIsPreviewMode] = useState(false);
  const moreOptionsRef = useRef<HTMLDivElement>(null);
  const customWidthPopupRef = useRef<HTMLDivElement>(null);
  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (moreOptionsRef.current && !moreOptionsRef.current.contains(event.target as Node)) {
        setShowMoreOptions(false);
      }
      if (customWidthPopupRef.current && !customWidthPopupRef.current.contains(event.target as Node) && showCustomWidthPopup) {
        // Restore original width if clicking outside while in preview mode
        if (isPreviewMode) {
          restoreOriginalWidth();
        }
        setShowCustomWidthPopup(false);
        setIsPreviewMode(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showCustomWidthPopup, isPreviewMode]);
  // Update width when window is resized (for percentage-based widths)
  useEffect(() => {
    const handleResize = () => {
      if (widthType === 'percentage' || widthType === 'customPercentage') {
        const windowWidth = window.innerWidth;
        const newWidth = Math.round(windowWidth * widthPercentage / 100);
        setSidebarWidth(newWidth);
      }
    };
    window.addEventListener('resize', handleResize);
    handleResize(); // Call once to set initial width
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, [widthType, widthPercentage]);
  // Save sidebar width settings to localStorage when they change
  useEffect(() => {
    // Only save to localStorage if not in preview mode
    if (!isPreviewMode) {
      localStorage.setItem('staffSidebarWidth', sidebarWidth.toString());
      localStorage.setItem('staffSidebarWidthType', widthType);
      localStorage.setItem('staffSidebarWidthPercentage', widthPercentage.toString());
    }
  }, [sidebarWidth, widthType, widthPercentage, isPreviewMode]);
  // Determine if sidebar is in expanded view (40%, 50% or 100% width)
  const isExpandedView = widthType === 'percentage' && (widthPercentage === 40 || widthPercentage === 50 || widthPercentage === 100);
  // Fixed width options
  const fixedSizeOptions = [{
    label: 'Ultra Compact (100px)',
    value: 100,
    description: 'Icons-only view with minimal text'
  }, {
    label: 'Compact (300px)',
    value: 300,
    description: 'Standard view with names and basic details'
  }];
  // Percentage width options
  const percentageSizeOptions = [{
    label: 'Wide',
    value: 40,
    description: 'Expanded view using 40% of screen width'
  }, {
    label: 'Full Screen',
    value: 100,
    description: 'Maximum width using entire screen'
  }];
  // Handle setting percentage-based width
  const handleSetPercentageWidth = (percentage: number) => {
    const windowWidth = window.innerWidth;
    const newWidth = Math.round(windowWidth * percentage / 100);
    setWidthType('percentage');
    setWidthPercentage(percentage);
    setSidebarWidth(newWidth);
    setShowMoreOptions(false);
    // Save to localStorage
    localStorage.setItem('staffSidebarWidthType', 'percentage');
    localStorage.setItem('staffSidebarWidthPercentage', percentage.toString());
    localStorage.setItem('staffSidebarWidth', newWidth.toString());
  };
  // Handle setting fixed width
  const handleSetFixedWidth = (width: number) => {
    setWidthType('fixed');
    setWidthPercentage(0);
    setSidebarWidth(width);
    setShowMoreOptions(false);
    // Save to localStorage
    localStorage.setItem('staffSidebarWidthType', 'fixed');
    localStorage.setItem('staffSidebarWidth', width.toString());
    localStorage.setItem('staffSidebarWidthPercentage', '0');
  };
  // Save the original width before previewing
  const saveOriginalWidth = () => {
    setOriginalWidth(sidebarWidth);
    setOriginalWidthType(widthType);
    setOriginalWidthPercentage(widthPercentage);
  };
  // Restore the original width when cancelling
  const restoreOriginalWidth = () => {
    setSidebarWidth(originalWidth);
    setWidthType(originalWidthType);
    setWidthPercentage(originalWidthPercentage);
  };
  // Preview custom width percentage without saving
  const previewCustomPercentageWidth = (percentage: number) => {
    if (percentage >= 10 && percentage <= 100) {
      const windowWidth = window.innerWidth;
      const newWidth = Math.round(windowWidth * percentage / 100);
      // Set the width preview
      setSidebarWidth(newWidth);
      setWidthType('customPercentage');
      setWidthPercentage(percentage);
      // Mark as preview mode
      setIsPreviewMode(true);
    }
  };
  // Handle custom width percentage setting
  const handleSetCustomPercentageWidth = (percentage: number) => {
    if (percentage >= 10 && percentage <= 100) {
      const windowWidth = window.innerWidth;
      const newWidth = Math.round(windowWidth * percentage / 100);
      // Apply the width
      setWidthType('customPercentage');
      setWidthPercentage(percentage);
      setSidebarWidth(newWidth);
      setIsPreviewMode(false);
      setShowCustomWidthPopup(false);
      // Save to localStorage
      localStorage.setItem('staffSidebarWidthType', 'customPercentage');
      localStorage.setItem('staffSidebarWidthPercentage', percentage.toString());
      localStorage.setItem('staffSidebarWidth', newWidth.toString());
    }
  };
  // Toggle between view modes (normal, compact)
  const toggleViewMode = () => {
    const newViewMode = viewMode === 'normal' ? 'compact' : 'normal';
    setViewMode(newViewMode);
    // Save the selection to localStorage
    localStorage.setItem('staffSidebarViewMode', newViewMode);
  };
  // Determine number of grid columns based on sidebar width and view mode
  const getGridColumns = () => {
    // Special case for ultra compact width
    if (sidebarWidth <= 100) {
      return 'grid-cols-1';
    }
    // Check if using percentage-based width (either preset or custom)
    const isPercentageBased = widthType === 'percentage' || widthType === 'customPercentage';
    if (viewMode === 'compact') {
      if (isPercentageBased) {
        // More columns for expanded view based on percentage width
        if (widthPercentage >= 90) {
          return 'grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6';
        } else if (widthPercentage >= 40) {
          return 'grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4';
        }
        return 'grid-cols-1 sm:grid-cols-2 md:grid-cols-3';
      }
      // Fixed width compact view
      if (sidebarWidth >= 400) {
        return 'grid-cols-2';
      }
      return 'grid-cols-1';
    } else {
      // Normal view
      if (isPercentageBased) {
        if (widthPercentage >= 90) {
          return 'grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5';
        } else if (widthPercentage >= 40) {
          return 'grid-cols-1 sm:grid-cols-2 md:grid-cols-3';
        }
        return 'grid-cols-1 sm:grid-cols-2';
      }
      return 'grid-cols-1';
    }
  };
  // Get the gap and padding based on view mode
  const getGapAndPadding = () => {
    if (viewMode === 'compact') {
      if (sidebarWidth <= 100) {
        return 'gap-0.5 p-0.5';
      } else if (sidebarWidth <= 300) {
        return 'gap-1 p-1.5';
      } else {
        return 'gap-2 p-2';
      }
    } else {
      // For normal view, use responsive gaps based on sidebar width
      if (sidebarWidth <= 300) {
        return 'gap-1.5 p-2';
      } else {
        return 'gap-2 p-3';
      }
    }
  };
  // Get the appropriate view mode icon
  const getViewModeIcon = () => {
    if (viewMode === 'normal') {
      return <ChevronUp size={16} />;
    } else {
      return <ChevronDown size={16} />;
    }
  };
  // Get the appropriate view mode label
  const getViewModeLabel = () => {
    if (viewMode === 'normal') {
      return 'Switch to compact view';
    } else {
      return 'Switch to normal view';
    }
  };
  // Get the appropriate card view mode based on sidebar width and user preference
  const getCardViewMode = (): 'ultra-compact' | 'compact' | 'normal' => {
    if (sidebarWidth <= 100) {
      return 'ultra-compact';
    }
    return viewMode;
  };
  // Calculate display priority tiers based on available width
  const getDisplayPriorityTiers = () => {
    // Base tier settings
    const tier1 = true; // Always show: Staff Name, Queue Order, Avatar
    let tier2 = false; // Turn Count
    let tier3 = false; // Status
    let tier4 = false; // Clocked In Time
    let tier5 = false; // Next Appointment
    let tier6 = false; // Service Amount
    let tier7 = false; // Tickets
    let tier8 = false; // Last Done Time
    // Determine which tiers to display based on width and view mode
    const cardMode = getCardViewMode();
    if (cardMode === 'ultra-compact') {
      // Ultra compact shows only tier 1
      return {
        tier1,
        tier2,
        tier3,
        tier4,
        tier5,
        tier6,
        tier7,
        tier8
      };
    }
    if (cardMode === 'compact') {
      tier2 = true; // Always show Turn Count in compact
      if (sidebarWidth >= 220) {
        tier3 = true; // Show Status
      }
      if (sidebarWidth >= 260) {
        tier6 = true; // Show Service Amount
      }
      if (sidebarWidth >= 300) {
        tier4 = true; // Show Clocked In Time
        tier7 = true; // Show Tickets
      }
      if (sidebarWidth >= 340) {
        tier5 = true; // Show Next Appointment
      }
      if (sidebarWidth >= 380) {
        tier8 = true; // Show Last Done Time
      }
    } else {
      // Normal mode
      tier2 = true; // Always show Turn Count
      tier3 = true; // Always show Status
      if (sidebarWidth >= 180) {
        tier6 = true; // Show Service Amount
      }
      if (sidebarWidth >= 220) {
        tier4 = true; // Show Clocked In Time
        tier7 = true; // Show Tickets
      }
      if (sidebarWidth >= 260) {
        tier5 = true; // Show Next Appointment
      }
      if (sidebarWidth >= 300) {
        tier8 = true; // Show Last Done Time
      }
    }
    return {
      tier1,
      tier2,
      tier3,
      tier4,
      tier5,
      tier6,
      tier7,
      tier8
    };
  };
  const staffStatus = [{
    id: 'tech',
    label: 'Tech',
    shortLabel: 'T',
    count: 13
  }, {
    id: 'ready',
    label: 'Ready',
    shortLabel: 'R',
    count: 9
  }, {
    id: 'busy',
    label: 'Busy',
    shortLabel: 'B',
    count: 4
  }];
  const staffMembers = [{
    id: 1,
    name: 'JENNY',
    shortName: 'JEN',
    time: '05:58:24 AM',
    image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&q=80',
    status: 'busy',
    color: 'bg-[#9B5DE5]',
    count: 1,
    revenue: null,
    nextAppointmentTime: '10:15 AM',
    nextAppointmentEta: '2h 17m',
    lastServiceTime: '08:30 AM',
    lastServiceAgo: '27m ago',
    turnCount: 4,
    ticketsServicedCount: 5,
    totalSalesAmount: 347,
    specialty: 'hair'
  }, {
    id: 2,
    name: 'TIM',
    shortName: 'TIM',
    time: '05:58:27 AM',
    image: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&q=80',
    status: 'ready',
    color: 'bg-white',
    count: 9,
    revenue: null,
    nextAppointmentTime: '09:45 AM',
    nextAppointmentEta: '1h 47m',
    lastServiceTime: '07:15 AM',
    lastServiceAgo: '1h 42m ago',
    turnCount: 7,
    ticketsServicedCount: 12,
    totalSalesAmount: 892,
    specialty: 'massage'
  }, {
    id: 3,
    name: 'JULIE',
    shortName: 'JUL',
    time: '05:58:25 AM',
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&q=80',
    status: 'busy',
    color: 'bg-[#E5565B]',
    count: 13,
    revenue: {
      transactions: 1,
      tickets: 1,
      amount: 72.1
    },
    nextAppointmentTime: '11:00 AM',
    nextAppointmentEta: '3h 2m',
    lastServiceTime: '09:10 AM',
    lastServiceAgo: 'Just now',
    turnCount: 2,
    ticketsServicedCount: 3,
    totalSalesAmount: 215,
    specialty: 'nails'
  }, {
    id: 4,
    name: 'KEVIN',
    shortName: 'KEV',
    time: '05:58:25 AM',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&q=80',
    status: 'busy',
    color: 'bg-[#3F83F8]',
    count: 3,
    revenue: null,
    specialty: 'waxing'
  }, {
    id: 6,
    name: 'SEAN',
    shortName: 'SEA',
    time: '05:58:26 AM',
    image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&q=80',
    status: 'busy',
    color: 'bg-[#9B5DE5]',
    count: 6,
    revenue: null,
    specialty: 'combo'
  }, {
    id: 8,
    name: 'THOR',
    shortName: 'THR',
    time: '05:58:27 AM',
    image: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&q=80',
    status: 'busy',
    color: 'bg-[#3C78D8]',
    count: 8,
    revenue: null,
    specialty: 'hair'
  }, {
    id: 9,
    name: 'JIM',
    shortName: 'JIM',
    time: '05:58:25 AM',
    image: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&q=80',
    status: 'busy',
    color: 'bg-[#4CC2A9]',
    count: 12,
    revenue: {
      transactions: 1,
      tickets: 1,
      amount: 41.2
    },
    specialty: 'nails'
  }, {
    id: 10,
    name: 'SARAH',
    shortName: 'SAR',
    time: '06:12:33 AM',
    image: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&q=80',
    status: 'ready',
    color: 'bg-[#4CC2A9]',
    count: 2,
    revenue: {
      transactions: 3,
      tickets: 3,
      amount: 189.5
    },
    nextAppointmentTime: '09:30 AM',
    nextAppointmentEta: '1h 32m',
    lastServiceTime: '08:15 AM',
    lastServiceAgo: '42m ago',
    turnCount: 8,
    ticketsServicedCount: 10,
    totalSalesAmount: 854,
    specialty: 'skincare'
  }, {
    id: 11,
    name: 'MIKE',
    shortName: 'MIK',
    time: '06:02:18 AM',
    image: 'https://images.unsplash.com/photo-1552374196-c4e7ffc6e126?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&q=80',
    status: 'off',
    color: 'bg-white',
    count: 0,
    revenue: null,
    specialty: 'massage'
  }, {
    id: 12,
    name: 'LISA',
    shortName: 'LIS',
    time: '06:05:42 AM',
    image: 'https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&q=80',
    status: 'ready',
    color: 'bg-[#E5565B]',
    count: 5,
    revenue: {
      transactions: 2,
      tickets: 2,
      amount: 128.75
    },
    nextAppointmentTime: '10:00 AM',
    nextAppointmentEta: '2h 2m',
    lastServiceTime: '08:50 AM',
    lastServiceAgo: '7m ago',
    turnCount: 9,
    ticketsServicedCount: 11,
    totalSalesAmount: 942,
    specialty: 'waxing'
  }, {
    id: 13,
    name: 'ALEX',
    shortName: 'ALX',
    time: '06:10:15 AM',
    image: 'https://images.unsplash.com/photo-1543610892-0b1f7e6d8ac1?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&q=80',
    status: 'busy',
    color: 'bg-[#3F83F8]',
    count: 7,
    revenue: null,
    lastServiceTime: '09:05 AM',
    lastServiceAgo: '5m ago',
    turnCount: 3,
    ticketsServicedCount: 4,
    totalSalesAmount: 275,
    specialty: 'combo'
  }, {
    id: 14,
    name: 'EMMA',
    shortName: 'EMM',
    time: '05:58:30 AM',
    image: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&q=80',
    status: 'ready',
    color: 'bg-[#9B5DE5]',
    count: 4,
    revenue: {
      transactions: 4,
      tickets: 4,
      amount: 215.2
    },
    nextAppointmentTime: '09:15 AM',
    nextAppointmentEta: '1h 17m',
    turnCount: 12,
    ticketsServicedCount: 15,
    totalSalesAmount: 1250,
    specialty: 'neutral'
  }, {
    id: 15,
    name: 'DAVID',
    shortName: 'DAV',
    time: '06:15:10 AM',
    image: 'https://images.unsplash.com/photo-1504257432389-52343af06ae3?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&q=80',
    status: 'off',
    color: 'bg-[#3C78D8]',
    count: 0,
    revenue: null,
    specialty: 'support'
  }];
  const filteredStaff = staffMembers.filter(staff => staff.name.toLowerCase().includes(searchQuery.toLowerCase()) && (statusFilter === null || staff.status === statusFilter)).sort((a, b) => {
    // Sort by status first (ready first, then busy)
    if (a.status !== b.status) {
      return a.status === 'ready' ? -1 : 1;
    }
    // Then sort by name
    return a.name.localeCompare(b.name);
  });
  // Render header based on view mode and width
  const renderHeader = () => {
    // Ultra compact header for narrow width
    if (sidebarWidth <= 100) {
      return <div className="p-1.5 border-b border-[#E2D9DC] bg-gradient-to-r from-[#EDE5E9] to-[#E5DDE1] shadow-md">
          <div className="flex flex-col space-y-1.5">
            <div className="flex items-center justify-between">
              <div className="bg-[#3BB09A] text-white text-xs px-2 py-0.5 rounded-md font-medium shadow-sm">
                Team
              </div>
              <div className="relative" ref={moreOptionsRef}>
                <Tippy content="More options">
                  <button className="p-0.5 rounded-md bg-white hover:bg-gray-50 text-gray-600 shadow-sm transition-colors" onClick={() => setShowMoreOptions(!showMoreOptions)}>
                    <MoreVertical size={12} />
                  </button>
                </Tippy>
                {showMoreOptions && renderOptionsDropdown()}
              </div>
            </div>
            <div className="w-full">
              <div className="flex flex-col space-y-1 w-full">
                <button onClick={() => setStatusFilter(null)} className={`flex items-center space-x-1 p-1 rounded-full transition-colors w-full ${statusFilter === null ? 'bg-blue-600 shadow-sm border border-blue-700 text-white' : 'bg-white hover:bg-blue-50 text-gray-700 border border-gray-200'}`} aria-label="Show all staff">
                  <div className={`w-1.5 h-1.5 ${statusFilter === null ? 'bg-white' : 'bg-blue-500'} rounded-full`}></div>
                  <span className={`text-[10px] ${statusFilter === null ? 'font-bold' : 'font-medium'}`}>
                    All:
                  </span>
                  <div className={`${statusFilter === null ? 'bg-blue-500 text-white' : 'bg-blue-50 text-blue-700'} text-[10px] px-1.5 py-0.5 rounded-full font-semibold`}>
                    13
                  </div>
                </button>
                <div className="flex space-x-1 w-full">
                  <button onClick={() => setStatusFilter('ready')} className={`flex flex-1 items-center justify-center space-x-1 p-1 rounded-full transition-colors ${statusFilter === 'ready' ? 'bg-green-600 shadow-sm border border-green-700 text-white' : 'bg-white hover:bg-green-50 text-gray-700 border border-gray-200'}`} aria-label="Filter by Ready status">
                    <span className={`text-[10px] ${statusFilter === 'ready' ? 'font-bold' : 'font-medium'}`}>
                      R:
                    </span>
                    <div className={`${statusFilter === 'ready' ? 'bg-green-500 text-white' : 'bg-green-50 text-green-700'} text-[10px] px-1.5 py-0.5 rounded-full font-semibold`}>
                      9
                    </div>
                  </button>
                  <button onClick={() => setStatusFilter('busy')} className={`flex flex-1 items-center justify-center space-x-1 p-1 rounded-full transition-colors ${statusFilter === 'busy' ? 'bg-amber-500 shadow-sm border border-amber-600 text-white' : 'bg-white hover:bg-amber-50 text-gray-700 border border-gray-200'}`} aria-label="Filter by Busy status">
                    <span className={`text-[10px] ${statusFilter === 'busy' ? 'font-bold' : 'font-medium'}`}>
                      B:
                    </span>
                    <div className={`${statusFilter === 'busy' ? 'bg-amber-400 text-white' : 'bg-amber-50 text-amber-700'} text-[10px] px-1.5 py-0.5 rounded-full font-semibold`}>
                      4
                    </div>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>;
    } else if (viewMode === 'compact') {
      return <div className="sticky top-0 z-10 p-1.5 border-b border-[#E2D9DC] bg-gradient-to-r from-[#EDE5E9] to-[#E5DDE1] shadow-sm">
          {/* Title and controls row - reduced vertical padding */}
          <div className="flex items-center justify-between mb-1.5">
            <div className="flex items-center">
              <div className="bg-[#3BB09A] p-0.5 rounded-md shadow-sm mr-1 text-white">
                <Users size={14} />
              </div>
              <h2 className="text-sm font-semibold text-gray-800">Team</h2>
            </div>
            <div className="flex items-center gap-1">
              <Tippy content="Search">
                <button className="p-0.5 rounded-md text-gray-500 hover:text-[#3BB09A] hover:bg-[#5EEAD4]/10 transition-colors" onClick={() => setShowSearch(!showSearch)} aria-label="Search">
                  <Search size={13} />
                </button>
              </Tippy>
              <Tippy content="Filter">
                <button className="p-0.5 rounded-md text-gray-500 hover:text-[#3BB09A] hover:bg-[#5EEAD4]/10 transition-colors" aria-label="Filter">
                  <Filter size={13} />
                </button>
              </Tippy>
              <Tippy content={getViewModeLabel()}>
                <button className="p-0.5 rounded-md text-gray-500 hover:text-[#3BB09A] hover:bg-[#5EEAD4]/10 transition-colors" onClick={toggleViewMode} aria-label={getViewModeLabel()}>
                  {getViewModeIcon()}
                </button>
              </Tippy>
              <div className="relative" ref={moreOptionsRef}>
                <Tippy content="More options">
                  <button className="p-0.5 rounded-md text-gray-500 hover:text-[#3BB09A] hover:bg-[#5EEAD4]/10 transition-colors" onClick={() => setShowMoreOptions(!showMoreOptions)} aria-label="More options">
                    <MoreVertical size={13} />
                  </button>
                </Tippy>
                {showMoreOptions && renderOptionsDropdown()}
              </div>
            </div>
          </div>
          {showSearch && <div className="mb-1.5">
              <div className="relative">
                <input type="text" placeholder="Search technicians..." className="w-full py-1 pl-7 pr-2 rounded-lg text-gray-800 text-xs border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#3BB09A] shadow-sm" value={searchQuery} onChange={e => setSearchQuery(e.target.value)} />
                <Search size={13} className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-400" />
              </div>
            </div>}
          {/* Status tabs - kept large and dominant */}
          <div className="flex items-center space-x-1.5 overflow-x-auto no-scrollbar py-1">
            <button onClick={() => setStatusFilter(null)} className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-full transition-all duration-200 flex-shrink-0 transform ${statusFilter === null ? 'bg-[#3BB09A] text-white font-bold shadow-md scale-105 ring-2 ring-[#3BB09A]/20' : 'bg-gray-50 text-gray-500 hover:bg-gray-100 border border-gray-200/80'}`}>
              <span className={`${statusFilter === null ? 'font-bold text-white' : 'font-normal'} text-xs`}>
                All
              </span>
              <span className={`${statusFilter === null ? 'bg-white text-[#3BB09A] shadow-sm' : 'bg-gray-200/70 text-gray-500'} text-xs px-1.5 py-0.5 rounded-full font-semibold`}>
                13
              </span>
            </button>
            {staffStatus.map(status => {
            // Only show Ready and Busy status filters
            if (status.id === 'ready' || status.id === 'busy') {
              const isActive = statusFilter === status.id;
              // Enhanced colors for active state
              const activeColors = {
                ready: 'bg-green-600 text-white font-bold shadow-md scale-105 ring-2 ring-green-200',
                busy: 'bg-amber-500 text-white font-bold shadow-md scale-105 ring-2 ring-amber-200'
              };
              // More subtle colors for inactive state
              const inactiveColors = {
                ready: 'bg-gray-50 text-gray-500 hover:bg-green-50/50 border border-gray-200/80',
                busy: 'bg-gray-50 text-gray-500 hover:bg-amber-50/50 border border-gray-200/80'
              };
              const bgColor = isActive ? activeColors[status.id] : inactiveColors[status.id];
              const badgeBg = isActive ? status.id === 'ready' ? 'bg-white text-green-700 shadow-sm' : 'bg-white text-amber-700 shadow-sm' : 'bg-gray-200/70 text-gray-500';
              return <button key={status.id} onClick={() => setStatusFilter(status.id)} className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-full transition-all duration-200 transform flex-shrink-0 ${bgColor}`}>
                    <span className={`text-xs ${isActive ? 'font-bold' : 'font-normal'}`}>
                      {status.label}
                    </span>
                    <span className={`${badgeBg} text-xs px-1.5 py-0.5 rounded-full font-semibold`}>
                      {status.count}
                    </span>
                  </button>;
            }
            return null;
          })}
          </div>
        </div>;
    } else {
      // Normal view
      return <div className="sticky top-0 z-10 p-2 border-b border-[#E2D9DC] bg-gradient-to-r from-[#EDE5E9] to-[#E5DDE1] shadow-sm">
          {/* Title and controls row - reduced vertical padding */}
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center">
              <div className="bg-[#3BB09A] p-1 rounded-lg shadow-sm mr-1.5 text-white">
                <Users size={15} />
              </div>
              <h2 className="text-sm font-bold text-gray-800">Team</h2>
            </div>
            <div className="flex items-center gap-1.5">
              <Tippy content="Search">
                <button className="p-1 rounded-md text-gray-500 hover:text-[#3BB09A] hover:bg-[#5EEAD4]/10 transition-colors" onClick={() => setShowSearch(!showSearch)}>
                  <Search size={14} />
                </button>
              </Tippy>
              <Tippy content="Filter">
                <button className="p-1 rounded-md text-gray-500 hover:text-[#3BB09A] hover:bg-[#5EEAD4]/10 transition-colors">
                  <Filter size={14} />
                </button>
              </Tippy>
              <Tippy content={getViewModeLabel()}>
                <button className="p-1 rounded-md text-gray-500 hover:text-[#3BB09A] hover:bg-[#5EEAD4]/10 transition-colors" onClick={toggleViewMode}>
                  {getViewModeIcon()}
                </button>
              </Tippy>
              <div className="relative" ref={moreOptionsRef}>
                <Tippy content="More options">
                  <button className="p-1 rounded-md text-gray-500 hover:text-[#3BB09A] hover:bg-[#5EEAD4]/10 transition-colors" onClick={() => setShowMoreOptions(!showMoreOptions)}>
                    <MoreVertical size={14} />
                  </button>
                </Tippy>
                {showMoreOptions && renderOptionsDropdown()}
              </div>
            </div>
          </div>
          {showSearch && <div className="mb-2">
              <div className="relative">
                <input type="text" placeholder="Search technicians by name..." className="w-full py-1.5 pl-8 pr-3 rounded-lg text-gray-800 text-xs border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#3BB09A] shadow-sm" value={searchQuery} onChange={e => setSearchQuery(e.target.value)} />
                <Search size={14} className="absolute left-2.5 top-1/2 transform -translate-y-1/2 text-gray-400" />
              </div>
            </div>}
          {/* Status tabs - kept large and dominant */}
          <div className="flex items-center space-x-2 overflow-x-auto no-scrollbar">
            <button onClick={() => setStatusFilter(null)} className={`flex items-center space-x-1.5 px-4 py-1.5 rounded-full transition-all duration-200 flex-shrink-0 transform ${statusFilter === null ? 'bg-[#3BB09A] text-white font-bold shadow-md scale-105 ring-2 ring-[#3BB09A]/20' : 'bg-white text-gray-700 hover:bg-[#5EEAD4]/10 border border-gray-200'}`}>
              <span className={`${statusFilter === null ? 'font-bold' : 'font-medium'} text-sm`}>
                All
              </span>
              <span className={`${statusFilter === null ? 'bg-white text-[#3BB09A]' : 'bg-gray-100 text-gray-600'} text-xs px-2 py-0.5 rounded-full font-semibold`}>
                13
              </span>
            </button>
            {staffStatus.map(status => {
            // Only show Ready and Busy status filters
            if (status.id === 'ready' || status.id === 'busy') {
              const isActive = statusFilter === status.id;
              const activeColors = {
                ready: 'bg-green-600 text-white font-bold shadow-md scale-105 ring-2 ring-green-200',
                busy: 'bg-amber-500 text-white font-bold shadow-md scale-105 ring-2 ring-amber-200'
              };
              const inactiveColors = {
                ready: 'bg-white text-gray-700 hover:bg-green-50 border border-gray-200',
                busy: 'bg-white text-gray-700 hover:bg-amber-50 border border-gray-200'
              };
              const bgColor = isActive ? activeColors[status.id] : inactiveColors[status.id];
              const badgeBg = status.id === 'ready' ? isActive ? 'bg-white text-green-700' : 'bg-gray-100 text-gray-600' : isActive ? 'bg-white text-amber-700' : 'bg-gray-100 text-gray-600';
              return <button key={status.id} onClick={() => setStatusFilter(status.id)} className={`flex items-center space-x-1.5 px-4 py-1.5 rounded-full transition-all duration-200 transform flex-shrink-0 ${bgColor}`}>
                    <span className={`text-sm ${isActive ? 'font-bold' : 'font-medium'}`}>
                      {status.label}
                    </span>
                    <span className={`${badgeBg} text-xs px-2 py-0.5 rounded-full font-semibold`}>
                      {status.count}
                    </span>
                  </button>;
            }
            return null;
          })}
          </div>
        </div>;
    }
  };
  // Render options dropdown
  const renderOptionsDropdown = () => {
    const isUltraCompact = sidebarWidth <= 100;
    return <div className={`fixed ${isUltraCompact ? '' : 'absolute'} ${isUltraCompact ? 'left-[104px]' : 'right-0'} mt-1 w-64 bg-white rounded-lg shadow-lg border border-gray-200 z-[1000] py-1.5 text-sm overflow-hidden`}>
        <div className="px-3 py-2 border-b border-gray-100 bg-gray-50">
          <h3 className="text-sm font-medium text-gray-700">Sidebar Width</h3>
          <p className="text-xs text-gray-500 mt-0.5">
            Adjust width of technicians panel
          </p>
        </div>
        <div className="py-1">
          <div className="px-3 py-1.5 text-xs font-medium text-gray-500 bg-gray-50">
            Fixed Widths
          </div>
          {fixedSizeOptions.map(option => <button key={option.value} className="w-full text-left px-3 py-2 hover:bg-gray-50 flex items-center justify-between transition-colors" onClick={() => handleSetFixedWidth(option.value)}>
              <div>
                <div className="text-gray-700 font-medium">{option.label}</div>
                <div className="text-xs text-gray-500">
                  {option.description}
                </div>
              </div>
              {widthType === 'fixed' && sidebarWidth === option.value && <Check size={16} className="text-gray-500" />}
            </button>)}
          <div className="px-3 py-1.5 text-xs font-medium text-gray-500 bg-gray-50 mt-1">
            Responsive Widths
          </div>
          {percentageSizeOptions.map(option => <button key={option.value} className="w-full text-left px-3 py-2 hover:bg-gray-50 flex items-center justify-between transition-colors" onClick={() => handleSetPercentageWidth(option.value)}>
              <div>
                <div className="text-gray-700 font-medium">{option.label}</div>
                <div className="text-xs text-gray-500">
                  {option.description}
                </div>
              </div>
              {widthType === 'percentage' && widthPercentage === option.value && <Check size={16} className="text-gray-500" />}
            </button>)}
          {/* Custom width option - Replaced with a single button */}
          <div className="px-3 py-1.5 text-xs font-medium text-gray-500 bg-gray-50 mt-1">
            Custom Width
          </div>
          <button className="w-full text-left px-3 py-2 hover:bg-gray-50 flex items-center justify-between transition-colors" onClick={() => {
          // Save original width before opening popup
          saveOriginalWidth();
          setShowCustomWidthPopup(true);
          setShowMoreOptions(false);
          // Pre-fill the input with current percentage if using custom percentage
          if (widthType === 'customPercentage') {
            setCustomWidthInput(widthPercentage.toString());
          } else {
            setCustomWidthInput('');
          }
        }}>
            <div>
              <div className="text-gray-700 font-medium">Custom Percentage</div>
              <div className="text-xs text-gray-500">
                Set a custom percentage width for the sidebar
              </div>
            </div>
            {widthType === 'customPercentage' && <div className="flex items-center">
                <span className="text-sm text-[#3BB09A] font-medium mr-1">
                  {widthPercentage}%
                </span>
                <Check size={16} className="text-gray-500" />
              </div>}
          </button>
          {/* Add a view mode section to the dropdown */}
          <div className="px-3 py-1.5 text-xs font-medium text-gray-500 bg-gray-50 mt-1">
            Card View Mode
          </div>
          <button className="w-full text-left px-3 py-2 hover:bg-gray-50 flex items-center justify-between transition-colors" onClick={toggleViewMode}>
            <div>
              <div className="text-gray-700 font-medium">
                {viewMode === 'normal' ? 'Normal View' : 'Compact View'}
              </div>
              <div className="text-xs text-gray-500">
                {viewMode === 'normal' ? 'Full cards with detailed information' : 'Horizontal cards with basic information'}
              </div>
            </div>
            <Check size={16} className="text-gray-500" />
          </button>
        </div>
      </div>;
  };
  // Render custom width popup
  const renderCustomWidthPopup = () => {
    if (!showCustomWidthPopup) return null;
    return <div className="fixed inset-0 flex items-start justify-center z-[1001] pt-20">
        <div className="absolute inset-0 bg-black bg-opacity-30" onClick={() => {
        // Restore original width when clicking outside
        restoreOriginalWidth();
        setShowCustomWidthPopup(false);
        setIsPreviewMode(false);
      }}></div>
        <div ref={customWidthPopupRef} className="bg-white rounded-lg shadow-xl border border-gray-200 w-80 z-10 transform transition-transform duration-200" style={{
        boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)'
      }}>
          <div className="px-4 py-3 border-b border-gray-200 bg-gradient-to-r from-[#5EEAD4]/20 to-[#3BB09A]/20">
            <h3 className="text-lg font-bold text-gray-800">Custom Width</h3>
            <p className="text-sm text-gray-500">
              Set a custom percentage width
            </p>
          </div>
          <div className="p-4">
            <div className="mb-4">
              <label htmlFor="custom-percentage" className="block text-sm font-medium text-gray-700 mb-1">
                Width Percentage
              </label>
              <div className="flex items-center">
                <input id="custom-percentage" type="number" min="10" max="100" className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-[#3BB09A] focus:border-[#3BB09A] text-base" placeholder="Enter percentage (10-100)" value={customWidthInput} onChange={e => {
                setCustomWidthInput(e.target.value);
                const percentage = parseInt(e.target.value);
                if (!isNaN(percentage) && percentage >= 10 && percentage <= 100) {
                  previewCustomPercentageWidth(percentage);
                }
              }} />
                <span className="ml-2 text-gray-500 text-lg font-medium">
                  %
                </span>
              </div>
              <p className="mt-1 text-sm text-gray-500">
                Choose between 10% and 100%
              </p>
            </div>
            <div className="mt-2 mb-1 text-sm font-medium text-gray-700">
              Quick Select
            </div>
            <div className="grid grid-cols-3 gap-2 mb-4">
              {[25, 33, 50, 67, 75, 100].map(percent => <button key={percent} className={`py-1.5 px-2 rounded border ${parseInt(customWidthInput) === percent ? 'bg-[#3BB09A] text-white border-[#3BB09A]' : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'}`} onClick={() => {
              setCustomWidthInput(percent.toString());
              previewCustomPercentageWidth(percent);
            }}>
                  {percent}%
                </button>)}
            </div>
            <div className="flex justify-end space-x-3 mt-4 border-t border-gray-100 pt-4">
              <button className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#3BB09A]" onClick={() => {
              // Restore original width when cancelling
              restoreOriginalWidth();
              setShowCustomWidthPopup(false);
              setIsPreviewMode(false);
            }}>
                Cancel
              </button>
              <button className="px-4 py-2 border border-transparent rounded-md shadow-sm text-white bg-[#3BB09A] hover:bg-[#2A9D8C] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#3BB09A]" onClick={() => {
              const percentage = parseInt(customWidthInput);
              if (!isNaN(percentage) && percentage >= 10 && percentage <= 100) {
                handleSetCustomPercentageWidth(percentage);
              }
            }}>
                Apply
              </button>
            </div>
          </div>
        </div>
      </div>;
  };
  // Calculate the card width style based on view mode to ensure consistency
  const getCardWidthStyle = () => {
    // Let the cards fill their container naturally
    return {};
  };
  // Get the priority tiers based on current width and view mode
  const priorityTiers = getDisplayPriorityTiers();
  return <div className="h-full border-r border-[#E2D9DC] bg-[#FBF8F9] flex flex-col overflow-hidden shadow-xl transition-all duration-300" style={{
    width: `${sidebarWidth}px`,
    boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.05), 0 10px 10px -5px rgba(0, 0, 0, 0.02)'
  }}>
      {renderHeader()}
      {renderCustomWidthPopup()}
      <div className="flex-1 overflow-auto bg-gradient-to-b from-[#FBF8F9] to-[#F7F2F4] relative">
        {filteredStaff.length > 0 ? <div className={`grid ${getGridColumns()} ${getGapAndPadding()}`}>
            {filteredStaff.map(staff => <div key={staff.id} className="w-full min-w-[80px]">
                <StaffCard staff={staff} viewMode={getCardViewMode()} isDraggable={true} isSelected={staff.id === 3} // Example: Julie is selected
          // Pass the priority tiers to control what content is displayed
          displayConfig={{
            showName: true,
            showQueueNumber: priorityTiers.tier1,
            showAvatar: priorityTiers.tier1,
            showTurnCount: priorityTiers.tier2,
            showStatus: priorityTiers.tier3,
            showClockedInTime: priorityTiers.tier4,
            showNextAppointment: priorityTiers.tier5,
            showSalesAmount: priorityTiers.tier6,
            showTickets: priorityTiers.tier7,
            showLastService: priorityTiers.tier8,
            // Ensure clear separation between top and bottom sections
            enhancedSeparator: true,
            // Add new props to control busy status styling
            busyIndicatorPosition: 'top-left',
            grayOutFullCard: true // Gray out the entire card when busy
          }} />
              </div>)}
          </div> : <div className={`p-${sidebarWidth <= 100 ? '2' : viewMode === 'compact' ? '3' : '5'} text-center text-gray-500 ${sidebarWidth <= 100 ? 'text-[9px]' : viewMode === 'compact' ? 'text-xs' : 'text-sm'}`}>
            <div className="bg-white bg-opacity-70 rounded-lg shadow-md p-4 backdrop-blur-sm">
              <p>No technicians match your filters</p>
            </div>
          </div>}
        {/* Scroll hint gradient */}
        
      </div>
    </div>;
}