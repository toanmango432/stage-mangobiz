import React, { useEffect, useState, useRef } from 'react';
import { ServiceCard } from './ServiceCard';
import Tippy from '@tippyjs/react';
import 'tippy.js/dist/tippy.css';
import { List, Grid, Filter, Minimize2, Maximize2, FileText, MoreVertical, Check, Clock, Calendar, User, Tag, CheckCircle, ChevronDown, ChevronUp, ChevronRight } from 'lucide-react';
interface ServiceSectionProps {
  isMinimized?: boolean;
  onToggleMinimize?: () => void;
  isMobile?: boolean;
  viewMode?: 'grid' | 'list';
  setViewMode?: (mode: 'grid' | 'list') => void;
  cardViewMode?: 'normal' | 'compact';
  setCardViewMode?: (mode: 'normal' | 'compact') => void;
  minimizedLineView?: boolean;
  setMinimizedLineView?: (minimized: boolean) => void;
  isCombinedView?: boolean;
  hideHeader?: boolean;
}
export function ServiceSection({
  isMinimized = false,
  onToggleMinimize,
  isMobile = false,
  viewMode: externalViewMode,
  setViewMode: externalSetViewMode,
  cardViewMode: externalCardViewMode,
  setCardViewMode: externalSetCardViewMode,
  minimizedLineView: externalMinimizedLineView,
  setMinimizedLineView: externalSetMinimizedLineView,
  isCombinedView = false,
  hideHeader = false
}: ServiceSectionProps) {
  // Get view mode from localStorage, default to 'list'
  const [internalViewMode, setInternalViewMode] = useState<'grid' | 'list'>(() => {
    const saved = localStorage.getItem('serviceViewMode');
    return saved === 'grid' || saved === 'list' ? saved as 'grid' | 'list' : 'list';
  });
  // Add card view mode state (normal or compact)
  const [internalCardViewMode, setInternalCardViewMode] = useState<'normal' | 'compact'>(() => {
    const saved = localStorage.getItem('serviceCardViewMode');
    return saved === 'normal' || saved === 'compact' ? saved as 'normal' | 'compact' : 'normal';
  });
  // Add minimized line view state
  const [internalMinimizedLineView, setInternalMinimizedLineView] = useState<boolean>(() => {
    const saved = localStorage.getItem('serviceMinimizedLineView');
    return saved === 'true' ? true : false;
  });
  // Use either external or internal state based on isCombinedView
  const viewMode = isCombinedView && externalViewMode ? externalViewMode : internalViewMode;
  const setViewMode = (newMode: 'grid' | 'list') => {
    if (isCombinedView && externalSetViewMode) {
      externalSetViewMode(newMode);
    } else {
      setInternalViewMode(newMode);
      localStorage.setItem('serviceViewMode', newMode);
    }
  };
  const cardViewMode = isCombinedView && externalCardViewMode ? externalCardViewMode : internalCardViewMode;
  const setCardViewMode = (newMode: 'normal' | 'compact') => {
    if (isCombinedView && externalSetCardViewMode) {
      externalSetCardViewMode(newMode);
    } else {
      setInternalCardViewMode(newMode);
      localStorage.setItem('serviceCardViewMode', newMode);
    }
  };
  const minimizedLineView = isCombinedView && externalMinimizedLineView !== undefined ? externalMinimizedLineView : internalMinimizedLineView;
  const setMinimizedLineView = (newValue: boolean) => {
    if (isCombinedView && externalSetMinimizedLineView) {
      externalSetMinimizedLineView(newValue);
    } else {
      setInternalMinimizedLineView(newValue);
      localStorage.setItem('serviceMinimizedLineView', newValue.toString());
    }
  };
  // State for dropdown menu
  const [showDropdown, setShowDropdown] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  // Close dropdowns when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setShowDropdown(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
  // Toggle between normal and compact card view
  const toggleCardViewMode = () => {
    const newMode = cardViewMode === 'normal' ? 'compact' : 'normal';
    setCardViewMode(newMode);
  };
  // Toggle minimized line view
  const toggleMinimizedLineView = () => {
    const newValue = !minimizedLineView;
    setMinimizedLineView(newValue);
  };
  // Get the appropriate view mode label
  const getViewModeLabel = () => {
    if (cardViewMode === 'normal') {
      return 'Switch to compact view';
    } else {
      return 'Switch to normal view';
    }
  };
  const services = [{
    id: 1,
    number: 2,
    clientName: 'Tim Tim GUEST',
    clientType: 'Reward',
    time: '05:30',
    duration: '38m',
    service: 'SIGNATURE MANICURE',
    technician: 'HANK',
    techColor: 'bg-[#E5565B]'
  }, {
    id: 2,
    number: 7,
    clientName: 'Sean Nguyen',
    clientType: 'Reward',
    time: '05:53',
    duration: '15m',
    service: 'DIPPING OVERLAY',
    technician: 'MARK',
    techColor: 'bg-[#3F83F8]'
  }, {
    id: 3,
    number: 3,
    clientName: 'AKEY G2',
    clientType: 'Reward',
    time: '05:30',
    duration: '38m',
    service: 'DELUXE MANICURE',
    technician: 'JIM',
    techColor: 'bg-[#4CC2A9]'
  }, {
    id: 4,
    number: 8,
    clientName: 'Lan Nguyen',
    clientType: 'Reward',
    time: '05:53',
    duration: '15m',
    service: 'DIPPING OMBRE',
    technician: 'JULIE',
    techColor: 'bg-[#E5565B]'
  }, {
    id: 5,
    number: 5,
    clientName: 'Sia Ly GUEST1',
    clientType: 'VIP',
    time: '05:31',
    duration: '37m',
    service: 'SIGNATURE PEDICURE',
    technician: 'SAM',
    techColor: 'bg-[#4CC2A9]'
  }, {
    id: 6,
    number: 10,
    clientName: 'Sean Nguyen',
    clientType: 'Reward',
    time: '05:49',
    duration: '127m',
    service: 'ESSENTIAL PEDICURE',
    technician: 'JOE',
    techColor: 'bg-[#9B5DE5]'
  }, {
    id: 7,
    number: 6,
    clientName: 'Sia Ly GUEST1',
    clientType: 'VIP',
    time: '05:31',
    duration: '37m',
    service: 'FULL FACE',
    technician: 'SUE',
    techColor: 'bg-[#E5565B]'
  }];
  // Enhanced color mappings for more vibrant tech colors
  const techColorMap: Record<string, string> = {
    'bg-[#E5565B]': 'bg-gradient-to-r from-[#FF6B70] to-[#E04146]',
    'bg-[#3F83F8]': 'bg-gradient-to-r from-[#5A9FFF] to-[#3373E8]',
    'bg-[#4CC2A9]': 'bg-gradient-to-r from-[#5EEAD4] to-[#3BB09A]',
    'bg-[#9B5DE5]': 'bg-gradient-to-r from-[#AF6FFF] to-[#8A4AD0]',
    'bg-[#3C78D8]': 'bg-gradient-to-r from-[#4A8EFF] to-[#2A68C8]',
    'bg-white': 'bg-gradient-to-r from-gray-100 to-white text-gray-700'
  };
  // Render list view item with bolder paper ticket styling
  const ServiceListItem = ({
    service
  }: {
    service: (typeof services)[0];
  }) => {
    const techColor = techColorMap[service.techColor] || service.techColor;
    return <div className="bg-[#FFF8E8] rounded-lg border-2 border-amber-100 hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1 hover:rotate-[0.2deg] mb-3 relative overflow-hidden group shadow-md" style={{
      backgroundImage: 'url("https://www.transparenttextures.com/patterns/paper-fibers.png")'
    }}>
        {/* Perforation marks - top */}
        <div className="absolute top-0 left-0 w-full h-[6px] overflow-hidden flex items-center">
          <div className="w-full flex justify-between px-4">
            {[...Array(20)].map((_, i) => <div key={i} className="w-1 h-1 bg-amber-200 rounded-full"></div>)}
          </div>
        </div>
        {/* Left ticket notch */}
        <div className="absolute -left-2 top-1/2 w-4 h-4 bg-gray-100 rounded-full border-r-2 border-amber-200"></div>
        {/* Right ticket notch */}
        <div className="absolute -right-2 top-1/2 w-4 h-4 bg-gray-100 rounded-full border-l-2 border-amber-200"></div>
        {/* Status indicator strip */}
        <div className="absolute top-0 left-0 w-2 h-full bg-gradient-to-b from-gray-400 to-gray-300"></div>
        <div className="flex flex-wrap sm:flex-nowrap items-center p-2 sm:p-3 pl-4 pt-3">
          {/* Left section - Number & Client */}
          <div className="w-[32px] h-[32px] sm:w-[40px] sm:h-[40px] bg-gray-800 text-white rounded-full flex items-center justify-center text-xs sm:text-sm font-bold shadow-lg mr-2 sm:mr-3 flex-shrink-0 transform -rotate-3 ring-2 ring-amber-300">
            {service.number}
          </div>
          <div className="flex flex-col min-w-0 flex-grow pr-2">
            <div className="font-bold text-gray-800 flex items-center flex-wrap">
              <span className="truncate mr-2 text-sm sm:text-base max-w-[120px] sm:max-w-full font-mono">
                {service.clientName}
              </span>
              <span className="text-[10px] sm:text-xs bg-amber-100 text-amber-800 font-bold px-1.5 sm:px-2 py-0.5 rounded-md shadow-sm mt-0.5 sm:mt-0 border border-amber-300 uppercase tracking-wide">
                {service.clientType}
              </span>
            </div>
            <div className="flex items-center mt-0.5 sm:mt-1 text-[10px] sm:text-xs text-gray-700 font-mono font-semibold">
              <div className="flex items-center mr-2 sm:mr-3">
                <Calendar size={10} className="text-amber-700 mr-0.5 sm:mr-1" />
                <span>{service.time}</span>
              </div>
              <div className="flex items-center">
                <Clock size={10} className="text-amber-700 mr-0.5 sm:mr-1" />
                <span>{service.duration}</span>
              </div>
            </div>
          </div>
          {/* Middle section - Service */}
          <div className="hidden sm:flex flex-grow items-center mx-3 max-w-[30%] bg-[#FFF8E8] px-2 py-1 rounded border-l-2 border-amber-300 shadow-sm">
            <Tag size={14} className="text-amber-700 mr-1.5 flex-shrink-0" />
            <span className="text-sm text-gray-800 truncate font-mono font-semibold">
              {service.service}
            </span>
          </div>
          {/* Service for small screens */}
          <div className="sm:hidden text-[10px] text-gray-800 bg-[#FFF8E8] px-1.5 py-0.5 rounded-sm mt-1 mb-1 w-full truncate border-l-2 border-amber-300 font-semibold">
            <Tag size={10} className="text-amber-700 mr-1 inline-block" />
            <span className="font-mono">{service.service}</span>
          </div>
          {/* Right section - Technician */}
          {service.technician && <div className={`${techColor} text-white text-[10px] sm:text-xs font-bold px-2 sm:px-3 py-1 sm:py-1.5 rounded-full shadow-lg ml-auto mr-1 sm:mr-2 flex-shrink-0`} style={{
          clipPath: 'polygon(4% 0%, 100% 0%, 96% 100%, 0% 100%)',
          paddingLeft: '10px',
          paddingRight: '10px'
        }}>
              {service.technician}
            </div>}
          {/* Actions */}
          <div className="flex items-center flex-shrink-0">
            {/* Done button */}
            <Tippy content="Mark as done">
              <button className="p-1.5 sm:p-2 rounded-full text-green-600 hover:text-green-700 hover:bg-green-100 transition-colors mr-1 touch-manipulation shadow-sm border border-green-200">
                <CheckCircle size={18} />
              </button>
            </Tippy>
            <Tippy content="More options">
              <button className="text-gray-500 hover:text-gray-700 p-1.5 sm:p-2 rounded-full hover:bg-amber-100 transition-colors touch-manipulation">
                <MoreVertical size={16} />
              </button>
            </Tippy>
          </div>
        </div>
        {/* Paper texture overlay */}
        <div className="absolute inset-0 pointer-events-none opacity-10 mix-blend-overlay" style={{
        backgroundImage: 'url("https://www.transparenttextures.com/patterns/cardboard.png")'
      }}></div>
      </div>;
  };
  // Render minimized list view item with bolder paper ticket styling
  const MinimizedServiceListItem = ({
    service
  }: {
    service: (typeof services)[0];
  }) => {
    const techColor = techColorMap[service.techColor] || service.techColor;
    return <div className="bg-[#FFF8E8] rounded-lg border-2 border-amber-100 hover:shadow-lg transition-all duration-300 transform hover:-translate-y-0.5 hover:rotate-[0.2deg] mb-2 relative overflow-hidden shadow-md" style={{
      backgroundImage: 'url("https://www.transparenttextures.com/patterns/paper-fibers.png")'
    }}>
        {/* Left notch */}
        <div className="absolute -left-2 top-1/2 w-4 h-4 bg-gray-100 rounded-full border-r-2 border-amber-200"></div>
        {/* Right notch */}
        <div className="absolute -right-2 top-1/2 w-4 h-4 bg-gray-100 rounded-full border-l-2 border-amber-200"></div>
        {/* Status indicator strip */}
        <div className="absolute top-0 left-0 w-2 h-full bg-gradient-to-b from-gray-400 to-gray-300"></div>
        <div className="flex items-center p-2 pl-4">
          {/* Number & Client */}
          <div className="w-[28px] h-[28px] bg-gray-800 text-white rounded-full flex items-center justify-center text-xs font-bold shadow-lg mr-2 flex-shrink-0 transform -rotate-3 ring-1 ring-amber-300">
            {service.number}
          </div>
          <div className="flex flex-col min-w-0 flex-grow">
            <div className="flex items-center">
              <span className="truncate text-xs font-bold text-gray-800 mr-1.5 max-w-[100px] font-mono">
                {service.clientName}
              </span>
              <span className="text-[9px] bg-amber-100 text-amber-800 px-1 py-0.5 rounded-sm border border-amber-300 font-bold uppercase">
                {service.clientType}
              </span>
            </div>
            <div className="flex items-center mt-0.5">
              <Tag size={9} className="text-amber-700 mr-1 flex-shrink-0" />
              <span className="text-[9px] text-gray-700 truncate max-w-[120px] font-mono font-semibold">
                {service.service}
              </span>
            </div>
          </div>
          {/* Technician */}
          {service.technician && <div className={`${techColor} text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full shadow-md ml-auto mr-1 flex-shrink-0`} style={{
          clipPath: 'polygon(4% 0%, 100% 0%, 96% 100%, 0% 100%)',
          paddingLeft: '8px',
          paddingRight: '8px'
        }}>
              {service.technician}
            </div>}
          {/* Done button */}
          <Tippy content="Mark as done">
            <button className="p-1 rounded-full text-green-600 hover:text-green-700 hover:bg-green-100 transition-colors flex-shrink-0 shadow-sm border border-green-200">
              <CheckCircle size={14} />
            </button>
          </Tippy>
        </div>
        {/* Paper texture overlay */}
        <div className="absolute inset-0 pointer-events-none opacity-10 mix-blend-overlay" style={{
        backgroundImage: 'url("https://www.transparenttextures.com/patterns/cardboard.png")'
      }}></div>
      </div>;
  };
  // Render minimized list item with bolder paper ticket styling
  const MinimizedServiceListItem2 = ({
    service
  }: {
    service: (typeof services)[0];
  }) => {
    const techColor = techColorMap[service.techColor] || service.techColor;
    return <div className="flex items-center bg-[#FFF8E8] rounded-lg border-2 border-amber-100 p-2 mb-1.5 hover:shadow-md transition-all transform hover:-translate-y-0.5 hover:rotate-[0.2deg] relative overflow-hidden" style={{
      backgroundImage: 'url("https://www.transparenttextures.com/patterns/paper-fibers.png")'
    }}>
        <div className="bg-gray-800 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold transform -rotate-3 ring-1 ring-amber-300 shadow-sm">
          {service.number}
        </div>
        <span className="ml-2 text-xs font-bold text-gray-800 truncate max-w-[100px] font-mono">
          {service.clientName}
        </span>
        {service.technician && <div className={`${techColor} text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full shadow-md ml-auto`} style={{
        clipPath: 'polygon(4% 0%, 100% 0%, 96% 100%, 0% 100%)',
        paddingLeft: '8px',
        paddingRight: '8px'
      }}>
            {service.technician}
          </div>}
        {/* Paper texture overlay */}
        <div className="absolute inset-0 pointer-events-none opacity-10 mix-blend-overlay" style={{
        backgroundImage: 'url("https://www.transparenttextures.com/patterns/cardboard.png")'
      }}></div>
      </div>;
  };
  if (isMinimized) {
    return <div className="bg-white rounded-lg shadow-md border border-gray-200 flex flex-col overflow-hidden">
        <div className="flex items-center justify-between px-3 py-2.5 bg-gradient-to-r from-gray-50 to-gray-100 border-b border-gray-200">
          <div className="flex items-center">
            <div className="bg-gray-700 p-1.5 rounded-md shadow-sm mr-2">
              <FileText size={16} className="text-white" />
            </div>
            <h2 className="text-base font-bold text-gray-700">In Service</h2>
            <div className="ml-2 bg-gray-700 text-white text-xs px-2 py-1 rounded-full shadow-sm">
              {services.length}
            </div>
          </div>
          <div className="flex space-x-1">
            <Tippy content="Expand section">
              <button className="p-1.5 rounded-md text-gray-500 hover:text-gray-700 hover:bg-gray-100 transition-all duration-200 transform hover:scale-105 active:scale-95 touch-manipulation" onClick={onToggleMinimize}>
                <Maximize2 size={isMobile ? 20 : 16} />
              </button>
            </Tippy>
          </div>
        </div>
        {/* Minimized list view */}
        <div className="p-2 overflow-auto max-h-40">
          {services.slice(0, 3).map(service => <MinimizedServiceListItem2 key={service.id} service={service} />)}
          {services.length > 3 && <button className="w-full text-center text-xs text-gray-500 hover:text-gray-700 mt-1 py-1 touch-manipulation" onClick={onToggleMinimize}>
              + {services.length - 3} more tickets
            </button>}
        </div>
      </div>;
  }
  return <div className="bg-white rounded-lg shadow-md border border-gray-200 flex flex-col overflow-hidden h-full">
      {/* Section header - hide when in combined view and hideHeader is true */}
      {!hideHeader && <div className="flex items-center justify-between px-3 py-2.5 bg-gradient-to-r from-gray-50 to-gray-100 border-b border-gray-200 sticky top-0 z-10">
          <div className="flex items-center">
            <div className="bg-gray-700 p-1.5 rounded-md shadow-sm mr-2">
              <FileText size={16} className="text-white" />
            </div>
            <h2 className="text-base font-bold text-gray-700">In Service</h2>
            <div className="ml-2 bg-gray-700 text-white text-xs px-2 py-1 rounded-full shadow-sm">
              {services.length}
            </div>
          </div>
          <div className="flex space-x-1">
            {!isMobile && viewMode === 'list' && <Tippy content={minimizedLineView ? 'Expand line view' : 'Minimize line view'}>
                <button className="p-1.5 rounded-md text-gray-500 hover:text-gray-700 hover:bg-gray-100 transition-all duration-200 transform hover:scale-105 active:scale-95" onClick={toggleMinimizedLineView}>
                  {minimizedLineView ? <ChevronDown size={16} /> : <ChevronUp size={16} />}
                </button>
              </Tippy>}
            {!isMobile && viewMode === 'grid' && <Tippy content={cardViewMode === 'compact' ? 'Expand card view' : 'Minimize card view'}>
                <button className="p-1.5 rounded-md text-gray-500 hover:text-gray-700 hover:bg-gray-100 transition-all duration-200 transform hover:scale-105 active:scale-95" onClick={toggleCardViewMode}>
                  {cardViewMode === 'compact' ? <ChevronDown size={16} /> : <ChevronUp size={16} />}
                </button>
              </Tippy>}
            <div className="relative" ref={dropdownRef}>
              <Tippy content="More options">
                <button className="p-1.5 rounded-md text-gray-500 hover:text-gray-700 hover:bg-gray-100 transition-all duration-200 transform hover:scale-105 active:scale-95" onClick={() => setShowDropdown(!showDropdown)}>
                  <MoreVertical size={16} />
                </button>
              </Tippy>
              {showDropdown && <div className="absolute right-0 mt-1 w-48 bg-white rounded-md shadow-lg z-10 border border-gray-200 py-1">
                  <div className="px-3 py-2 border-b border-gray-100 bg-gray-50">
                    <h3 className="text-sm font-medium text-gray-700">
                      View Options
                    </h3>
                  </div>
                  <button className="w-full text-left px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 flex items-center" onClick={() => setViewMode('list')}>
                    <List size={14} className="mr-2 text-gray-500" />
                    Line View
                    {viewMode === 'list' && <Check size={14} className="ml-auto text-gray-500" />}
                  </button>
                  <button className="w-full text-left px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 flex items-center" onClick={() => setViewMode('grid')}>
                    <Grid size={14} className="mr-2 text-gray-500" />
                    Grid View
                    {viewMode === 'grid' && <Check size={14} className="ml-auto text-gray-500" />}
                  </button>
                </div>}
            </div>
            <Tippy content="Minimize section">
              <button className="p-1.5 rounded-md text-gray-500 hover:text-gray-700 hover:bg-gray-100 transition-all duration-200 transform hover:scale-105 active:scale-95 touch-manipulation" onClick={onToggleMinimize}></button>
            </Tippy>
          </div>
        </div>}
      {/* Add view controls even when header is hidden in combined view */}
      {hideHeader && isCombinedView && <div className="flex items-center justify-end space-x-1 pr-3">
          {/* Remove the view control buttons from here as they're now in the header */}
        </div>}
      <div className="flex-1 overflow-auto p-3">
        {viewMode === 'grid' ? <div className={`grid ${viewMode === 'grid' ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4' : 'grid-cols-1'} gap-3`}>
            {services.map(service => <ServiceCard key={service.id} service={service} viewMode={cardViewMode} />)}
          </div> : <div className="space-y-2">
            {services.map(service => minimizedLineView ? <MinimizedServiceListItem key={service.id} service={service} /> : <ServiceListItem key={service.id} service={service} />)}
          </div>}
      </div>
    </div>;
}