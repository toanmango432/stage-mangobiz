import React, { useEffect, useState, useRef } from 'react';
import Tippy from '@tippyjs/react';
import 'tippy.js/dist/tippy.css';
import { AlertCircle, Plus, Minimize2, Maximize2, AlertTriangle, MoreVertical, Clock, Calendar, Timer, Tag, User, ChevronRight, X, Trash2, Edit2, Info, LayoutGrid, Layers } from 'lucide-react';
interface PendingTicketsProps {
  isMinimized?: boolean;
  onToggleMinimize?: () => void;
}
export function PendingTickets({
  isMinimized = false,
  onToggleMinimize
}: PendingTicketsProps) {
  // Add effect to prevent body scrolling when in full view
  useEffect(() => {
    if (!isMinimized) {
      // Prevent scrolling on the body when expanded
      document.body.style.overflow = 'hidden';
    } else {
      // Restore scrolling when minimized
      document.body.style.overflow = 'auto';
    }
    // Cleanup
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, [isMinimized]);
  // Add card view mode state (normal or compact)
  const [cardViewMode, setCardViewMode] = useState<'normal' | 'compact'>(() => {
    const saved = localStorage.getItem('pendingTicketsCardViewMode');
    return saved === 'normal' || saved === 'compact' ? saved as 'normal' | 'compact' : 'normal';
  });
  // Save card view mode to localStorage when it changes
  useEffect(() => {
    localStorage.setItem('pendingTicketsCardViewMode', cardViewMode);
  }, [cardViewMode]);
  // Toggle between normal and compact card view
  const toggleCardViewMode = () => {
    setCardViewMode(cardViewMode === 'normal' ? 'compact' : 'normal');
  };
  // Get the appropriate view mode icon
  const getViewModeIcon = () => {
    if (cardViewMode === 'normal') {
      return <LayoutGrid size={16} />;
    } else {
      return <Layers size={16} />;
    }
  };
  // Get the appropriate view mode label
  const getViewModeLabel = () => {
    if (cardViewMode === 'normal') {
      return 'Switch to compact view';
    } else {
      return 'Switch to normal view';
    }
  };
  // State to track which ticket's dropdown is open
  const [openDropdownId, setOpenDropdownId] = useState<number | null>(null);
  // State for delete confirmation modal
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [ticketToDelete, setTicketToDelete] = useState<number | null>(null);
  const [deleteReason, setDeleteReason] = useState('');
  // State for header dropdown menu
  const [showHeaderDropdown, setShowHeaderDropdown] = useState(false);
  // State for delete all confirmation modal
  const [showDeleteAllModal, setShowDeleteAllModal] = useState(false);
  const [deleteAllReason, setDeleteAllReason] = useState('');
  // Refs for dropdown menus
  const dropdownRef = useRef<HTMLDivElement>(null);
  const headerDropdownRef = useRef<HTMLDivElement>(null);
  // Close dropdowns when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setOpenDropdownId(null);
      }
      if (headerDropdownRef.current && !headerDropdownRef.current.contains(event.target as Node)) {
        setShowHeaderDropdown(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
  // Sample pending tickets data
  const [pendingTickets, setPendingTickets] = useState([{
    id: 1,
    number: 2,
    clientName: 'Tim Tim GUEST',
    clientType: 'Reward',
    time: '06:40',
    duration: '30min',
    service: 'SIGNATURE MANICURE',
    technician: 'HANK',
    techColor: 'bg-[#E5565B]'
  }, {
    id: 2,
    number: 8,
    clientName: 'Lan Nguyen',
    clientType: 'Reward',
    time: '06:53',
    duration: '50min',
    service: 'DIPPING OMBRE',
    technician: 'JULIE',
    techColor: 'bg-[#E5565B]'
  }, {
    id: 3,
    number: 3,
    clientName: 'AKEY G2',
    clientType: 'Reward',
    time: '06:45',
    duration: '20min',
    service: 'DELUXE MANICURE',
    technician: 'JIM',
    techColor: 'bg-[#4CC2A9]'
  }, {
    id: 4,
    number: 7,
    clientName: 'Z Test',
    clientType: 'Reward',
    time: '07:11',
    duration: '120min',
    service: 'SIGNATURE PEDICURE, DELUXE PEDI',
    technician: 'JULIE',
    techColor: 'bg-[#E5565B]'
  }, {
    id: 5,
    number: 12,
    clientName: 'Sarah Johnson',
    clientType: 'VIP',
    time: '07:15',
    duration: '45min',
    service: 'GEL MANICURE',
    technician: 'KEVIN',
    techColor: 'bg-[#3F83F8]'
  }, {
    id: 6,
    number: 15,
    clientName: 'Michael Chang',
    clientType: 'New',
    time: '07:20',
    duration: '60min',
    service: 'FULL SET ACRYLIC',
    technician: 'THOR',
    techColor: 'bg-[#3C78D8]'
  }, {
    id: 7,
    number: 18,
    clientName: 'Jessica Kim',
    clientType: 'Reward',
    time: '07:25',
    duration: '35min',
    service: 'POLISH CHANGE',
    technician: 'TIM',
    techColor: 'bg-white'
  }, {
    id: 8,
    number: 21,
    clientName: 'David Patel',
    clientType: 'VIP',
    time: '07:30',
    duration: '90min',
    service: 'SPA PEDICURE, GEL MANICURE',
    technician: 'SEAN',
    techColor: 'bg-[#9B5DE5]'
  }, {
    id: 9,
    number: 24,
    clientName: 'Emma Wilson',
    clientType: 'Reward',
    time: '07:35',
    duration: '40min',
    service: 'NAIL REPAIR',
    technician: 'JENNY',
    techColor: 'bg-[#9B5DE5]'
  }, {
    id: 10,
    number: 27,
    clientName: 'Robert Garcia',
    clientType: 'New',
    time: '07:40',
    duration: '55min',
    service: 'DIPPING POWDER',
    technician: 'JULIE',
    techColor: 'bg-[#E5565B]'
  }, {
    id: 11,
    number: 30,
    clientName: 'Michelle Lee',
    clientType: 'Reward',
    time: '07:45',
    duration: '75min',
    service: 'DELUXE PEDICURE, NAIL ART',
    technician: 'HANK',
    techColor: 'bg-[#E5565B]'
  }, {
    id: 12,
    number: 33,
    clientName: 'Thomas Wang',
    clientType: 'VIP',
    time: '07:50',
    duration: '25min',
    service: 'EYEBROW WAX',
    technician: 'TOM',
    techColor: 'bg-white'
  }, {
    id: 13,
    number: 36,
    clientName: 'Olivia Martinez',
    clientType: 'Reward',
    time: '07:55',
    duration: '65min',
    service: 'FRENCH MANICURE',
    technician: 'JIM',
    techColor: 'bg-[#4CC2A9]'
  }, {
    id: 14,
    number: 39,
    clientName: 'Daniel Brown',
    clientType: 'New',
    time: '08:00',
    duration: '50min',
    service: 'SPORTS MANICURE',
    technician: 'KEVIN',
    techColor: 'bg-[#3F83F8]'
  }]);
  // For testing empty state, uncomment the line below
  // const pendingTickets = [];
  // Handle ticket deletion
  const handleDeleteTicket = () => {
    if (ticketToDelete !== null && deleteReason.trim() !== '') {
      setPendingTickets(prevTickets => prevTickets.filter(ticket => ticket.id !== ticketToDelete));
      setShowDeleteModal(false);
      setTicketToDelete(null);
      setDeleteReason('');
    }
  };
  // Handle delete all tickets
  const handleDeleteAllTickets = () => {
    if (deleteAllReason.trim() !== '') {
      setPendingTickets([]);
      setShowDeleteAllModal(false);
      setDeleteAllReason('');
      setShowHeaderDropdown(false);
    }
  };
  // Toggle dropdown menu for a ticket
  const toggleDropdown = (id: number, e: React.MouseEvent) => {
    e.stopPropagation();
    setOpenDropdownId(openDropdownId === id ? null : id);
  };
  // Toggle header dropdown menu
  const toggleHeaderDropdown = (e: React.MouseEvent) => {
    e.stopPropagation();
    setShowHeaderDropdown(!showHeaderDropdown);
  };
  // Open delete confirmation modal
  const openDeleteConfirmation = (id: number, e: React.MouseEvent) => {
    e.stopPropagation();
    setTicketToDelete(id);
    setShowDeleteModal(true);
    setOpenDropdownId(null);
  };
  // Open delete all confirmation modal
  const openDeleteAllConfirmation = (e: React.MouseEvent) => {
    e.stopPropagation();
    setShowDeleteAllModal(true);
    setShowHeaderDropdown(false);
  };
  // Enhanced color mappings for more vibrant tech colors
  const techColorMap: Record<string, string> = {
    'bg-[#E5565B]': 'bg-gradient-to-r from-[#FF6B70] to-[#E04146]',
    'bg-[#3F83F8]': 'bg-gradient-to-r from-[#5A9FFF] to-[#3373E8]',
    'bg-[#4CC2A9]': 'bg-gradient-to-r from-[#5EEAD4] to-[#3BB09A]',
    'bg-[#9B5DE5]': 'bg-gradient-to-r from-[#AF6FFF] to-[#8A4AD0]',
    'bg-[#3C78D8]': 'bg-gradient-to-r from-[#4A8EFF] to-[#2A68C8]',
    'bg-white': 'bg-gradient-to-r from-gray-100 to-white text-gray-700'
  };
  // Compact ticket card component with bolder paper ticket styling
  const CompactTicketCard = ({
    ticket
  }: {
    ticket: (typeof pendingTickets)[0];
  }) => {
    return <div className="bg-[#FFF8E8] rounded-lg border-2 border-red-200 shadow-md hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1 hover:rotate-[0.5deg] group relative overflow-hidden" style={{
      backgroundImage: 'url("https://www.transparenttextures.com/patterns/paper-fibers.png")'
    }}>
        {/* Perforation marks - top */}
        <div className="absolute top-0 left-0 w-full h-[6px] overflow-hidden flex items-center">
          <div className="w-full flex justify-between px-2">
            {[...Array(12)].map((_, i) => <div key={i} className="w-1 h-1 bg-red-200 rounded-full"></div>)}
          </div>
        </div>
        {/* Left notch */}
        <div className="absolute -left-2 top-1/2 w-4 h-4 bg-gray-100 rounded-full border-r-2 border-red-200"></div>
        {/* Right notch */}
        <div className="absolute -right-2 top-1/2 w-4 h-4 bg-gray-100 rounded-full border-l-2 border-red-200"></div>
        {/* Status indicator strip */}
        <div className="absolute top-0 left-0 w-2 h-full bg-gradient-to-b from-red-400 to-red-300"></div>
        <div className="flex items-center justify-between p-2 border-b-2 border-dashed border-red-200 pl-4 pt-3">
          <div className="flex items-center">
            <div className="bg-gray-800 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold shadow-lg mr-2 transform -rotate-3 ring-1 ring-red-300">
              {ticket.number}
            </div>
            <span className="text-xs font-bold text-gray-800 truncate max-w-[100px] font-mono">
              {ticket.clientName}
            </span>
            <span className="ml-1.5 text-[10px] bg-red-100 text-red-800 px-1 py-0.5 rounded-sm border border-red-200 font-bold uppercase">
              {ticket.clientType}
            </span>
          </div>
          <div className="relative">
            <Tippy content="More options">
              <button className="text-gray-500 hover:text-gray-700 p-1 rounded-full hover:bg-red-100 transition-colors" onClick={e => toggleDropdown(ticket.id, e)}>
                <MoreVertical size={12} />
              </button>
            </Tippy>
            {openDropdownId === ticket.id && <div ref={dropdownRef} className="absolute right-0 mt-1 w-36 bg-white rounded-md shadow-lg z-10 border border-gray-200 py-1">
                <button className="w-full text-left px-3 py-1.5 text-sm text-gray-700 hover:bg-red-50 flex items-center" onClick={e => openDeleteConfirmation(ticket.id, e)}>
                  <Trash2 size={14} className="mr-2 text-red-500" />
                  Delete Ticket
                </button>
                <button className="w-full text-left px-3 py-1.5 text-sm text-gray-700 hover:bg-gray-50 flex items-center">
                  <Edit2 size={14} className="mr-2 text-blue-500" />
                  Edit Ticket
                </button>
                <button className="w-full text-left px-3 py-1.5 text-sm text-gray-700 hover:bg-gray-50 flex items-center">
                  <Info size={14} className="mr-2 text-amber-500" />
                  View Details
                </button>
              </div>}
          </div>
        </div>
        <div className="p-2 flex items-center justify-between">
          <div className="flex items-center text-[10px] text-gray-700 font-mono font-semibold">
            <Clock size={10} className="text-red-500 mr-0.5" />
            {ticket.time}
          </div>
          {ticket.technician && <div className={`${techColorMap[ticket.techColor] || ticket.techColor} text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-md`} style={{
          clipPath: 'polygon(4% 0%, 100% 0%, 96% 100%, 0% 100%)',
          paddingLeft: '8px',
          paddingRight: '8px'
        }}>
              {ticket.technician}
            </div>}
        </div>
        {/* Paper texture overlay */}
        <div className="absolute inset-0 pointer-events-none opacity-10 mix-blend-overlay" style={{
        backgroundImage: 'url("https://www.transparenttextures.com/patterns/cardboard.png")'
      }}></div>
        {/* "Pending" stamp effect */}
        <div className="absolute top-0 right-0 transform rotate-12 opacity-10">
          <div className="w-16 h-16 rounded-full border-4 border-red-600 flex items-center justify-center">
            <span className="text-red-600 font-bold text-sm">PENDING</span>
          </div>
        </div>
      </div>;
  };
  // Delete confirmation modal component
  const DeleteConfirmationModal = () => {
    if (!showDeleteModal) return null;
    const ticket = pendingTickets.find(t => t.id === ticketToDelete);
    if (!ticket) return null;
    return <>
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50" onClick={() => setShowDeleteModal(false)}></div>
        <div className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white rounded-lg shadow-xl z-50 w-11/12 max-w-md overflow-hidden">
          <div className="bg-red-50 p-4 border-b border-red-100">
            <div className="flex items-center">
              <div className="bg-red-500 p-2 rounded-full text-white mr-3">
                <Trash2 size={20} />
              </div>
              <h3 className="text-lg font-bold text-gray-800">Delete Ticket</h3>
            </div>
          </div>
          <div className="p-4">
            <div className="mb-4">
              <p className="text-gray-700 mb-2">
                You are about to delete the following ticket:
              </p>
              <div className="bg-[#FFFCF7] p-3 rounded-md border border-gray-200 relative overflow-hidden" style={{
              backgroundImage: 'url("https://www.transparenttextures.com/patterns/subtle-white-feathers.png")',
              backgroundBlendMode: 'overlay'
            }}>
                <div className="flex items-center mb-1">
                  <span className="font-semibold text-gray-800 mr-2 font-mono">
                    #{ticket.number}
                  </span>
                  <span className="text-gray-700 font-mono">
                    {ticket.clientName}
                  </span>
                </div>
                <div className="text-sm text-gray-600 font-mono">
                  {ticket.service}
                </div>
                {/* Paper texture overlay */}
                <div className="absolute inset-0 pointer-events-none opacity-5 mix-blend-overlay" style={{
                backgroundImage: 'url("https://www.transparenttextures.com/patterns/rice-paper.png")'
              }}></div>
              </div>
            </div>
            <div className="mb-4">
              <label htmlFor="deleteReason" className="block text-sm font-medium text-gray-700 mb-1">
                Reason for deletion <span className="text-red-500">*</span>
              </label>
              <select id="deleteReason" className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-red-500 focus:border-red-500" value={deleteReason} onChange={e => setDeleteReason(e.target.value)} required>
                <option value="">Select a reason</option>
                <option value="client_no_show">Client No-Show</option>
                <option value="client_cancelled">Client Cancelled</option>
                <option value="duplicate_entry">Duplicate Entry</option>
                <option value="tech_unavailable">Technician Unavailable</option>
                <option value="scheduling_error">Scheduling Error</option>
                <option value="other">Other</option>
              </select>
              {deleteReason === '' && <p className="text-sm text-red-500 mt-1">
                  Please select a reason for deletion
                </p>}
            </div>
            {deleteReason === 'other' && <div className="mb-4">
                <label htmlFor="otherReason" className="block text-sm font-medium text-gray-700 mb-1">
                  Please specify
                </label>
                <textarea id="otherReason" className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-red-500 focus:border-red-500" rows={2} placeholder="Enter reason..."></textarea>
              </div>}
            <div className="flex justify-end space-x-2 mt-4">
              <button className="px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 transition-colors" onClick={() => setShowDeleteModal(false)}>
                Cancel
              </button>
              <button className={`px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors ${deleteReason === '' ? 'opacity-50 cursor-not-allowed' : ''}`} onClick={handleDeleteTicket} disabled={deleteReason === ''}>
                Delete Ticket
              </button>
            </div>
          </div>
        </div>
      </>;
  };
  // Delete all confirmation modal component
  const DeleteAllConfirmationModal = () => {
    if (!showDeleteAllModal) return null;
    return <>
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50" onClick={() => setShowDeleteAllModal(false)}></div>
        <div className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white rounded-lg shadow-xl z-50 w-11/12 max-w-md overflow-hidden">
          <div className="bg-red-50 p-4 border-b border-red-100">
            <div className="flex items-center">
              <div className="bg-red-500 p-2 rounded-full text-white mr-3">
                <Trash2 size={20} />
              </div>
              <h3 className="text-lg font-bold text-gray-800">
                Delete All Tickets
              </h3>
            </div>
          </div>
          <div className="p-4">
            <div className="mb-4">
              <p className="text-gray-700 mb-2">
                You are about to delete{' '}
                <span className="font-bold text-red-600">
                  all {pendingTickets.length} pending tickets
                </span>
                . This action cannot be undone.
              </p>
              <div className="bg-red-50 p-3 rounded-md border border-red-200 mt-2">
                <div className="flex items-center text-red-700">
                  <AlertCircle size={16} className="mr-2 flex-shrink-0" />
                  <span className="text-sm font-medium">
                    This will remove all tickets from the pending list.
                  </span>
                </div>
              </div>
            </div>
            <div className="mb-4">
              <label htmlFor="deleteAllReason" className="block text-sm font-medium text-gray-700 mb-1">
                Reason for deletion <span className="text-red-500">*</span>
              </label>
              <select id="deleteAllReason" className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-red-500 focus:border-red-500" value={deleteAllReason} onChange={e => setDeleteAllReason(e.target.value)} required>
                <option value="">Select a reason</option>
                <option value="end_of_day">End of Day Cleanup</option>
                <option value="system_reset">System Reset</option>
                <option value="data_correction">Data Correction</option>
                <option value="other">Other</option>
              </select>
              {deleteAllReason === '' && <p className="text-sm text-red-500 mt-1">
                  Please select a reason for deletion
                </p>}
            </div>
            {deleteAllReason === 'other' && <div className="mb-4">
                <label htmlFor="otherAllReason" className="block text-sm font-medium text-gray-700 mb-1">
                  Please specify
                </label>
                <textarea id="otherAllReason" className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-red-500 focus:border-red-500" rows={2} placeholder="Enter reason..."></textarea>
              </div>}
            <div className="flex justify-end space-x-2 mt-4">
              <button className="px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 transition-colors" onClick={() => setShowDeleteAllModal(false)}>
                Cancel
              </button>
              <button className={`px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors ${deleteAllReason === '' ? 'opacity-50 cursor-not-allowed' : ''}`} onClick={handleDeleteAllTickets} disabled={deleteAllReason === ''}>
                Delete All Tickets
              </button>
            </div>
          </div>
        </div>
      </>;
  };
  if (isMinimized) {
    return <div className="bg-white rounded-lg shadow-md border border-gray-200 overflow-hidden h-full">
        <div className="flex items-center justify-between px-3 py-2.5 bg-gradient-to-r from-amber-50 to-orange-50 border-b border-gray-200">
          <div className="flex items-center">
            <div className="bg-amber-500 p-1.5 rounded-md shadow-md mr-2 text-white">
              <AlertTriangle size={16} />
            </div>
            <h2 className="text-base font-bold text-gray-700">
              Pending Tickets
            </h2>
            <div className="ml-2 bg-red-500 text-white text-xs px-2 py-1 rounded-full shadow-md">
              {pendingTickets.length}
            </div>
          </div>
          <div className="flex items-center space-x-1">
            {/* More Options dropdown */}
            <div className="relative" ref={headerDropdownRef}>
              <Tippy content="More options">
                <button className="p-1.5 rounded-md text-gray-500 hover:text-amber-600 hover:bg-amber-50 transition-all duration-200 transform hover:scale-105 active:scale-95" onClick={toggleHeaderDropdown}>
                  <MoreVertical size={16} />
                </button>
              </Tippy>
              {showHeaderDropdown && <div className="absolute right-0 mt-1 w-48 bg-white rounded-md shadow-lg z-10 border border-gray-200 py-1">
                  <button className="w-full text-left px-3 py-2 text-sm text-gray-700 hover:bg-red-50 flex items-center" onClick={openDeleteAllConfirmation}>
                    <Trash2 size={14} className="mr-2 text-red-500" />
                    Delete All Tickets
                  </button>
                </div>}
            </div>
            <Tippy content="Expand section">
              <button className="p-1.5 rounded-md text-gray-500 hover:text-amber-600 hover:bg-amber-50 transition-all duration-200 transform hover:scale-105 active:scale-95" onClick={onToggleMinimize}>
                <Maximize2 size={16} />
              </button>
            </Tippy>
          </div>
        </div>
        {/* Only show tickets section if there are tickets */}
        {pendingTickets.length > 0 && <div className="px-3 py-2 overflow-x-auto">
            <div className="flex space-x-2 pb-1">
              {pendingTickets.slice(0, 10).map(ticket => <div key={ticket.id} className="flex-shrink-0 bg-[#FFFCF7] rounded-lg border border-red-100 shadow-sm hover:shadow-md transition-all duration-200 transform hover:-translate-y-0.5 group relative overflow-hidden" style={{
            width: '180px',
            backgroundImage: 'url("https://www.transparenttextures.com/patterns/subtle-white-feathers.png")',
            backgroundBlendMode: 'overlay'
          }}>
                  {/* Left notch */}
                  <div className="absolute -left-1.5 top-1/2 w-3 h-3 bg-gray-100 rounded-full border-r border-gray-200"></div>
                  {/* Right notch */}
                  <div className="absolute -right-1.5 top-1/2 w-3 h-3 bg-gray-100 rounded-full border-l border-gray-200"></div>
                  {/* Status indicator strip */}
                  <div className="absolute top-0 left-0 w-1 h-full bg-red-300"></div>
                  <div className="flex items-center justify-between p-2 border-b border-dashed border-red-100 pl-3">
                    <div className="flex items-center">
                      <div className="bg-gray-700 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold shadow-sm transform -rotate-2">
                        {ticket.number}
                      </div>
                      <span className="ml-1.5 text-xs font-medium text-gray-700 truncate max-w-[90px] font-mono">
                        {ticket.clientName}
                      </span>
                    </div>
                    <div className="relative">
                      <Tippy content="More options">
                        <button className="text-gray-400 hover:text-gray-600 p-1 rounded-full hover:bg-red-50 transition-colors" onClick={e => toggleDropdown(ticket.id, e)}>
                          <MoreVertical size={12} />
                        </button>
                      </Tippy>
                      {openDropdownId === ticket.id && <div ref={dropdownRef} className="absolute right-0 mt-1 w-36 bg-white rounded-md shadow-lg z-10 border border-gray-200 py-1">
                          <button className="w-full text-left px-3 py-1.5 text-sm text-gray-700 hover:bg-red-50 flex items-center" onClick={e => openDeleteConfirmation(ticket.id, e)}>
                            <Trash2 size={14} className="mr-2 text-red-500" />
                            Delete Ticket
                          </button>
                          <button className="w-full text-left px-3 py-1.5 text-sm text-gray-700 hover:bg-gray-50 flex items-center">
                            <Edit2 size={14} className="mr-2 text-blue-500" />
                            Edit Ticket
                          </button>
                          <button className="w-full text-left px-3 py-1.5 text-sm text-gray-700 hover:bg-gray-50 flex items-center">
                            <Info size={14} className="mr-2 text-amber-500" />
                            View Details
                          </button>
                        </div>}
                    </div>
                  </div>
                  <div className="p-1.5 flex items-center justify-between">
                    <div className="text-[10px] truncate max-w-[110px] text-gray-600 font-mono">
                      {ticket.service}
                    </div>
                    {ticket.technician && <div className={`${techColorMap[ticket.techColor] || ticket.techColor} text-white text-[10px] px-1.5 py-0.5 rounded-full shadow-sm`} style={{
                clipPath: 'polygon(5% 0%, 100% 0%, 95% 100%, 0% 100%)',
                paddingLeft: '8px',
                paddingRight: '8px'
              }}>
                        {ticket.technician}
                      </div>}
                  </div>
                  {/* Paper texture overlay */}
                  <div className="absolute inset-0 pointer-events-none opacity-5 mix-blend-overlay" style={{
              backgroundImage: 'url("https://www.transparenttextures.com/patterns/rice-paper.png")'
            }}></div>
                </div>)}
              {pendingTickets.length > 10 && <div className="flex items-center justify-center flex-shrink-0 w-10 h-full">
                  <Tippy content="Show more tickets">
                    <button className="p-1 rounded-full bg-amber-100 text-amber-700 hover:bg-amber-200 transition-all duration-200" onClick={onToggleMinimize}>
                      <ChevronRight size={16} />
                    </button>
                  </Tippy>
                </div>}
            </div>
          </div>}
        {/* If no tickets, show an empty state message */}
        {pendingTickets.length === 0 && <div className="px-3 py-2 text-center">
            <p className="text-xs text-gray-500">No pending tickets</p>
          </div>}
        {/* Delete Confirmation Modal */}
        <DeleteConfirmationModal />
        {/* Delete All Confirmation Modal */}
        <DeleteAllConfirmationModal />
      </div>;
  }
  return <div className="h-full flex flex-col max-h-[40vh]">
      {/* Full view for pending tickets */}
      <div className={`flex items-center justify-between px-3 py-3 bg-gradient-to-r from-amber-50 to-orange-50 border-b border-gray-200 sticky top-0 z-10`}>
        <div className="flex items-center">
          <div className="bg-amber-500 p-2 rounded-md shadow-md mr-2 text-white">
            <AlertTriangle size={18} strokeWidth={2.5} />
          </div>
          <h2 className="text-base font-bold text-gray-700">Pending Tickets</h2>
          <div className="ml-2 bg-red-500 text-white text-xs px-2.5 py-1 rounded-full shadow-md">
            {pendingTickets.length}
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <Tippy content={getViewModeLabel()}>
            <button className="p-2 rounded-md text-gray-500 hover:text-amber-600 hover:bg-amber-50 transition-all duration-200 transform hover:scale-105 active:scale-95 touch-manipulation" onClick={toggleCardViewMode}>
              {getViewModeIcon()}
            </button>
          </Tippy>
          {/* More Options dropdown */}
          <div className="relative" ref={headerDropdownRef}>
            <Tippy content="More options">
              <button className="p-2 rounded-md text-gray-500 hover:text-amber-600 hover:bg-amber-50 transition-all duration-200 transform hover:scale-105 active:scale-95 touch-manipulation" onClick={toggleHeaderDropdown}>
                <MoreVertical size={18} strokeWidth={2.5} />
              </button>
            </Tippy>
            {showHeaderDropdown && <div className="absolute right-0 mt-1 w-48 bg-white rounded-md shadow-lg z-10 border border-gray-200 py-1">
                <button className="w-full text-left px-4 py-3 text-sm text-gray-700 hover:bg-red-50 flex items-center touch-manipulation" onClick={openDeleteAllConfirmation}>
                  <Trash2 size={16} strokeWidth={2.5} className="mr-2 text-red-500" />
                  Delete All Tickets
                </button>
              </div>}
          </div>
          <Tippy content="Minimize section">
            <button className="p-2 rounded-md text-gray-500 hover:text-amber-600 hover:bg-amber-50 transition-all duration-200 transform hover:scale-105 active:scale-95 touch-manipulation" onClick={onToggleMinimize}>
              <Minimize2 size={18} strokeWidth={2.5} />
            </button>
          </Tippy>
        </div>
      </div>
      <div className="flex-1 overflow-auto p-3">
        {pendingTickets.length > 0 ? cardViewMode === 'compact' ?
      // Compact view - optimized for mobile
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-3">
              {pendingTickets.map(ticket => <CompactTicketCard key={ticket.id} ticket={ticket} />)}
            </div> :
      // Normal view with bolder paper ticket styling
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
              {pendingTickets.map(ticket => <div key={ticket.id} className="bg-[#FFF8E8] rounded-lg overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 hover:rotate-[0.5deg] group h-full touch-manipulation relative border-2 border-red-200 shadow-md" style={{
          backgroundImage: 'url("https://www.transparenttextures.com/patterns/paper-fibers.png")'
        }}>
                  {/* Perforation marks - top */}
                  <div className="absolute top-0 left-0 w-full h-[6px] overflow-hidden flex items-center">
                    <div className="w-full flex justify-between px-4">
                      {[...Array(20)].map((_, i) => <div key={i} className="w-1 h-1 bg-red-200 rounded-full"></div>)}
                    </div>
                  </div>
                  {/* Left ticket notch */}
                  <div className="absolute -left-3 top-1/3 w-6 h-6 bg-gray-100 rounded-full border-r-2 border-red-200"></div>
                  {/* Right ticket notch */}
                  <div className="absolute -right-3 top-1/3 w-6 h-6 bg-gray-100 rounded-full border-l-2 border-red-200"></div>
                  {/* Status indicator strip */}
                  <div className="absolute top-0 left-0 w-2 h-full bg-gradient-to-b from-red-400 to-red-300"></div>
                  {/* Card header with number and client type */}
                  <div className="flex justify-between p-3 border-b-2 border-dashed border-red-200 pl-5 pt-4">
                    <div className="flex items-center">
                      <div className="bg-gray-800 text-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold shadow-lg mr-2 transform -rotate-3 ring-2 ring-red-300">
                        {ticket.number}
                      </div>
                      <div className="ml-2 text-xs bg-red-100 text-red-800 font-bold px-2 py-1 rounded-md shadow-md border border-red-200 uppercase tracking-wide">
                        {ticket.clientType}
                      </div>
                    </div>
                    <div className="relative">
                      <Tippy content="More options">
                        <button className="text-gray-500 hover:text-gray-700 p-2 rounded-full hover:bg-red-100 transition-colors touch-manipulation" onClick={e => toggleDropdown(ticket.id, e)}>
                          <MoreVertical size={16} strokeWidth={2.5} />
                        </button>
                      </Tippy>
                      {openDropdownId === ticket.id && <div ref={dropdownRef} className="absolute right-0 mt-1 w-40 bg-white rounded-md shadow-lg z-10 border border-gray-200 py-1">
                          <button className="w-full text-left px-4 py-3 text-sm text-gray-700 hover:bg-red-50 flex items-center touch-manipulation" onClick={e => openDeleteConfirmation(ticket.id, e)}>
                            <Trash2 size={16} strokeWidth={2.5} className="mr-2 text-red-500" />
                            Delete Ticket
                          </button>
                          <button className="w-full text-left px-4 py-3 text-sm text-gray-700 hover:bg-gray-50 flex items-center touch-manipulation">
                            <Edit2 size={16} strokeWidth={2.5} className="mr-2 text-blue-500" />
                            Edit Ticket
                          </button>
                          <button className="w-full text-left px-4 py-3 text-sm text-gray-700 hover:bg-gray-50 flex items-center touch-manipulation">
                            <Info size={16} strokeWidth={2.5} className="mr-2 text-amber-500" />
                            View Details
                          </button>
                        </div>}
                    </div>
                  </div>
                  {/* Card content */}
                  <div className="p-3 pl-5">
                    {/* Client information */}
                    <div className="flex items-center mb-3">
                      <div className="bg-red-100 p-1.5 rounded-full mr-2 shadow-md border border-red-200">
                        <User size={16} strokeWidth={2.5} className="text-red-700" />
                      </div>
                      <div className="font-bold text-gray-800 truncate font-mono text-lg">
                        {ticket.clientName}
                      </div>
                    </div>
                    {/* Time and duration */}
                    <div className="flex items-center justify-between text-xs text-gray-700 mb-3">
                      <div className="flex items-center bg-red-50 px-2 py-1 rounded-md shadow-md border border-red-200">
                        <Calendar size={12} strokeWidth={2.5} className="text-red-700 mr-1" />
                        <span className="font-bold font-mono">
                          {ticket.time}
                        </span>
                      </div>
                      {ticket.duration && <div className="flex items-center bg-red-50 px-2 py-1 rounded-md shadow-md border border-red-200">
                          <Timer size={12} strokeWidth={2.5} className="text-red-700 mr-1" />
                          <span className="font-bold font-mono">
                            {ticket.duration}
                          </span>
                        </div>}
                    </div>
                    {/* Service information */}
                    {ticket.service && <div className="mt-2 font-bold text-sm text-gray-800 bg-[#FFF8E8] p-3 rounded-md border-l-2 border-red-300 shadow-md">
                        <div className="flex items-start">
                          <Tag size={14} strokeWidth={2.5} className="text-red-700 mr-2 mt-0.5 flex-shrink-0" />
                          <span className="line-clamp-2 font-mono">
                            {ticket.service}
                          </span>
                        </div>
                      </div>}
                  </div>
                  {/* Card footer */}
                  <div className="flex items-center justify-between border-t-2 border-dashed border-red-200 p-3 bg-[#FFF8E8] mt-auto">
                    {/* Left side - technician */}
                    {ticket.technician && <div className={`${techColorMap[ticket.techColor] || ticket.techColor} text-white text-xs font-bold px-3 py-1.5 rounded-full shadow-lg transform rotate-[0.5deg]`} style={{
              clipPath: 'polygon(4% 0%, 100% 0%, 96% 100%, 0% 100%)',
              paddingLeft: '12px',
              paddingRight: '12px'
            }}>
                        {ticket.technician}
                      </div>}
                    {/* Right side - status */}
                    <div className="text-xs font-bold bg-amber-200 text-amber-800 px-2 py-1 rounded-full shadow-md ml-auto border-2 border-amber-300 uppercase tracking-wide">
                      Pending
                    </div>
                  </div>
                  {/* Paper texture overlay */}
                  <div className="absolute inset-0 pointer-events-none opacity-10 mix-blend-overlay" style={{
            backgroundImage: 'url("https://www.transparenttextures.com/patterns/cardboard.png")'
          }}></div>
                  {/* "Pending" stamp effect */}
                  <div className="absolute top-2 right-10 transform rotate-12 opacity-10">
                    <div className="w-20 h-20 rounded-full border-4 border-red-600 flex items-center justify-center">
                      <span className="text-red-600 font-bold text-sm">
                        PENDING
                      </span>
                    </div>
                  </div>
                </div>)}
            </div> : <div className="text-sm text-gray-500 bg-gray-50 p-4 rounded-md border border-dashed border-gray-300 text-center">
            No pending tickets to display
          </div>}
      </div>
      {/* Delete Confirmation Modal - Mobile Optimized */}
      <DeleteConfirmationModal />
      {/* Delete All Confirmation Modal - Mobile Optimized */}
      <DeleteAllConfirmationModal />
    </div>;
}