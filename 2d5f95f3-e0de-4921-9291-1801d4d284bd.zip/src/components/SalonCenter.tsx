import React, { useEffect, useState, useRef } from 'react';
import { SalonHeader } from './SalonHeader';
import { StaffSidebar } from './StaffSidebar';
import { ServiceSection } from './ServiceSection';
import { WaitListSection } from './WaitListSection';
import { PendingTickets } from './PendingTickets';
import Tippy from '@tippyjs/react';
import 'tippy.js/dist/tippy.css';
import { FileText, Users, Columns, LayoutGrid, LayoutDashboard, ChevronDown, Check, ChevronUp, MoreVertical, List, Grid } from 'lucide-react';
export function SalonCenter() {
  const [activeTab, setActiveTab] = useState('salonCenter');
  const [showSidebar, setShowSidebar] = useState(false);
  const [minimizedSections, setMinimizedSections] = useState({
    service: false,
    waitList: false,
    pendingTickets: true
  });
  // Enhanced device detection with orientation
  const [deviceInfo, setDeviceInfo] = useState({
    isMobile: false,
    isTablet: false,
    isPortrait: false,
    isDesktop: false
  });
  // New state for combined view
  const [isCombinedView, setIsCombinedView] = useState(() => {
    // Default to column view on desktop, tabs on mobile/tablet
    const savedView = localStorage.getItem('salonCenterViewMode');
    // If we have a saved preference and we're on desktop, use it
    if (savedView && window.matchMedia('(min-width: 1024px)').matches) {
      return savedView === 'combined';
    }
    // Default to column view (not combined) for desktop
    return false;
  });
  // New state for mobile/tablet section tabs
  const [activeMobileSection, setActiveMobileSection] = useState(() => {
    const saved = localStorage.getItem('activeMobileSection');
    return saved || 'waitList'; // Default to waitList for tablet
  });
  // New state for active tab in combined view - changed default to 'service'
  const [activeCombinedTab, setActiveCombinedTab] = useState(() => {
    const saved = localStorage.getItem('activeCombinedTab');
    return saved || 'service';
  });
  // New states for shared view settings when combined
  const [combinedViewMode, setCombinedViewMode] = useState<'grid' | 'list'>(() => {
    const saved = localStorage.getItem('combinedViewMode');
    return saved === 'grid' || saved === 'list' ? saved as 'grid' | 'list' : 'list';
  });
  const [combinedCardViewMode, setCombinedCardViewMode] = useState<'normal' | 'compact'>(() => {
    const saved = localStorage.getItem('combinedCardViewMode');
    return saved === 'normal' || saved === 'compact' ? saved as 'normal' | 'compact' : 'normal';
  });
  const [combinedMinimizedLineView, setCombinedMinimizedLineView] = useState<boolean>(() => {
    const saved = localStorage.getItem('combinedMinimizedLineView');
    return saved === 'true' ? true : false;
  });
  // State for dropdown menus
  const [showServiceDropdown, setShowServiceDropdown] = useState(false);
  const [showWaitListDropdown, setShowWaitListDropdown] = useState(false);
  const serviceDropdownRef = useRef<HTMLDivElement>(null);
  const waitListDropdownRef = useRef<HTMLDivElement>(null);
  // Add state for Wait List tab dropdown
  const [waitListTabDropdownOpen, setWaitListTabDropdownOpen] = useState(false);
  // Toggle Wait List tab dropdown - fixed to not expect event parameter
  const toggleWaitListTabDropdown = () => {
    setWaitListTabDropdownOpen(!waitListTabDropdownOpen);
  };
  // Save active mobile section to localStorage when it changes
  useEffect(() => {
    localStorage.setItem('activeMobileSection', activeMobileSection);
  }, [activeMobileSection]);
  // Save active combined tab to localStorage when it changes
  useEffect(() => {
    localStorage.setItem('activeCombinedTab', activeCombinedTab);
  }, [activeCombinedTab]);
  // Close dropdowns when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (serviceDropdownRef.current && !serviceDropdownRef.current.contains(event.target as Node)) {
        setShowServiceDropdown(false);
      }
      if (waitListDropdownRef.current && !waitListDropdownRef.current.contains(event.target as Node)) {
        setShowWaitListDropdown(false);
      }
      // Close Wait List tab dropdown when clicking outside
      if (waitListTabDropdownOpen && !(event.target as Element).closest('.wait-list-tab-dropdown-container')) {
        setWaitListTabDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [waitListTabDropdownOpen, showServiceDropdown, showWaitListDropdown]);
  // Toggle card view mode with persistence
  const toggleCombinedCardViewMode = () => {
    const newMode = combinedCardViewMode === 'normal' ? 'compact' : 'normal';
    setCombinedCardViewMode(newMode);
    localStorage.setItem('combinedCardViewMode', newMode);
    // Also update section-specific settings for consistency
    if (activeCombinedTab === 'service') {
      localStorage.setItem('serviceCardViewMode', newMode);
    } else if (['waitList', 'walkIn', 'appt'].includes(activeCombinedTab)) {
      localStorage.setItem('waitListCardViewMode', newMode);
    }
  };
  // Toggle minimized line view with persistence
  const toggleCombinedMinimizedLineView = () => {
    const newValue = !combinedMinimizedLineView;
    setCombinedMinimizedLineView(newValue);
    localStorage.setItem('combinedMinimizedLineView', newValue.toString());
    // Also update section-specific settings for consistency
    if (activeCombinedTab === 'service') {
      localStorage.setItem('serviceMinimizedLineView', newValue.toString());
    } else if (['waitList', 'walkIn', 'appt'].includes(activeCombinedTab)) {
      localStorage.setItem('waitListMinimizedLineView', newValue.toString());
    }
  };
  // Save combined view settings to localStorage when they change
  useEffect(() => {
    localStorage.setItem('combinedViewMode', combinedViewMode);
    // Also update section-specific settings for consistency
    if (activeCombinedTab === 'service') {
      localStorage.setItem('serviceViewMode', combinedViewMode);
    } else if (['waitList', 'walkIn', 'appt'].includes(activeCombinedTab)) {
      localStorage.setItem('waitListViewMode', combinedViewMode);
    }
  }, [combinedViewMode, activeCombinedTab]);
  // Sync view mode settings when active combined tab changes
  useEffect(() => {
    if (isCombinedView) {
      if (activeCombinedTab === 'service') {
        // Load service-specific settings
        const viewMode = localStorage.getItem('serviceViewMode');
        const cardViewMode = localStorage.getItem('serviceCardViewMode');
        const minimizedLineView = localStorage.getItem('serviceMinimizedLineView');
        if (viewMode === 'grid' || viewMode === 'list') {
          setCombinedViewMode(viewMode);
        }
        if (cardViewMode === 'normal' || cardViewMode === 'compact') {
          setCombinedCardViewMode(cardViewMode as 'normal' | 'compact');
        }
        if (minimizedLineView === 'true' || minimizedLineView === 'false') {
          setCombinedMinimizedLineView(minimizedLineView === 'true');
        }
      } else if (['waitList', 'walkIn', 'appt'].includes(activeCombinedTab)) {
        // Load waitlist-specific settings
        const viewMode = localStorage.getItem('waitListViewMode');
        const cardViewMode = localStorage.getItem('waitListCardViewMode');
        const minimizedLineView = localStorage.getItem('waitListMinimizedLineView');
        if (viewMode === 'grid' || viewMode === 'list') {
          setCombinedViewMode(viewMode);
        }
        if (cardViewMode === 'normal' || cardViewMode === 'compact') {
          setCombinedCardViewMode(cardViewMode as 'normal' | 'compact');
        }
        if (minimizedLineView === 'true' || minimizedLineView === 'false') {
          setCombinedMinimizedLineView(minimizedLineView === 'true');
        }
      }
    }
  }, [activeCombinedTab, isCombinedView]);
  // Enhanced device detection with orientation
  useEffect(() => {
    const checkDeviceInfo = () => {
      const mobileQuery = window.matchMedia('(max-width: 767px)');
      const tabletQuery = window.matchMedia('(min-width: 768px) and (max-width: 1023px)');
      const desktopQuery = window.matchMedia('(min-width: 1024px)');
      const portraitQuery = window.matchMedia('(orientation: portrait)');
      const isMobile = mobileQuery.matches;
      const isTablet = tabletQuery.matches;
      const isPortrait = portraitQuery.matches;
      const isDesktop = desktopQuery.matches;
      setDeviceInfo({
        isMobile,
        isTablet,
        isPortrait,
        isDesktop
      });
      // Automatically set view mode based on device
      if (isMobile || isTablet) {
        // Force Tabs view on mobile/tablet
        setIsCombinedView(true);
      } else if (isDesktop) {
        // On desktop, restore user preference or default to Column view
        const savedView = localStorage.getItem('salonCenterViewMode');
        if (savedView) {
          setIsCombinedView(savedView === 'combined');
        } else {
          // Default to Column view (not combined) for desktop
          setIsCombinedView(false);
        }
      }
    };
    // Initial check
    checkDeviceInfo();
    // Add event listeners for window resize and orientation change
    window.addEventListener('resize', checkDeviceInfo);
    window.addEventListener('orientationchange', checkDeviceInfo);
    // Clean up
    return () => {
      window.removeEventListener('resize', checkDeviceInfo);
      window.removeEventListener('orientationchange', checkDeviceInfo);
    };
  }, []);
  // Auto-minimize sections on mobile and tablet for better UX
  useEffect(() => {
    if (deviceInfo.isMobile || deviceInfo.isTablet) {
      setMinimizedSections(prev => ({
        ...prev,
        service: activeMobileSection !== 'service',
        waitList: activeMobileSection !== 'waitList',
        pendingTickets: true // Always keep pending tickets minimized on mobile/tablet
      }));
    }
  }, [deviceInfo.isMobile, deviceInfo.isTablet, activeMobileSection]);
  const toggleSectionMinimize = (section: 'service' | 'waitList' | 'pendingTickets') => {
    // On mobile or tablet, minimize other sections when opening one
    if ((deviceInfo.isMobile || deviceInfo.isTablet) && !minimizedSections[section]) {
      if (section === 'pendingTickets') {
        // Only toggle pendingTickets without affecting other sections on mobile/tablet
        setMinimizedSections(prev => ({
          ...prev,
          pendingTickets: !prev.pendingTickets
        }));
      } else {
        setMinimizedSections(prev => ({
          ...prev,
          service: section !== 'service',
          waitList: section !== 'waitList',
          // Keep pendingTickets minimized on mobile/tablet
          pendingTickets: prev.pendingTickets
        }));
        // Also update the active mobile section to match
        setActiveMobileSection(section);
      }
    } else {
      setMinimizedSections(prev => ({
        ...prev,
        [section]: !prev[section]
      }));
    }
  };
  // Toggle combined view - enhanced to save preference and preserve view settings
  const toggleCombinedView = () => {
    const newValue = !isCombinedView;
    setIsCombinedView(newValue);
    // Only save preference on desktop
    if (deviceInfo.isDesktop) {
      localStorage.setItem('salonCenterViewMode', newValue ? 'combined' : 'column');
    }
    // When switching to combined view, sync the view settings for the active tab
    if (newValue) {
      // Load the appropriate section's view settings for the active tab
      if (activeCombinedTab === 'service') {
        // Use service section settings
        const viewMode = localStorage.getItem('serviceViewMode');
        const cardViewMode = localStorage.getItem('serviceCardViewMode');
        const minimizedLineView = localStorage.getItem('serviceMinimizedLineView');
        if (viewMode === 'grid' || viewMode === 'list') {
          setCombinedViewMode(viewMode);
        }
        if (cardViewMode === 'normal' || cardViewMode === 'compact') {
          setCombinedCardViewMode(cardViewMode as 'normal' | 'compact');
        }
        if (minimizedLineView === 'true' || minimizedLineView === 'false') {
          setCombinedMinimizedLineView(minimizedLineView === 'true');
        }
      } else if (['waitList', 'walkIn', 'appt'].includes(activeCombinedTab)) {
        // Use waitlist section settings
        const viewMode = localStorage.getItem('waitListViewMode');
        const cardViewMode = localStorage.getItem('waitListCardViewMode');
        const minimizedLineView = localStorage.getItem('waitListMinimizedLineView');
        if (viewMode === 'grid' || viewMode === 'list') {
          setCombinedViewMode(viewMode);
        }
        if (cardViewMode === 'normal' || cardViewMode === 'compact') {
          setCombinedCardViewMode(cardViewMode as 'normal' | 'compact');
        }
        if (minimizedLineView === 'true' || minimizedLineView === 'false') {
          setCombinedMinimizedLineView(minimizedLineView === 'true');
        }
      }
    }
  };
  // Mobile/tablet section tabs configuration
  const mobileSectionTabs = [{
    id: 'service',
    label: 'In Service',
    icon: <FileText size={16} className="mr-1" />,
    count: 7
  }, {
    id: 'waitList',
    label: 'Wait List',
    icon: <Users size={16} className="mr-1" />,
    count: 2
  }];
  // Combined view tabs - reordered to put In Service first
  const combinedTabs = [{
    id: 'service',
    label: 'In Service',
    icon: <FileText size={16} className="mr-1" />,
    count: 7
  }, {
    id: 'waitList',
    label: 'Wait List',
    icon: <Users size={16} className="mr-1" />,
    count: 2
  }];
  return <div className="flex flex-col h-screen bg-gray-50">
      <SalonHeader activeTab={activeTab} setActiveTab={setActiveTab} showSidebar={showSidebar} setShowSidebar={setShowSidebar} />
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar with improved mobile handling */}
        <div className={`${showSidebar ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0 fixed md:relative z-30 h-[calc(100vh-60px)] transition-transform duration-300 ease-in-out`}>
          <StaffSidebar />
        </div>
        {/* Overlay for mobile sidebar */}
        {showSidebar && <div className="fixed inset-0 bg-black bg-opacity-50 z-20 md:hidden" onClick={() => setShowSidebar(false)}></div>}
        {/* Enhanced visual separator between tech and service sections */}
        <div className="hidden md:block w-[3px] bg-gradient-to-r from-[#E2D9DC] to-[#D4C8CC] shadow-[2px_0_6px_rgba(0,0,0,0.04)] relative">
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#D4C8CC]/40 to-transparent opacity-70"></div>
          <div className="absolute left-0 top-0 bottom-0 w-[1px] bg-[#E2D9DC]/70"></div>
          <div className="absolute right-0 top-0 bottom-0 w-[1px] bg-[#D4C8CC]/70 shadow-[0_0_3px_rgba(0,0,0,0.03)]"></div>
        </div>
        {/* Main content area with flex layout for optimal space usage */}
        <div className="flex-1 flex flex-col h-full overflow-hidden bg-white">
          {/* Mobile/Tablet section tabs - show on mobile and tablet when not in combined view */}
          {(deviceInfo.isMobile || deviceInfo.isTablet) && !isCombinedView && <div className="flex overflow-x-auto no-scrollbar bg-white border-b border-gray-200 shadow-sm sticky top-0 z-10 h-11 whitespace-nowrap">
              {mobileSectionTabs.map(tab => <button key={tab.id} className={`inline-flex items-center h-8 min-w-[88px] px-3 text-xs font-medium whitespace-nowrap transition-colors ${activeMobileSection === tab.id ? 'text-[#00D0E0] border-b-2 border-[#00D0E0]' : 'text-gray-500 hover:text-gray-700'}`} onClick={() => setActiveMobileSection(tab.id)}>
                  {tab.icon}
                  <span className="truncate">{tab.label}</span>
                  <span className={`ml-1.5 ${activeMobileSection === tab.id ? 'bg-[#00D0E0]/10 text-[#00D0E0]' : 'bg-gray-100 text-gray-600'} text-xs px-1.5 py-0.5 rounded-full`}>
                    {tab.count}
                  </span>
                </button>)}
              {/* Toggle combined view button for mobile */}
              <Tippy content="Combine sections">
                <button className="inline-flex items-center justify-center h-10 w-10 text-sm font-medium whitespace-nowrap text-gray-500 hover:text-[#00D0E0] hover:bg-gray-50 ml-3 opacity-80 hover:opacity-100" onClick={toggleCombinedView} aria-label="Combine sections">
                  <LayoutGrid size={20} />
                </button>
              </Tippy>
            </div>}

          {/* Combined view tabs - styled to match the design */}
          {isCombinedView && <div className="flex items-center justify-between bg-white border-b border-gray-200 shadow-sm sticky top-0 z-10 h-11 md:h-auto">
              <div className="flex overflow-x-auto no-scrollbar whitespace-nowrap">
                {/* Service Tab with enhanced active state */}
                <button key="service" className={`inline-flex items-center h-8 min-w-[88px] px-3 text-xs font-medium whitespace-nowrap transition-all duration-200 relative ${activeCombinedTab === 'service' ? 'bg-gradient-to-r from-gray-100 to-gray-200 text-gray-800 shadow-inner font-bold scale-[1.02] border-b-[3px] border-gray-800' : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'}`} onClick={() => setActiveCombinedTab('service')} role="tab" aria-selected={activeCombinedTab === 'service'} aria-controls="service-panel" id="service-tab">
                  <div className={`mr-2 p-1 rounded-md shadow-md ${activeCombinedTab === 'service' ? 'bg-gray-800 ring-1 ring-gray-300 ring-offset-1' : 'bg-gray-500'}`}>
                    <FileText size={14} className="text-white" />
                  </div>
                  <span className={`truncate ${activeCombinedTab === 'service' ? 'tracking-wide' : ''}`}>
                    In Service
                  </span>
                  <div className={`ml-1.5 ${activeCombinedTab === 'service' ? 'bg-gray-800 ring-1 ring-gray-300' : 'bg-gray-500'} text-white text-xs px-2 py-1 rounded-full shadow-md`}>
                    7
                  </div>
                  {/* Active indicator line - only visible when active */}
                  {activeCombinedTab === 'service' && <div className="absolute bottom-0 left-0 w-full h-1 bg-gray-800 rounded-t-md hidden sm:block"></div>}
                </button>
                {/* Wait List Tab with dropdown for Walk-In and Appt */}
                <div className="flex items-center relative wait-list-tab-dropdown-container">
                  {/* Wait List Tab */}
                  <button key="waitList" className={`inline-flex items-center h-8 min-w-[88px] px-3 text-xs font-medium whitespace-nowrap transition-all duration-200 relative ${['waitList', 'walkIn', 'appt'].includes(activeCombinedTab) ? 'bg-gradient-to-r from-[#00D0E0] to-[#22A5C9] text-white shadow-inner font-bold scale-[1.02] border-b-[3px] border-white' : 'text-gray-500 hover:text-[#00D0E0] hover:bg-[#00D0E0]/5'}`} onClick={() => setActiveCombinedTab('waitList')} role="tab" aria-selected={['waitList', 'walkIn', 'appt'].includes(activeCombinedTab)} aria-controls="waitlist-panel" id="waitlist-tab">
                    <div className={`mr-2 p-1 rounded-md shadow-md ${['waitList', 'walkIn', 'appt'].includes(activeCombinedTab) ? 'bg-white/30 ring-1 ring-white/60 ring-offset-1 ring-offset-[#00D0E0]/40' : 'bg-gray-500'}`}>
                      <Users size={14} className="text-white" />
                    </div>
                    <span className={`truncate ${['waitList', 'walkIn', 'appt'].includes(activeCombinedTab) ? 'tracking-wide' : ''}`}>
                      {activeCombinedTab === 'waitList' ? 'Wait List' : activeCombinedTab === 'walkIn' ? 'Walk-In' : activeCombinedTab === 'appt' ? 'Appt' : 'Wait List'}
                    </span>
                    <div className={`ml-1.5 ${['waitList', 'walkIn', 'appt'].includes(activeCombinedTab) ? 'bg-white text-[#00D0E0] ring-1 ring-white/60' : 'bg-gray-500 text-white'} text-xs px-2 py-1 rounded-full shadow-md`}>
                      {activeCombinedTab === 'waitList' || activeCombinedTab === 'walkIn' ? '2' : activeCombinedTab === 'appt' ? '0' : '2'}
                    </div>
                    {/* Active indicator line - only visible when active */}
                    {['waitList', 'walkIn', 'appt'].includes(activeCombinedTab) && <div className="absolute bottom-0 left-0 w-full h-1 bg-white rounded-t-md hidden sm:block"></div>}
                  </button>
                  {/* Dropdown toggle button - completely separate from main button */}
                  <button className={`inline-flex items-center justify-center h-8 w-8 rounded-md ${['waitList', 'walkIn', 'appt'].includes(activeCombinedTab) ? 'text-white hover:bg-white/20' : 'text-gray-400 hover:bg-gray-100'} transition-colors ml-1`} onClick={e => {
                e.stopPropagation();
                toggleWaitListTabDropdown();
              }} aria-label="Show more options" aria-expanded={waitListTabDropdownOpen} aria-haspopup="true">
                    <ChevronDown size={14} className={`${['waitList', 'walkIn', 'appt'].includes(activeCombinedTab) ? 'text-white' : 'text-gray-600'}`} />
                  </button>
                </div>
                {/* Dropdown menu for Wait List options - properly positioned */}
                {waitListTabDropdownOpen && <div className="absolute mt-1 w-40 bg-white rounded-md shadow-lg z-50 border border-gray-200 py-1 wait-list-dropdown" style={{
              left: '50px',
              top: '32px'
            }} role="menu" aria-labelledby="waitlist-options">
                    <button className="w-full text-left px-3 py-2 text-xs text-gray-700 hover:bg-gray-50 flex items-center" onClick={() => {
                setActiveCombinedTab('waitList');
                setWaitListTabDropdownOpen(false);
              }} role="menuitem">
                      Wait List
                      <span className="ml-1.5 bg-gray-100 text-gray-600 text-xs px-1.5 py-0.5 rounded-full">
                        2
                      </span>
                      {activeCombinedTab === 'waitList' && <Check size={12} className="ml-auto text-[#00D0E0]" />}
                    </button>
                    <button className="w-full text-left px-3 py-2 text-xs text-gray-700 hover:bg-gray-50 flex items-center" onClick={() => {
                setActiveCombinedTab('walkIn');
                setWaitListTabDropdownOpen(false);
              }} role="menuitem">
                      Walk-In
                      <span className="ml-1.5 bg-gray-100 text-gray-600 text-xs px-1.5 py-0.5 rounded-full">
                        2
                      </span>
                      {activeCombinedTab === 'walkIn' && <Check size={12} className="ml-auto text-[#00D0E0]" />}
                    </button>
                    <button className="w-full text-left px-3 py-2 text-xs text-gray-700 hover:bg-gray-50 flex items-center" onClick={() => {
                setActiveCombinedTab('appt');
                setWaitListTabDropdownOpen(false);
              }} role="menuitem">
                      Appt
                      <span className="ml-1.5 bg-gray-100 text-gray-600 text-xs px-1.5 py-0.5 rounded-full">
                        0
                      </span>
                      {activeCombinedTab === 'appt' && <Check size={12} className="ml-auto text-[#00D0E0]" />}
                    </button>
                  </div>}
              </div>
              {/* View controls - moved to the same row as tabs */}
              <div className="flex items-center space-x-1 pr-2 md:pr-3">
                {/* Minimize toggle - conditional based on view mode */}
                {combinedViewMode === 'list' ? <Tippy content={combinedMinimizedLineView ? 'Expand line view' : 'Minimize line view'}>
                    <button className="inline-flex items-center justify-center h-10 w-10 rounded-md text-gray-500 hover:text-gray-700 hover:bg-gray-100 transition-all opacity-80 hover:opacity-100" onClick={toggleCombinedMinimizedLineView} aria-label={combinedMinimizedLineView ? 'Expand line view' : 'Minimize line view'}>
                      {combinedMinimizedLineView ? <ChevronDown size={20} /> : <ChevronUp size={20} />}
                    </button>
                  </Tippy> : <Tippy content={combinedCardViewMode === 'compact' ? 'Expand card view' : 'Minimize card view'}>
                    <button className="inline-flex items-center justify-center h-10 w-10 rounded-md text-gray-500 hover:text-gray-700 hover:bg-gray-100 transition-all opacity-80 hover:opacity-100" onClick={toggleCombinedCardViewMode} aria-label={combinedCardViewMode === 'compact' ? 'Expand card view' : 'Minimize card view'}>
                      {combinedCardViewMode === 'compact' ? <ChevronDown size={20} /> : <ChevronUp size={20} />}
                    </button>
                  </Tippy>}
                {/* More options dropdown button - mobile-optimized */}
                <div className="relative md:hidden">
                  <Tippy content="View options">
                    <button className="inline-flex items-center justify-center h-10 w-10 rounded-md text-gray-500 hover:text-gray-700 hover:bg-gray-100 transition-all opacity-80 hover:opacity-100" onClick={() => activeCombinedTab === 'service' ? setShowServiceDropdown(!showServiceDropdown) : setShowWaitListDropdown(!showWaitListDropdown)} aria-label="View options" aria-haspopup="true">
                      <MoreVertical size={20} />
                    </button>
                  </Tippy>
                  {/* Combined dropdown for mobile */}
                  {(showServiceDropdown || showWaitListDropdown) && <div className="absolute right-0 mt-1 w-40 bg-white rounded-md shadow-lg z-10 border border-gray-200 py-1" ref={activeCombinedTab === 'service' ? serviceDropdownRef : waitListDropdownRef} role="menu">
                      <button className="w-full text-left px-3 py-2 text-xs text-gray-700 hover:bg-gray-50 flex items-center" onClick={() => {
                  setCombinedViewMode('list');
                  setShowServiceDropdown(false);
                  setShowWaitListDropdown(false);
                }} role="menuitem">
                        <List size={14} className="mr-2 text-gray-500" />
                        Line View
                        {combinedViewMode === 'list' && <Check size={14} className="ml-auto text-gray-500" />}
                      </button>
                      <button className="w-full text-left px-3 py-2 text-xs text-gray-700 hover:bg-gray-50 flex items-center" onClick={() => {
                  setCombinedViewMode('grid');
                  setShowServiceDropdown(false);
                  setShowWaitListDropdown(false);
                }} role="menuitem">
                        <Grid size={14} className="mr-2 text-gray-500" />
                        Grid View
                        {combinedViewMode === 'grid' && <Check size={14} className="ml-auto text-gray-500" />}
                      </button>
                    </div>}
                </div>
                {/* More options for Service tab - tablet/desktop only */}
                {activeCombinedTab === 'service' && <div className="relative hidden md:block" ref={serviceDropdownRef}>
                    <Tippy content="View options">
                      <button className="p-1.5 rounded-md text-gray-500 hover:text-gray-700 hover:bg-gray-100 transition-all" onClick={() => setShowServiceDropdown(!showServiceDropdown)} aria-expanded={showServiceDropdown} aria-haspopup="true">
                        <MoreVertical size={16} />
                      </button>
                    </Tippy>
                    {showServiceDropdown && <div className="absolute right-0 mt-1 w-48 bg-white rounded-md shadow-lg z-10 border border-gray-200 py-1" role="menu">
                        <div className="px-3 py-2 border-b border-gray-100 bg-gray-50">
                          <h3 className="text-sm font-medium text-gray-700">
                            View Options
                          </h3>
                        </div>
                        <button className="w-full text-left px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 flex items-center" onClick={() => setCombinedViewMode('list')} role="menuitem">
                          <List size={14} className="mr-2 text-gray-500" />
                          Line View
                          {combinedViewMode === 'list' && <Check size={14} className="ml-auto text-gray-500" />}
                        </button>
                        <button className="w-full text-left px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 flex items-center" onClick={() => setCombinedViewMode('grid')} role="menuitem">
                          <Grid size={14} className="mr-2 text-gray-500" />
                          Grid View
                          {combinedViewMode === 'grid' && <Check size={14} className="ml-auto text-gray-500" />}
                        </button>
                      </div>}
                  </div>}
                {/* More options for Wait List tab - tablet/desktop only */}
                {['waitList', 'walkIn', 'appt'].includes(activeCombinedTab) && <div className="relative hidden md:block" ref={waitListDropdownRef}>
                    <Tippy content="View options">
                      <button className="p-1.5 rounded-md text-gray-500 hover:text-gray-700 hover:bg-gray-100 transition-all" onClick={() => setShowWaitListDropdown(!showWaitListDropdown)} aria-expanded={showWaitListDropdown} aria-haspopup="true">
                        <MoreVertical size={16} />
                      </button>
                    </Tippy>
                    {showWaitListDropdown && <div className="absolute right-0 mt-1 w-48 bg-white rounded-md shadow-lg z-10 border border-gray-200 py-1" role="menu">
                        <div className="px-3 py-2 border-b border-gray-100 bg-gray-50">
                          <h3 className="text-sm font-medium text-gray-700">
                            View Options
                          </h3>
                        </div>
                        <button className="w-full text-left px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 flex items-center" onClick={() => setCombinedViewMode('list')} role="menuitem">
                          <List size={14} className="mr-2 text-gray-500" />
                          Line View
                          {combinedViewMode === 'list' && <Check size={14} className="ml-auto text-gray-500" />}
                        </button>
                        <button className="w-full text-left px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 flex items-center" onClick={() => setCombinedViewMode('grid')} role="menuitem">
                          <Grid size={14} className="mr-2 text-gray-500" />
                          Grid View
                          {combinedViewMode === 'grid' && <Check size={14} className="ml-auto text-gray-500" />}
                        </button>
                      </div>}
                  </div>}
                {/* Toggle combined view button - only show on desktop */}
                {deviceInfo.isDesktop && <div className="flex items-center ml-4 border border-gray-200 rounded-md overflow-hidden shadow-sm">
                    <Tippy content="Tab View">
                      <button className={`flex items-center p-1.5 text-xs font-medium transition-all ${isCombinedView ? 'bg-[#00D0E0] text-white' : 'bg-white text-gray-600 hover:bg-gray-50'}`} onClick={() => {
                  if (!isCombinedView) toggleCombinedView();
                }} aria-pressed={isCombinedView}>
                        <LayoutGrid size={14} className="mr-1" />
                        Tabs
                      </button>
                    </Tippy>
                    <Tippy content="Column View">
                      <button className={`flex items-center p-1.5 text-xs font-medium transition-all ${!isCombinedView ? 'bg-[#00D0E0] text-white' : 'bg-white text-gray-600 hover:bg-gray-50'}`} onClick={() => {
                  if (isCombinedView) toggleCombinedView();
                }} aria-pressed={!isCombinedView}>
                        <Columns size={14} className="mr-1" />
                        Column
                      </button>
                    </Tippy>
                  </div>}
              </div>
            </div>}

          <div className="flex-1 flex flex-col p-2 sm:p-3 relative h-full">
            {/* Flexible content container */}
            <div className="flex flex-col h-full">
              {/* Combined view */}
              {isCombinedView ? <div className="overflow-auto flex-1" role="tabpanel" id={activeCombinedTab === 'service' ? 'service-panel' : 'waitlist-panel'}>
                  {/* Service Section - Show when active in combined view */}
                  {activeCombinedTab === 'service' && <div className="h-full">
                      <ServiceSection isMinimized={false} onToggleMinimize={() => toggleSectionMinimize('service')} isMobile={deviceInfo.isMobile || deviceInfo.isTablet} viewMode={combinedViewMode} setViewMode={setCombinedViewMode} cardViewMode={combinedCardViewMode} setCardViewMode={setCombinedCardViewMode} minimizedLineView={combinedMinimizedLineView} setMinimizedLineView={setCombinedMinimizedLineView} isCombinedView={true} hideHeader={true} />
                    </div>}
                  {/* Wait List Section - Show when active in combined view */}
                  {activeCombinedTab === 'waitList' && <div className="h-full">
                      <WaitListSection isMinimized={false} onToggleMinimize={() => toggleSectionMinimize('waitList')} isMobile={deviceInfo.isMobile || deviceInfo.isTablet} viewMode={combinedViewMode} setViewMode={setCombinedViewMode} cardViewMode={combinedCardViewMode} setCardViewMode={setCombinedCardViewMode} minimizedLineView={combinedMinimizedLineView} setMinimizedLineView={setCombinedMinimizedLineView} isCombinedView={true} hideHeader={true} />
                    </div>}
                </div> : <>
                  {/* Desktop: Grid layout for Service and Wait List sections */}
                  {/* Mobile/Tablet: Show only the active section based on tab */}
                  <div className={`${deviceInfo.isMobile || deviceInfo.isTablet ? 'overflow-auto flex-1' : 'grid grid-cols-1 lg:grid-cols-2 gap-3 overflow-auto'} ${!(deviceInfo.isMobile || deviceInfo.isTablet) && minimizedSections.pendingTickets ? 'flex-grow' : deviceInfo.isMobile || deviceInfo.isTablet ? 'flex-grow mb-[140px]' : 'mb-3'}`}>
                    {/* For tablet and mobile: Show sections based on active tab */}
                    {deviceInfo.isMobile || deviceInfo.isTablet ? <>
                        {/* Wait List Section - Show when active on mobile/tablet */}
                        {activeMobileSection === 'waitList' && <div className="h-full">
                            <WaitListSection isMinimized={false} onToggleMinimize={() => toggleSectionMinimize('waitList')} isMobile={deviceInfo.isMobile || deviceInfo.isTablet} />
                          </div>}
                        {/* Service Section - Show when active on mobile/tablet */}
                        {activeMobileSection === 'service' && <div className="h-full">
                            <ServiceSection isMinimized={false} onToggleMinimize={() => toggleSectionMinimize('service')} isMobile={deviceInfo.isMobile || deviceInfo.isTablet} />
                          </div>}
                      </> : <>
                        {/* Service Section */}
                        <div>
                          <ServiceSection isMinimized={minimizedSections.service} onToggleMinimize={() => toggleSectionMinimize('service')} isMobile={false} />
                        </div>
                        {/* Combine/Separate toggle button for desktop */}
                        <div className="absolute left-1/2 top-3 z-20 transform -translate-x-1/2">
                          <Tippy content={isCombinedView ? 'Separate sections' : 'Combine sections'}>
                            <button className="bg-white rounded-full p-2 shadow-md border border-gray-200 text-gray-500 hover:text-[#00D0E0] hover:bg-gray-50 transition-all duration-200" onClick={toggleCombinedView} aria-label={isCombinedView ? 'Separate sections' : 'Combine sections'}>
                              {isCombinedView ? <Columns size={20} /> : <LayoutDashboard size={20} />}
                            </button>
                          </Tippy>
                        </div>
                        {/* Wait List Section */}
                        <div>
                          <WaitListSection isMinimized={minimizedSections.waitList} onToggleMinimize={() => toggleSectionMinimize('waitList')} isMobile={false} />
                        </div>
                      </>}
                  </div>
                </>}
              {/* Pending Tickets - Always show, but position differently based on device */}
              <div className={`${!(deviceInfo.isMobile || deviceInfo.isTablet) && minimizedSections.pendingTickets ? 'absolute bottom-3 left-3 right-3' : deviceInfo.isMobile || deviceInfo.isTablet ? 'fixed bottom-0 left-0 right-0 z-20 ' + (minimizedSections.pendingTickets ? 'max-h-[140px]' : 'max-h-[40vh]') + ' px-2 pb-2' : ''}`}>
                <PendingTickets isMinimized={minimizedSections.pendingTickets} onToggleMinimize={() => toggleSectionMinimize('pendingTickets')} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>;
}