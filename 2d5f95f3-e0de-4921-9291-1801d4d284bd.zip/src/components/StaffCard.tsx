import React, { useEffect, useState, useRef } from 'react';
import { MoreVertical, Clock, DollarSign, Ticket, Star, Award, Sparkles, Coffee, UserCheck, ChevronRight, GripVertical, RefreshCw, Check, Circle, CircleDot } from 'lucide-react';
import Tippy from '@tippyjs/react';
import 'tippy.js/dist/tippy.css';
interface StaffCardProps {
  staff: {
    id: number;
    name: string;
    time: string;
    image: string;
    status: string;
    color: string;
    count: number;
    revenue: {
      transactions: number;
      tickets: number;
      amount: number;
    } | null;
    nextAppointmentTime?: string;
    nextAppointmentEta?: string;
    nextClientName?: string;
    nextServiceType?: string;
    lastServiceTime?: string;
    lastServiceAgo?: string;
    turnCount?: number;
    ticketsServicedCount?: number;
    totalSalesAmount?: number;
    specialty?: 'neutral' | 'nails' | 'hair' | 'massage' | 'skincare' | 'waxing' | 'combo' | 'support';
  };
  viewMode?: 'ultra-compact' | 'compact' | 'normal';
  isDraggable?: boolean;
  isSelected?: boolean;
  displayConfig?: {
    showName?: boolean;
    showQueueNumber?: boolean;
    showAvatar?: boolean;
    showTurnCount?: boolean;
    showStatus?: boolean;
    showClockedInTime?: boolean;
    showNextAppointment?: boolean;
    showSalesAmount?: boolean;
    showTickets?: boolean;
    showLastService?: boolean;
    enhancedSeparator?: boolean;
  };
}
// SVG Icons for data zone with classic metaphors
const ClassicIcons = {
  TicketStubClassic: ({
    color = '#4A5568',
    size = 18,
    strokeWidth = 2
  }) => <svg width={size} height={size} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" style={{
    shapeRendering: 'geometricPrecision'
  }}>
      <path d="M4 4h16a0 0 0 0 1 0 0v16a0 0 0 0 1 0 0H4a0 0 0 0 1 0 0V4a0 0 0 0 1 0 0z" />
      <path d="M4 4v16h16V4H4z" />
      <path d="M16 2v20M9 2v2M9 20v2M9 12h7M9 8h4M9 16h5" />
    </svg>,
  TicketStubPerf: ({
    color = '#4A5568',
    size = 18,
    strokeWidth = 2
  }) => <svg width={size} height={size} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" style={{
    shapeRendering: 'geometricPrecision'
  }}>
      <path d="M2 7v10a1 1 0 0 0 1 1h18a1 1 0 0 0 1-1V7a1 1 0 0 0-1-1H3a1 1 0 0 0-1 1z" />
      <path d="M16 6v12M6 6v.5M6 9.5v.5M6 13.5v.5M6 17.5v.5M22 10.5v3" />
    </svg>,
  MoneyBagClassic: ({
    color = '#4A5568',
    size = 18,
    strokeWidth = 2
  }) => <svg width={size} height={size} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" style={{
    shapeRendering: 'geometricPrecision'
  }}>
      <path d="M12 7v10M8 11h8M17.8 14c0 3.3-2.7 6-6 6-3.3 0-6-2.7-6-6V8h12v6z" />
      <path d="M10 4h4l2 4H8l2-4z" />
    </svg>,
  ClockAnalog: ({
    color = '#4A5568',
    size = 18,
    strokeWidth = 2
  }) => <svg width={size} height={size} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" style={{
    shapeRendering: 'geometricPrecision'
  }}>
      <circle cx="12" cy="12" r="10" />
      <polyline points="12,6 12,12 16,14" />
    </svg>,
  CalendarRingTabs: ({
    color = '#4A5568',
    size = 18,
    strokeWidth = 2,
    className = ''
  }) => <svg width={size} height={size} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" className={className} style={{
    shapeRendering: 'geometricPrecision'
  }}>
      <circle cx="12" cy="12" r="10" />
      <polyline points="12,6 12,12 16,14" />
      <rect x="12" y="1" width="1" height="2" />
      <rect x="12" y="21" width="1" height="2" />
      <rect x="21" y="12" width="2" height="1" />
      <rect x="1" y="12" width="2" height="1" />
    </svg>,
  NextAppointment: ({
    color = '#4A5568',
    size = 18,
    strokeWidth = 2,
    className = ''
  }) => <svg width={size} height={size} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" className={className} style={{
    shapeRendering: 'geometricPrecision'
  }}>
      <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
      <line x1="16" y1="2" x2="16" y2="6" />
      <line x1="8" y1="2" x2="8" y2="6" />
      <line x1="3" y1="10" x2="21" y2="10" />
      <path d="M12 14l3 3m0 0l-3 3m3-3H8" />
    </svg>,
  RepeatArrows: ({
    color = '#4A5568',
    size = 18,
    strokeWidth = 2
  }) => <svg width={size} height={size} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" style={{
    shapeRendering: 'geometricPrecision'
  }}>
      <path d="M17 2l4 4-4 4" />
      <path d="M3 11V9a4 4 0 0 1 4-4h14" />
      <path d="M7 22l-4-4 4-4" />
      <path d="M21 13v2a4 4 0 0 1-4 4H3" />
    </svg>,
  ClockAnalog3OClock: ({
    color = '#4A5568',
    size = 18,
    strokeWidth = 2
  }) => <svg width={size} height={size} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" style={{
    shapeRendering: 'geometricPrecision'
  }}>
      <circle cx="12" cy="12" r="10" />
      <polyline points="12,12 16,12" />
      <polyline points="12,6 12,12" />
    </svg>
};
export function StaffCard({
  staff,
  viewMode = 'normal',
  isDraggable = false,
  isSelected = false,
  displayConfig
}: StaffCardProps) {
  // Default display config - follow content priority rules
  const defaultDisplayConfig = {
    showName: true,
    showQueueNumber: true,
    showAvatar: true,
    showTurnCount: true,
    showStatus: true,
    showClockedInTime: true,
    showNextAppointment: true,
    showSalesAmount: true,
    showTickets: true,
    showLastService: true,
    enhancedSeparator: true // Improved visual separation
  };
  // Merge provided config with defaults
  const config = {
    ...defaultDisplayConfig,
    ...(displayConfig || {})
  };
  // Add ref and state for card width measurement
  const cardRef = useRef<HTMLDivElement>(null);
  const [cardWidth, setCardWidth] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);
  // Measure card width on mount and resize with debounce
  useEffect(() => {
    const updateWidth = () => {
      if (cardRef.current) {
        const newWidth = cardRef.current.offsetWidth;
        // Only trigger transition state if width actually changes
        if (newWidth !== cardWidth) {
          setIsTransitioning(true);
          setCardWidth(newWidth);
          // Reset transition state after animation completes
          const timer = setTimeout(() => setIsTransitioning(false), 300);
          return () => clearTimeout(timer);
        }
      }
    };
    // Initial measurement
    updateWidth();
    // Set up resize observer with debounce
    let debounceTimer: NodeJS.Timeout;
    const resizeObserver = new ResizeObserver(() => {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(updateWidth, 100);
    });
    if (cardRef.current) {
      resizeObserver.observe(cardRef.current);
    }
    // Clean up
    return () => {
      clearTimeout(debounceTimer);
      if (cardRef.current) {
        resizeObserver.disconnect();
      }
    };
  }, [cardWidth]);
  // Status colors and icons with improved visual indicators
  const statusColors = {
    ready: {
      bg: 'bg-emerald-500',
      lightBg: 'bg-emerald-100',
      pulseColor: 'bg-emerald-400',
      glowColor: 'shadow-emerald-300/0',
      text: 'text-emerald-700',
      lightText: 'text-emerald-50',
      chipBg: 'bg-emerald-100',
      chipBorder: 'border-emerald-200',
      icon: <Check size={viewMode === 'ultra-compact' ? 10 : 12} strokeWidth={2.5} className="mr-1" style={{
        shapeRendering: 'geometricPrecision'
      }} />,
      label: 'Ready',
      desaturateHeader: false,
      cardShadow: '0 1px 3px rgba(0,0,0,0.05)',
      grayOutOverlay: false
    },
    busy: {
      bg: 'bg-rose-500',
      lightBg: 'bg-rose-100',
      pulseColor: 'bg-rose-400',
      glowColor: 'shadow-rose-300/70',
      text: 'text-rose-700',
      lightText: 'text-rose-50',
      chipBg: 'bg-rose-100',
      chipBorder: 'border-rose-200',
      icon: <CircleDot size={viewMode === 'ultra-compact' ? 10 : 12} strokeWidth={2.5} className="mr-1" style={{
        shapeRendering: 'geometricPrecision'
      }} />,
      label: 'Busy',
      desaturateHeader: true,
      cardShadow: '0 1px 3px rgba(0,0,0,0.05)',
      grayOutOverlay: true,
      busyBorderColor: 'rgba(225, 29, 72, 0.5)' // Rose color for busy border
    },
    off: {
      bg: 'bg-gray-400',
      lightBg: 'bg-gray-100',
      pulseColor: 'bg-gray-300',
      glowColor: 'shadow-gray-200/0',
      text: 'text-gray-600',
      lightText: 'text-gray-100',
      chipBg: 'bg-gray-100',
      chipBorder: 'border-gray-200',
      icon: <Circle size={viewMode === 'ultra-compact' ? 10 : 12} strokeWidth={2.5} className="mr-1" style={{
        shapeRendering: 'geometricPrecision'
      }} />,
      label: 'Off',
      desaturateHeader: false,
      cardShadow: '0 1px 3px rgba(0,0,0,0.05)',
      grayOutOverlay: false
    }
  };
  const status = statusColors[staff.status] || statusColors.busy;
  // Specialty color mapping
  const specialtyColors: Record<string, {
    base: string;
    header: string;
    headerDesaturated: string;
    data: string;
    dataDesaturated: string;
    description: string;
    textColor: string;
    darkText: boolean;
    borderColor: string;
    darkBorderColor: string; // Darker border color for metallic effect
    bgTint: string;
    headerBg: string;
    dataBg: string;
    busyHeaderBg: string;
    busyDataBg: string;
    // Metallic gradient colors
    metalGradientFrom: string;
    metalGradientTo: string;
    metalGradientFromDark: string;
    metalGradientToDark: string;
  }> = {
    neutral: {
      base: '#FFEEF1',
      header: '#FFFFFF',
      headerDesaturated: '#FCFCFC',
      data: '#F8F8F8',
      dataDesaturated: '#FAFAFA',
      description: 'General staff with no specialty',
      textColor: '#333333',
      darkText: true,
      borderColor: '#E0E0E0',
      darkBorderColor: '#C0C0C0',
      bgTint: 'rgba(240, 240, 240, 0.03)',
      headerBg: 'rgba(250, 250, 250, 0.08)',
      dataBg: 'rgba(245, 245, 245, 0.04)',
      busyHeaderBg: 'rgba(245, 245, 245, 0.06)',
      busyDataBg: 'rgba(240, 240, 240, 0.02)',
      // Metallic gradient colors
      metalGradientFrom: '#FFFFFF',
      metalGradientTo: '#F0F0F0',
      metalGradientFromDark: '#F8F8F8',
      metalGradientToDark: '#E8E8E8'
    },
    nails: {
      base: '#F43F5E',
      header: '#FFF1F3',
      headerDesaturated: '#FFF1F3',
      data: '#FFFFFF',
      dataDesaturated: '#FFFAFA',
      description: 'Nail services specialists',
      textColor: '#BE123C',
      darkText: true,
      borderColor: '#F43F5E',
      darkBorderColor: '#D41C44',
      bgTint: 'rgba(244, 63, 94, 0.07)',
      headerBg: 'rgba(244, 63, 94, 0.25)',
      dataBg: 'rgba(244, 63, 94, 0.12)',
      busyHeaderBg: 'rgba(244, 63, 94, 0.15)',
      busyDataBg: 'rgba(244, 63, 94, 0.07)',
      // Metallic gradient colors
      metalGradientFrom: '#FFF1F3',
      metalGradientTo: '#FFE4E8',
      metalGradientFromDark: '#FFE4E8',
      metalGradientToDark: '#FFD8DE'
    },
    hair: {
      base: '#2563EB',
      header: '#F0F7FF',
      headerDesaturated: '#F0F7FF',
      data: '#FFFFFF',
      dataDesaturated: '#FAFCFF',
      description: 'Hair styling and cutting specialists',
      textColor: '#1E40AF',
      darkText: true,
      borderColor: '#2563EB',
      darkBorderColor: '#1D4ED8',
      bgTint: 'rgba(37, 99, 235, 0.07)',
      headerBg: 'rgba(37, 99, 235, 0.25)',
      dataBg: 'rgba(37, 99, 235, 0.12)',
      busyHeaderBg: 'rgba(37, 99, 235, 0.15)',
      busyDataBg: 'rgba(37, 99, 235, 0.07)',
      // Metallic gradient colors
      metalGradientFrom: '#F0F7FF',
      metalGradientTo: '#E1EFFE',
      metalGradientFromDark: '#E1EFFE',
      metalGradientToDark: '#D1E5FE'
    },
    massage: {
      base: '#16A34A',
      header: '#F0FFF4',
      headerDesaturated: '#F0FFF4',
      data: '#FFFFFF',
      dataDesaturated: '#FAFFFC',
      description: 'Massage therapy specialists',
      textColor: '#166534',
      darkText: true,
      borderColor: '#16A34A',
      darkBorderColor: '#15803D',
      bgTint: 'rgba(22, 163, 74, 0.07)',
      headerBg: 'rgba(22, 163, 74, 0.25)',
      dataBg: 'rgba(22, 163, 74, 0.12)',
      busyHeaderBg: 'rgba(22, 163, 74, 0.15)',
      busyDataBg: 'rgba(22, 163, 74, 0.07)',
      // Metallic gradient colors
      metalGradientFrom: '#F0FFF4',
      metalGradientTo: '#DCFCE7',
      metalGradientFromDark: '#DCFCE7',
      metalGradientToDark: '#BBF7D0'
    },
    skincare: {
      base: '#A855F7',
      header: '#F8F5FF',
      headerDesaturated: '#F8F5FF',
      data: '#FFFFFF',
      dataDesaturated: '#FCFAFF',
      description: 'Facial and skin treatment specialists',
      textColor: '#7E22CE',
      darkText: true,
      borderColor: '#A855F7',
      darkBorderColor: '#9333EA',
      bgTint: 'rgba(168, 85, 247, 0.07)',
      headerBg: 'rgba(168, 85, 247, 0.25)',
      dataBg: 'rgba(168, 85, 247, 0.12)',
      busyHeaderBg: 'rgba(168, 85, 247, 0.15)',
      busyDataBg: 'rgba(168, 85, 247, 0.07)',
      // Metallic gradient colors
      metalGradientFrom: '#F8F5FF',
      metalGradientTo: '#F3E8FF',
      metalGradientFromDark: '#F3E8FF',
      metalGradientToDark: '#E9D5FF'
    },
    waxing: {
      base: '#06B6D4',
      header: '#F0FCFF',
      headerDesaturated: '#F0FCFF',
      data: '#FFFFFF',
      dataDesaturated: '#FAFEFF',
      description: 'Waxing service specialists',
      textColor: '#0E7490',
      darkText: true,
      borderColor: '#06B6D4',
      darkBorderColor: '#0891B2',
      bgTint: 'rgba(6, 182, 212, 0.07)',
      headerBg: 'rgba(6, 182, 212, 0.25)',
      dataBg: 'rgba(6, 182, 212, 0.12)',
      busyHeaderBg: 'rgba(6, 182, 212, 0.15)',
      busyDataBg: 'rgba(6, 182, 212, 0.07)',
      // Metallic gradient colors
      metalGradientFrom: '#F0FCFF',
      metalGradientTo: '#CFFAFE',
      metalGradientFromDark: '#CFFAFE',
      metalGradientToDark: '#A5F3FC'
    },
    combo: {
      base: '#EAB308',
      header: '#FFFBEB',
      headerDesaturated: '#FFFBEB',
      data: '#FFFFFF',
      dataDesaturated: '#FFFDF7',
      description: 'Staff providing multiple service types',
      textColor: '#A16207',
      darkText: true,
      borderColor: '#EAB308',
      darkBorderColor: '#CA8A04',
      bgTint: 'rgba(234, 179, 8, 0.07)',
      headerBg: 'rgba(234, 179, 8, 0.25)',
      dataBg: 'rgba(234, 179, 8, 0.12)',
      busyHeaderBg: 'rgba(234, 179, 8, 0.15)',
      busyDataBg: 'rgba(234, 179, 8, 0.07)',
      // Metallic gradient colors
      metalGradientFrom: '#FFFBEB',
      metalGradientTo: '#FEF3C7',
      metalGradientFromDark: '#FEF3C7',
      metalGradientToDark: '#FDE68A'
    },
    support: {
      base: '#F97316',
      header: '#FFF7ED',
      headerDesaturated: '#FFF7ED',
      data: '#FFFFFF',
      dataDesaturated: '#FFFCFA',
      description: 'Support and training personnel',
      textColor: '#C2410C',
      darkText: true,
      borderColor: '#F97316',
      darkBorderColor: '#EA580C',
      bgTint: 'rgba(249, 115, 22, 0.07)',
      headerBg: 'rgba(249, 115, 22, 0.25)',
      dataBg: 'rgba(249, 115, 22, 0.12)',
      busyHeaderBg: 'rgba(249, 115, 22, 0.15)',
      busyDataBg: 'rgba(249, 115, 22, 0.07)',
      // Metallic gradient colors
      metalGradientFrom: '#FFF7ED',
      metalGradientTo: '#FFEDD5',
      metalGradientFromDark: '#FFEDD5',
      metalGradientToDark: '#FED7AA'
    }
  };
  // Get specialty colors or default to neutral
  const specialty = staff.specialty || 'neutral';
  const specialtyColor = specialtyColors[specialty];
  // Generate a unique gradient based on staff color
  const getStaffGradient = () => {
    const baseColor = staff.color.replace('bg-', '');
    // Enhanced color mappings for more vibrant colors
    const colorMap: Record<string, {
      main: string;
      light: string;
      dark: string;
      glow: string;
      accent: string;
      border: string;
      stripeBg: string;
      badgeBg: string;
      badgeText: string;
      shadowColor: string;
      innerBorder: string;
      highlightColor: string;
    }> = {
      white: {
        main: 'bg-white',
        light: 'from-gray-50 to-white',
        dark: 'bg-gray-200',
        glow: 'shadow-gray-300/40',
        accent: 'bg-gray-400',
        border: 'border-gray-200',
        stripeBg: 'bg-gradient-to-b from-gray-200 to-gray-300',
        badgeBg: 'bg-gray-100',
        badgeText: 'text-gray-700',
        shadowColor: 'rgba(0,0,0,0.05)',
        innerBorder: 'border-gray-200/60',
        highlightColor: 'rgba(255,255,255,0.8)'
      },
      '[#9B5DE5]': {
        main: 'bg-white',
        light: 'from-purple-50 to-white',
        dark: 'bg-[#7A3DBE]',
        glow: 'shadow-purple-300/40',
        accent: 'bg-[#9B5DE5]',
        border: 'border-purple-200',
        stripeBg: 'bg-gradient-to-b from-[#9B5DE5] to-[#7A3DBE]',
        badgeBg: 'bg-purple-100',
        badgeText: 'text-purple-700',
        shadowColor: 'rgba(0,0,0,0.05)',
        innerBorder: 'border-purple-200/60',
        highlightColor: 'rgba(233,213,255,0.8)'
      },
      '[#E5565B]': {
        main: 'bg-white',
        light: 'from-red-50 to-white',
        dark: 'bg-[#C23A3F]',
        glow: 'shadow-red-300/40',
        accent: 'bg-[#E5565B]',
        border: 'border-red-200',
        stripeBg: 'bg-gradient-to-b from-[#E5565B] to-[#C23A3F]',
        badgeBg: 'bg-red-100',
        badgeText: 'text-red-700',
        shadowColor: 'rgba(0,0,0,0.05)',
        innerBorder: 'border-red-200/60',
        highlightColor: 'rgba(254,226,226,0.8)'
      },
      '[#3F83F8]': {
        main: 'bg-white',
        light: 'from-blue-50 to-white',
        dark: 'bg-[#2A5EC8]',
        glow: 'shadow-blue-300/40',
        accent: 'bg-[#3F83F8]',
        border: 'border-blue-200',
        stripeBg: 'bg-gradient-to-b from-[#3F83F8] to-[#2A5EC8]',
        badgeBg: 'bg-blue-100',
        badgeText: 'text-blue-700',
        shadowColor: 'rgba(0,0,0,0.05)',
        innerBorder: 'border-blue-200/60',
        highlightColor: 'rgba(219,234,254,0.8)'
      },
      '[#4CC2A9]': {
        main: 'bg-white',
        light: 'from-teal-50 to-white',
        dark: 'bg-[#2D9C87]',
        glow: 'shadow-teal-300/40',
        accent: 'bg-[#4CC2A9]',
        border: 'border-teal-200',
        stripeBg: 'bg-gradient-to-b from-[#4CC2A9] to-[#2D9C87]',
        badgeBg: 'bg-teal-100',
        badgeText: 'text-teal-700',
        shadowColor: 'rgba(0,0,0,0.05)',
        innerBorder: 'border-teal-200/60',
        highlightColor: 'rgba(204,251,241,0.8)'
      },
      '[#3C78D8]': {
        main: 'bg-white',
        light: 'from-blue-50 to-white',
        dark: 'bg-[#2559B0]',
        glow: 'shadow-blue-300/40',
        accent: 'bg-[#3C78D8]',
        border: 'border-blue-200',
        stripeBg: 'bg-gradient-to-b from-[#3C78D8] to-[#2559B0]',
        badgeBg: 'bg-blue-100',
        badgeText: 'text-blue-700',
        shadowColor: 'rgba(0,0,0,0.05)',
        innerBorder: 'border-blue-200/60',
        highlightColor: 'rgba(219,234,254,0.8)'
      }
    };
    return colorMap[baseColor] || colorMap['white'];
  };
  const colors = getStaffGradient();
  // Format time to h:mma without leading zero (e.g., 9:45a, 1:05p)
  const formatTime = (timeString?: string): string => {
    if (!timeString) return '-';
    // Parse the time string
    const match = timeString.match(/(\d+):(\d+)\s*([AP]M)?/i);
    if (!match) return timeString;
    let hours = parseInt(match[1], 10);
    const minutes = match[2];
    const ampm = match[3]?.toLowerCase() || '';
    // Remove leading zero from hours
    if (hours === 0) hours = 12;
    // Format as h:mma
    const period = ampm.includes('p') ? 'p' : 'a';
    return `${hours}:${minutes}${period}`;
  };
  // Format currency in compact form without cents unless needed
  const formatCurrency = (amount?: number): string => {
    if (amount === undefined) return '-';
    if (amount >= 1000) {
      const thousands = amount / 1000;
      return `$${thousands % 1 === 0 ? thousands : thousands.toFixed(1)}k`;
    }
    return `$${amount % 1 === 0 ? amount : amount.toFixed(2)}`;
  };
  // Determine header and data background colors based on status
  const getHeaderColor = () => {
    return status.desaturateHeader ? specialtyColor.busyHeaderBg : specialtyColor.headerBg;
  };
  const getDataColor = () => {
    return status.desaturateHeader ? specialtyColor.busyDataBg : specialtyColor.dataBg;
  };
  // Get transition class based on state
  const getTransitionClass = () => {
    return isTransitioning ? 'transition-all duration-300 ease-in-out' : '';
  };
  // COMPACT VIEW - Optimized for minimized staff card view
  if (viewMode === 'compact') {
    return <div ref={cardRef} className={`group flex items-center p-2 w-full ${isSelected ? 'ring-2 ring-offset-2 ring-blue-500' : ''} ${getTransitionClass()}`} style={{
      borderRadius: '14px',
      boxShadow: status.grayOutOverlay ? '0 3px 6px rgba(0,0,0,0.15), 0 1px 3px rgba(0,0,0,0.1)' // Enhanced shadow for busy
      : '0 2px 5px rgba(0,0,0,0.08), 0 1px 2px rgba(0,0,0,0.06)',
      border: status.grayOutOverlay ? `2px solid ${specialtyColor.darkBorderColor}` // Darker border for busy
      : `2px solid ${specialtyColor.darkBorderColor}`,
      position: 'relative',
      overflow: 'hidden',
      transformStyle: 'preserve-3d',
      cursor: isDraggable ? 'grab' : 'pointer',
      filter: status.grayOutOverlay ? 'contrast(0.95) grayscale(0.15)' : 'none'
    }} tabIndex={0} role="button" aria-label={`${staff.name}, ${status.label}, Queue position: ${staff.count}`}>
        {/* Metallic gradient background */}
        <div className="absolute inset-0 z-0" style={{
        background: status.grayOutOverlay ? `linear-gradient(to bottom, ${specialtyColor.metalGradientFromDark}, ${specialtyColor.metalGradientToDark})` : `linear-gradient(to bottom, ${specialtyColor.metalGradientFrom}, ${specialtyColor.metalGradientTo})`,
        opacity: 0.85
      }}></div>
        {/* Inner shadow/bevel effect */}
        <div className="absolute inset-0 z-0 rounded-[12px] pointer-events-none" style={{
        boxShadow: 'inset 0 1px 2px rgba(255,255,255,0.6), inset 0 -1px 2px rgba(0,0,0,0.1)'
      }}></div>
        {/* Semi-circle notch at top border - INCREASED SIZE with added outline and sharper edges */}
        <div className="absolute top-0 left-1/2 w-5 h-3 bg-white z-20" style={{
        transform: 'translate(-50%, -50%)',
        borderRadius: '0 0 5px 5px',
        borderTop: 'none',
        borderLeft: `1px solid ${specialtyColor.darkBorderColor}`,
        borderRight: `1px solid ${specialtyColor.darkBorderColor}`,
        borderBottom: `1px solid ${specialtyColor.darkBorderColor}`,
        boxShadow: '0 1px 2px rgba(0,0,0,0.1)' // Enhanced shadow
      }}></div>
        {/* Enhanced separation line - visible even in compact view */}
        <div className="absolute top-0 bottom-0 left-[25%] w-[1px] h-full z-10" style={{
        background: status.grayOutOverlay ? 'rgba(180, 40, 60, 0.12)' : specialtyColor.darkText ? 'rgba(0,0,0,0.1)' // Darker line for lighter colors
        : 'rgba(255,255,255,0.2)',
        boxShadow: specialtyColor.darkText ? '1px 0 1px rgba(255,255,255,0.15)' // Subtle highlight for embossed effect
        : '1px 0 1px rgba(255,255,255,0.25)' // More pronounced highlight for darker colors
      }}></div>
        {/* Gray out overlay for busy status - ENHANCED with striped pattern and increased contrast */}
        {status.grayOutOverlay && <>
            {/* Improved overlay with consistent gray background - APPLIED TO ENTIRE CARD */}
            <div className="absolute inset-0 z-10 pointer-events-none rounded-[13.5px]" style={{
          backgroundColor: 'rgba(220, 225, 235, 0.5)',
          mixBlendMode: 'multiply'
        }}></div>
            {/* Enhanced busy indicator with icon - POSITIONED AT TOP RIGHT */}
            <div className="absolute top-0 right-0 px-3 py-1 bg-rose-600 z-40 pointer-events-none shadow-sm flex items-center justify-center" style={{
          borderRadius: '0 0 0 8px',
          boxShadow: '0 2px 4px rgba(225, 29, 72, 0.2)',
          minWidth: '60px'
        }}>
              <CircleDot size={10} className="mr-1 text-white animate-pulse" strokeWidth={2.5} />
              <span className="text-xs font-bold text-white uppercase tracking-wider">
                Busy
              </span>
            </div>
          </>}
        {/* More Options Button - positioned at middle right */}
        <button className="absolute top-1/2 right-2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700 transition-all duration-300 p-1 flex-shrink-0 z-30" aria-label="More options for staff member">
          <MoreVertical size={14} strokeWidth={2} />
        </button>
        {isDraggable && <div className="absolute top-1/2 -left-1 transform -translate-y-1/2 opacity-0 group-hover:opacity-70 cursor-grab active:cursor-grabbing z-10 transition-opacity">
            <GripVertical size={16} className="text-gray-600" strokeWidth={2} />
          </div>}
        {/* Staff avatar with accent border - INCREASED SIZE */}
        {config.showAvatar && <div className="relative flex-shrink-0 z-10 ml-1">
            <img src={staff.image} alt={`${staff.name} profile`} className={`w-16 h-16 rounded-full object-cover shadow-sm transition-all duration-300 group-hover:brightness-105 ${getTransitionClass()} ${status.grayOutOverlay ? 'grayscale-[15%] brightness-95' : ''}`} style={{
          boxShadow: '0 2px 4px rgba(0,0,0,0.15), 0 0 1px rgba(0,0,0,0.1)',
          border: status.grayOutOverlay ? `3px solid ${specialtyColor.darkBorderColor}` : `3.5px solid ${specialtyColor.darkBorderColor}`,
          minWidth: '64px',
          minHeight: '64px'
        }} />
            {/* Queue Order Number - INCREASED SIZE */}
            {config.showQueueNumber && <div className="absolute -top-1 -left-1">
                <Tippy content={`Queue Position: ${staff.count}`}>
                  <div className="bg-white rounded-full w-6 h-6 flex items-center justify-center text-[11px] font-bold text-gray-700 border border-white shadow-sm" aria-label={`Queue position: ${staff.count}`} style={{
              boxShadow: '0 1px 3px rgba(0,0,0,0.2)' // Enhanced shadow
            }}>
                    {staff.count}
                  </div>
                </Tippy>
              </div>}
            {/* Status indicator - ALWAYS VISIBLE (Tier 1) */}
            {config.showStatus && <div className="absolute -bottom-0.5 -right-0.5">
                <Tippy content={`Status: ${status.label}`}>
                  <div className={`${status.bg} w-6 h-6 rounded-full flex items-center justify-center shadow-sm border-2 border-white ${status.glowColor}`} style={{
              boxShadow: '0 2px 4px rgba(0,0,0,0.2)' // Enhanced shadow
            }} aria-label={`Status: ${status.label}`}>
                    <div className={`w-2 h-2 rounded-full bg-white animate-pulse opacity-80`}></div>
                  </div>
                </Tippy>
              </div>}
          </div>}
        {/* Staff info - Name and status - INCREASED TEXT SIZE */}
        <div className="ml-3 flex-1 min-w-0 z-10">
          {/* Staff name - INCREASED SIZE AND PRIORITY */}
          {config.showName && <div className={`font-bold text-lg truncate block ${getTransitionClass()}`} style={{
          color: status.grayOutOverlay ? 'rgba(70, 77, 95, 0.95)' // Darker desaturated text for busy status
          : 'rgba(50, 57, 75, 0.95)',
          fontSize: 'min(1.125rem, max(0.875rem, 2.5vw))',
          lineHeight: '1.1',
          letterSpacing: '0.01em',
          maxWidth: '100%',
          paddingRight: '4px',
          minWidth: '0',
          flexShrink: 1,
          whiteSpace: 'nowrap',
          overflow: 'hidden',
          textOverflow: 'ellipsis',
          textShadow: '0px 1px 0px rgba(255,255,255,0.5)' // Text shadow for etched effect
        }} title={staff.name} // Show full name on hover
        >
              {staff.name}
            </div>}
          {/* Status text */}
          {config.showStatus && <div className="flex items-center mt-1"></div>}
          {/* Clock-in Time */}
          {config.showClockedInTime && <Tippy content={`Clocked In: ${staff.time}`}>
              <div className={`flex items-center text-xs ${status.grayOutOverlay ? 'text-gray-500' : 'text-gray-700'} mt-1`} style={{
            textShadow: '0px 1px 0px rgba(255,255,255,0.5)' // Text shadow for etched effect
          }}>
                <Clock size={10} className={`mr-0.5 ${status.grayOutOverlay ? 'text-gray-500' : 'text-gray-700'}`} strokeWidth={2} />
                <span className="font-medium">{formatTime(staff.time)}</span>
              </div>
            </Tippy>}
          {/* Metrics row - Turn Count, Tickets, etc. */}
          <div className="flex items-center mt-2 space-x-3">
            {/* Turn Count - ALWAYS VISIBLE (Tier 1) - ENHANCED EMPHASIS */}
            {config.showTurnCount && <Tippy content={`Turn Count: ${staff.turnCount ?? staff.count}`}>
                <div className="flex items-center" aria-label={`Turn count: ${staff.turnCount ?? staff.count}`} style={{
              textShadow: '0px 1px 0px rgba(255,255,255,0.5)' // Text shadow for etched effect
            }}>
                  <span className="text-sm font-semibold mr-0.5 text-gray-700">
                    T:
                  </span>
                  <span className="text-sm font-extrabold" style={{
                color: status.grayOutOverlay ? 'rgba(60, 67, 80, 0.95)' : 'rgba(40, 47, 60, 0.95)',
                letterSpacing: '-0.01em'
              }}>
                    {staff.turnCount ?? staff.count}
                  </span>
                </div>
              </Tippy>}
            {/* Tickets - TIER 3 PERFORMANCE METRIC */}
            {config.showTickets && cardWidth >= 220 && <Tippy content={`Tickets: ${staff.ticketsServicedCount ?? staff.count}`}>
                <div className="flex items-center" aria-label={`Tickets: ${staff.ticketsServicedCount ?? staff.count}`} style={{
              textShadow: '0px 1px 0px rgba(255,255,255,0.5)' // Text shadow for etched effect
            }}>
                  <Ticket size={12} className={`mr-1 ${status.grayOutOverlay ? 'text-gray-500' : 'text-gray-700'}`} strokeWidth={2} />
                  <span className="text-sm font-semibold text-gray-700">
                    {staff.ticketsServicedCount ?? staff.count}
                  </span>
                </div>
              </Tippy>}
            {/* Sales Amount */}
            {config.showSalesAmount && cardWidth >= 240 && <Tippy content={`Total Sales: ${formatCurrency(staff.totalSalesAmount ?? staff.revenue?.amount ?? 0)}`}>
                <div className="flex items-center" aria-label={`Total sales: ${formatCurrency(staff.totalSalesAmount ?? staff.revenue?.amount ?? 0)}`} style={{
              textShadow: '0px 1px 0px rgba(255,255,255,0.5)' // Text shadow for etched effect
            }}>
                  <DollarSign size={12} className={`mr-1 ${status.grayOutOverlay ? 'text-gray-500' : 'text-gray-700'}`} strokeWidth={2} />
                  <span className="text-sm font-semibold text-gray-700">
                    {formatCurrency(staff.totalSalesAmount ?? staff.revenue?.amount ?? 0).replace('$', '')}
                  </span>
                </div>
              </Tippy>}
          </div>
        </div>
        {/* Time indicators - Next appointment and Last service */}
        <div className="flex flex-col ml-auto space-y-1 z-10">
          {/* Next Appointment - TIER 2 OPERATIONAL TIMING */}
          {config.showNextAppointment && staff.nextAppointmentTime && cardWidth >= 280 && <Tippy content={`Next Appointment: ${staff.nextAppointmentTime}${staff.nextAppointmentEta ? ` (${staff.nextAppointmentEta})` : ''}${staff.nextClientName ? ` - ${staff.nextClientName}` : ''}${staff.nextServiceType ? ` - ${staff.nextServiceType}` : ''}`}>
                <div className={`flex items-center text-xs ${status.grayOutOverlay ? 'text-blue-700/80' : 'text-blue-700'}`} aria-label={`Next appointment at ${staff.nextAppointmentTime}${staff.nextAppointmentEta ? ` (${staff.nextAppointmentEta})` : ''}${staff.nextClientName ? ` for ${staff.nextClientName}` : ''}${staff.nextServiceType ? ` - ${staff.nextServiceType}` : ''}`} style={{
            textShadow: '0px 1px 0px rgba(255,255,255,0.5)' // Text shadow for etched effect
          }}>
                  <ClassicIcons.NextAppointment size={10} color={status.grayOutOverlay ? '#3B82F6CC' : '#3B82F6'} strokeWidth={2} className="mr-0.5" />
                  <span className="font-medium">
                    {formatTime(staff.nextAppointmentTime)}
                  </span>
                </div>
              </Tippy>}
          {/* Last Service - TIER 4 CONTEXT/UTILITY (lowest priority) */}
          {config.showLastService && staff.lastServiceTime && cardWidth >= 320 && <Tippy content={`Last Service: ${staff.lastServiceTime}${staff.lastServiceAgo ? ` (${staff.lastServiceAgo})` : ''}`}>
                <div className={`flex items-center text-xs ${status.grayOutOverlay ? 'text-amber-700/80' : 'text-amber-700'}`} aria-label={`Last service at ${staff.lastServiceTime}`} style={{
            textShadow: '0px 1px 0px rgba(255,255,255,0.5)' // Text shadow for etched effect
          }}>
                  <ClassicIcons.ClockAnalog size={10} color={status.grayOutOverlay ? '#B45309CC' : '#B45309'} strokeWidth={2} className="mr-0.5" />
                  <span className="font-medium">
                    {formatTime(staff.lastServiceTime)}
                  </span>
                </div>
              </Tippy>}
        </div>
        {/* Hover/active/drag state styling */}
        <style jsx>{`
          .group {
            transform-origin: center center;
            transform: translateZ(0);
            backface-visibility: hidden;
            will-change: transform, box-shadow;
          }
          .group:hover {
            transform: translateY(-2px);
            box-shadow:
              0 5px 10px rgba(0, 0, 0, 0.12),
              0 3px 6px rgba(0, 0, 0, 0.08);
          }
          .group:active {
            transform: translateY(1px);
            box-shadow: 0 2px 3px rgba(0, 0, 0, 0.15);
            cursor: grabbing;
          }
          .group:focus-visible {
            outline: none;
            box-shadow: 0 0 0 3px rgba(0, 180, 255, 0.35);
          }
        `}</style>
      </div>;
  }
  // ULTRA-COMPACT VIEW - Optimized for very narrow sidebars
  if (viewMode === 'ultra-compact') {
    return <div ref={cardRef} className={`group flex flex-col items-center p-1.5 w-full ${isSelected ? 'ring-2 ring-offset-1 ring-blue-500' : ''} ${getTransitionClass()}`} style={{
      borderRadius: '12px',
      boxShadow: status.grayOutOverlay ? '0 3px 6px rgba(0,0,0,0.15), 0 1px 3px rgba(0,0,0,0.1)' // Enhanced shadow for busy
      : '0 2px 5px rgba(0,0,0,0.08), 0 1px 2px rgba(0,0,0,0.06)',
      border: status.grayOutOverlay ? `2px solid ${specialtyColor.darkBorderColor}` // Darker border for busy
      : `2px solid ${specialtyColor.darkBorderColor}`,
      position: 'relative',
      overflow: 'hidden',
      transformStyle: 'preserve-3d',
      cursor: isDraggable ? 'grab' : 'pointer',
      filter: status.grayOutOverlay ? 'contrast(0.95) grayscale(0.15)' : 'none'
    }} tabIndex={0} role="button" aria-label={`${staff.name}, ${status.label}, Queue position: ${staff.count}`}>
        {/* Metallic gradient background */}
        <div className="absolute inset-0 z-0" style={{
        background: status.grayOutOverlay ? `linear-gradient(to bottom, ${specialtyColor.metalGradientFromDark}, ${specialtyColor.metalGradientToDark})` : `linear-gradient(to bottom, ${specialtyColor.metalGradientFrom}, ${specialtyColor.metalGradientTo})`,
        opacity: 0.85
      }}></div>
        {/* Inner shadow/bevel effect */}
        <div className="absolute inset-0 z-0 rounded-[10px] pointer-events-none" style={{
        boxShadow: 'inset 0 1px 2px rgba(255,255,255,0.6), inset 0 -1px 2px rgba(0,0,0,0.1)'
      }}></div>
        {/* Semi-circle notch at top border (smaller for ultra-compact view) - INCREASED SIZE with added outline and sharper edges */}
        <div className="absolute top-0 left-1/2 w-4.5 h-2.5 bg-white z-20" style={{
        transform: 'translate(-50%, -50%)',
        borderRadius: '0 0 4.5px 4.5px',
        borderTop: 'none',
        borderLeft: `1px solid ${specialtyColor.darkBorderColor}`,
        borderRight: `1px solid ${specialtyColor.darkBorderColor}`,
        borderBottom: `1px solid ${specialtyColor.darkBorderColor}`,
        boxShadow: '0 1px 2px rgba(0,0,0,0.1)' // Enhanced shadow
      }}></div>
        {/* Gray out overlay for busy status */}
        {status.grayOutOverlay && <>
            {/* Improved overlay with consistent gray background */}
            <div className="absolute inset-0 z-10 pointer-events-none rounded-[11.5px]" style={{
          backgroundColor: 'rgba(220, 225, 235, 0.5)',
          mixBlendMode: 'multiply'
        }}></div>
            {/* Enhanced busy indicator with icon */}
            <div className="absolute top-0 right-0 px-2.5 py-0.5 bg-rose-600 z-40 pointer-events-none shadow-sm flex items-center justify-center" style={{
          borderRadius: '0 0 0 7px',
          boxShadow: '0 2px 4px rgba(225, 29, 72, 0.2)',
          minWidth: '51px'
        }}>
              <CircleDot size={8} className="mr-0.5 text-white animate-pulse" strokeWidth={2.5} />
              <span className="text-[10px] font-bold text-white uppercase tracking-wider">
                Busy
              </span>
            </div>
          </>}
        {/* Staff avatar with accent border */}
        {config.showAvatar && <div className="relative z-10 w-full flex justify-center">
            <img src={staff.image} alt={`${staff.name} profile`} className={`w-11 h-11 rounded-full object-cover shadow-sm transition-all duration-300 group-hover:brightness-105 ${getTransitionClass()} ${status.grayOutOverlay ? 'grayscale-[15%] brightness-95' : ''}`} style={{
          boxShadow: '0 2px 4px rgba(0,0,0,0.15), 0 0 1px rgba(0,0,0,0.1)',
          border: status.grayOutOverlay ? `2.5px solid ${specialtyColor.darkBorderColor}` : `3px solid ${specialtyColor.darkBorderColor}`,
          minWidth: '44px',
          minHeight: '44px'
        }} />
            {/* Queue Order Number - ALWAYS VISIBLE (Tier 1) */}
            {config.showQueueNumber && <div className="absolute -top-0.5 -left-0.5">
                <Tippy content={`Queue Position: ${staff.count}`}>
                  <div className="bg-white rounded-full w-5 h-5 flex items-center justify-center text-[10px] font-bold text-gray-700 border border-white shadow-sm" aria-label={`Queue position: ${staff.count}`} style={{
              boxShadow: '0 1px 3px rgba(0,0,0,0.2)' // Enhanced shadow
            }}>
                    {staff.count}
                  </div>
                </Tippy>
              </div>}
            {/* Status indicator - ALWAYS VISIBLE (Tier 1) */}
            {config.showStatus && <div className="absolute -top-0.5 -right-0.5">
                <Tippy content={`Status: ${status.label}`}>
                  <div className={`${status.bg} w-4.5 h-4.5 rounded-full flex items-center justify-center shadow-sm border-2 border-white ${status.glowColor}`} style={{
              boxShadow: '0 2px 4px rgba(0,0,0,0.2)' // Enhanced shadow
            }} aria-label={`Status: ${status.label}`}>
                    <div className={`w-1.5 h-1.5 rounded-full bg-white animate-pulse opacity-80`}></div>
                  </div>
                </Tippy>
              </div>}
          </div>}
        {/* Subtle separator line for ultra-compact view */}
        <div className="w-full h-[1px] my-1 z-10" style={{
        background: status.grayOutOverlay ? 'rgba(180, 40, 60, 0.12)' : specialtyColor.darkText ? 'rgba(0,0,0,0.08)' // Darker line for lighter colors
        : 'rgba(255,255,255,0.15)',
        opacity: 0.8,
        boxShadow: '0 1px 0 rgba(255,255,255,0.3)' // Shadow for embossed effect
      }}></div>
        {/* Staff name - ALWAYS VISIBLE (Tier 1) */}
        {config.showName && <div className={`font-bold text-xs whitespace-nowrap overflow-hidden text-ellipsis text-center px-0.5 ${getTransitionClass()}`} style={{
        color: status.grayOutOverlay ? 'rgba(70, 77, 95, 0.95)' // Darker desaturated text for busy status
        : 'rgba(50, 57, 75, 0.95)',
        maxWidth: '100%',
        textShadow: '0px 1px 0px rgba(255,255,255,0.5)' // Text shadow for etched effect
      }}>
            {staff.name}
          </div>}
        {/* Turn Count - ALWAYS VISIBLE (Tier 1) - ENHANCED EMPHASIS */}
        {config.showTurnCount && <Tippy content={`Turn Count: ${staff.turnCount ?? staff.count}`}>
            <div className="flex items-center justify-center mt-0.5" aria-label={`Turn count: ${staff.turnCount ?? staff.count}`} style={{
          textShadow: '0px 1px 0px rgba(255,255,255,0.5)' // Text shadow for etched effect
        }}>
              <span className="text-[10px] font-semibold mr-0.5 text-gray-700">
                T:
              </span>
              <span className="text-[10px] font-extrabold" style={{
            color: status.grayOutOverlay ? 'rgba(60, 67, 80, 0.95)' : 'rgba(40, 47, 60, 0.95)',
            letterSpacing: '-0.01em'
          }}>
                {staff.turnCount ?? staff.count}
              </span>
            </div>
          </Tippy>}
        {/* More Options Button - positioned at middle right */}
        <button className="absolute top-1/2 right-2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700 transition-all duration-300 p-1 flex-shrink-0 z-30" aria-label="More options for staff member">
          <MoreVertical size={14} strokeWidth={2} />
        </button>
        {/* Hover/active/drag state styling */}
        <style jsx>{`
          .group {
            transform-origin: center center;
            transform: translateZ(0);
            backface-visibility: hidden;
            will-change: transform, box-shadow;
          }
          .group:hover {
            transform: translateY(-2px);
            box-shadow:
              0 5px 10px rgba(0, 0, 0, 0.12),
              0 3px 6px rgba(0, 0, 0, 0.08);
          }
          .group:active {
            transform: translateY(1px);
            box-shadow: 0 2px 3px rgba(0, 0, 0, 0.15);
            cursor: grabbing;
          }
          .group:focus-visible {
            outline: none;
            box-shadow: 0 0 0 3px rgba(0, 180, 255, 0.35);
          }
        `}</style>
      </div>;
  }
  // NORMAL VIEW - Full card with all information
  return <div ref={cardRef} className={`group flex flex-col w-full ${isSelected ? 'ring-2 ring-offset-1 ring-blue-500' : ''} ${getTransitionClass()}`} style={{
    borderRadius: '16px',
    boxShadow: status.grayOutOverlay ? '0 4px 8px rgba(225, 29, 72, 0.2), 0 3px 6px rgba(0, 0, 0, 0.15), 0 0 0 1px rgba(225, 29, 72, 0.1) inset' // Enhanced shadow for busy
    : '0 3px 6px rgba(0,0,0,0.1), 0 1px 3px rgba(0,0,0,0.08)',
    border: status.grayOutOverlay ? `2px solid ${specialtyColor.darkBorderColor}` // Darker border for busy
    : `2px solid ${specialtyColor.darkBorderColor}`,
    transition: 'all 0.25s cubic-bezier(0.2, 0, 0, 1)',
    position: 'relative',
    overflow: 'hidden',
    transformStyle: 'preserve-3d',
    cursor: isDraggable ? 'grab' : 'pointer',
    minHeight: '180px',
    filter: status.grayOutOverlay ? 'contrast(1.05)' // Slightly increase contrast to improve readability
    : 'none'
  }} tabIndex={0} role="button" aria-label={`${staff.name}, ${status.label}, Queue position: ${staff.count}`}>
      {/* Semi-circle notch at top border - INCREASED SIZE with added outline and sharper edges */}
      <div className="absolute top-0 left-1/2 w-7 h-4 bg-white z-20" style={{
      transform: 'translate(-50%, -50%)',
      borderRadius: '0 0 7px 7px',
      borderTop: 'none',
      borderLeft: `1px solid ${specialtyColor.darkBorderColor}`,
      borderRight: `1px solid ${specialtyColor.darkBorderColor}`,
      borderBottom: `1px solid ${specialtyColor.darkBorderColor}`,
      boxShadow: '0 2px 3px rgba(0,0,0,0.1)' // Enhanced shadow
    }}></div>
      {/* Metallic gradient background */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-0 left-0 right-0 h-[60%] rounded-t-[14px]" style={{
        background: status.grayOutOverlay ? `linear-gradient(to bottom, ${specialtyColor.metalGradientFromDark}, ${specialtyColor.metalGradientToDark})` : `linear-gradient(to bottom, ${specialtyColor.metalGradientFrom}, ${specialtyColor.metalGradientTo})`,
        opacity: 0.9
      }}></div>
        <div className="absolute bottom-0 left-0 right-0 h-[40%] rounded-b-[14px]" style={{
        background: status.grayOutOverlay ? `linear-gradient(to bottom, ${specialtyColor.metalGradientFromDark}, ${specialtyColor.metalGradientToDark})` : `linear-gradient(to bottom, ${specialtyColor.metalGradientFrom}, ${specialtyColor.metalGradientTo})`,
        opacity: 0.95
      }}></div>
      </div>
      {/* Inner shadow/bevel effect */}
      <div className="absolute inset-0 z-0 rounded-[14px] pointer-events-none" style={{
      boxShadow: 'inset 0 1px 3px rgba(255,255,255,0.6), inset 0 -1px 3px rgba(0,0,0,0.15)'
    }}></div>
      {/* Enhanced overlay for busy status */}
      {status.grayOutOverlay && <>
          {/* Darker overlay (20-25% opacity) for busy status */}
          <div className="absolute inset-0 z-10 pointer-events-none" style={{
        backgroundColor: 'rgba(30, 30, 40, 0.25)',
        mixBlendMode: 'multiply',
        borderRadius: '14px'
      }}></div>
          {/* Secondary overlay to maintain specialty color visibility */}
          <div className="absolute inset-0 z-10 pointer-events-none" style={{
        backgroundColor: 'rgba(180, 40, 60, 0.1)',
        mixBlendMode: 'color',
        borderRadius: '14px'
      }}></div>
          {/* Enhanced busy indicator with icon - SOLID RED BACKGROUND */}
          <div className="absolute top-0 right-0 px-4 py-1.5 bg-rose-600 z-40 pointer-events-none shadow-md flex items-center justify-center" style={{
        borderRadius: '0 14px 0 10px',
        boxShadow: '0 3px 5px rgba(225, 29, 72, 0.3)',
        minWidth: '80px'
      }}>
            <CircleDot size={12} className="mr-1.5 text-white animate-pulse" strokeWidth={2.5} />
            <span className="text-xs font-bold text-white uppercase tracking-wider">
              Busy
            </span>
          </div>
        </>}
      {isDraggable && <div className="absolute top-3 left-3 opacity-0 group-hover:opacity-80 cursor-grab active:cursor-grabbing z-30 transition-opacity">
          <GripVertical size={18} className={`${status.grayOutOverlay ? 'text-gray-300' : 'text-gray-600'}`} strokeWidth={2} />
        </div>}
      {/* More Options Button - positioned at middle right */}
      <button className={`absolute top-1/2 right-2 transform -translate-y-1/2 ${status.grayOutOverlay ? 'text-gray-300 hover:text-white hover:bg-gray-700/30' : 'text-gray-500 hover:text-gray-700 hover:bg-gray-100/80'} transition-all duration-300 p-1.5 rounded-full flex-shrink-0 z-30`} aria-label="More options for staff member">
        <MoreVertical size={viewMode === 'ultra-compact' ? 12 : 14} strokeWidth={2} />
      </button>
      {/* Top section with staff info - 60% height */}
      <div className="relative z-10 p-4 h-[60%]">
        <div className="flex items-start">
          {/* Staff avatar with accent border */}
          {config.showAvatar && <div className="relative flex-shrink-0">
              <img src={staff.image} alt={`${staff.name} profile`} className={`rounded-full object-cover shadow-md relative z-10 transition-all duration-300 group-hover:brightness-105 ${getTransitionClass()} ${status.grayOutOverlay ? 'brightness-90' : ''}`} style={{
            width: '78px',
            height: '78px',
            boxShadow: '0 3px 6px rgba(0,0,0,0.15), 0 1px 3px rgba(0,0,0,0.1)',
            border: status.grayOutOverlay ? `3.5px solid ${specialtyColor.darkBorderColor}` : `4px solid ${specialtyColor.darkBorderColor}`,
            outline: '1px solid white'
          }} />
              {/* Queue Order Number - ALWAYS VISIBLE (Tier 1) */}
              {config.showQueueNumber && <div className="absolute -top-1 -left-1 z-20">
                  <Tippy content={`Queue Position: ${staff.count}`}>
                    <div className="bg-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold text-gray-700 border border-white shadow-md hover:bg-gray-50 transition-colors cursor-pointer" aria-label={`Queue position: ${staff.count}`} style={{
                boxShadow: '0 2px 4px rgba(0,0,0,0.15)' // Enhanced shadow
              }}>
                      {staff.count}
                    </div>
                  </Tippy>
                </div>}
            </div>}
          <div className="ml-4 flex-1 min-w-0 flex flex-col justify-center h-full">
            {/* Staff name - ALWAYS VISIBLE (Tier 1) */}
            {config.showName && <div className={`font-bold tracking-wide overflow-hidden text-ellipsis pr-1 mb-auto ${getTransitionClass()}`} style={{
            color: status.grayOutOverlay ? 'rgba(240, 240, 250, 0.95)' // Lighter text for better contrast on darkened background
            : 'rgba(40, 47, 60, 0.95)',
            fontSize: 'clamp(0.875rem, 3vw, 1.25rem)',
            fontWeight: '700',
            lineHeight: '1.2',
            letterSpacing: '0.01em',
            minWidth: '5ch',
            maxWidth: '100%',
            display: 'block',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
            textShadow: status.grayOutOverlay ? '0px 1px 1px rgba(0,0,0,0.2)' // Dark shadow for light text on dark background
            : '0px 1px 0px rgba(255,255,255,0.7)' // Light shadow for dark text on light background
          }}>
                {staff.name}
              </div>}
            {/* Status and time information */}
            <div className="flex flex-col space-y-1.5 mt-auto">
              {/* Status - ALWAYS VISIBLE (Tier 1) */}
              {config.showStatus && cardWidth >= 160 && <div className="flex items-center">
                  <Tippy content={`Status: ${status.label}`}>
                    {status.label !== 'Busy' ? <div className={`${status.bg} ${status.lightText} flex items-center px-2.5 py-1 rounded-full shadow-sm text-xs font-medium ${status.glowColor} ${getTransitionClass()}`} style={{
                  boxShadow: status.grayOutOverlay ? '0 2px 4px rgba(0,0,0,0.2)' : '0 2px 3px rgba(0,0,0,0.15)'
                }} aria-label={`Status: ${status.label}`}>
                        {status.icon}
                        {status.label}
                      </div> : <div className="h-6" aria-label="Status: Busy"></div>}
                  </Tippy>
                </div>}
              {/* Clocked in time - TIER 2 OPERATIONAL TIMING */}
              {config.showClockedInTime && cardWidth >= 180 && <div className={`text-xs ${status.grayOutOverlay ? 'text-gray-200' : 'text-gray-700'} flex items-center ${getTransitionClass()}`} style={{
              textShadow: status.grayOutOverlay ? '0px 1px 1px rgba(0,0,0,0.2)' // Dark shadow for light text
              : '0px 1px 0px rgba(255,255,255,0.5)' // Light shadow for dark text
            }}>
                  <Tippy content={`Clocked In: ${staff.time}`}>
                    <div className="flex items-center">
                      <ClassicIcons.ClockAnalog size={14} color={status.grayOutOverlay ? '#F1F5F9' : '#4B5563'} strokeWidth={2} className="mr-1.5 flex-shrink-0" />
                      <span className="font-medium">{staff.time}</span>
                    </div>
                  </Tippy>
                </div>}
            </div>
          </div>
        </div>
      </div>
      {/* Enhanced separation between header and data sections */}
      <div className="absolute inset-x-0 top-[60%] z-20">
        {/* Improved separator with conditional styling based on specialty color */}
        <div className="h-[1px] w-full" style={{
        background: status.grayOutOverlay ? 'rgba(255, 255, 255, 0.2)' // Lighter separator for better visibility on dark overlay
        : 'rgba(0, 0, 0, 0.12)' // Darker line for metal effect
      }}></div>
        <div className="h-[2px] w-full" style={{
        background: `linear-gradient(to bottom, 
              ${status.grayOutOverlay ? 'rgba(255, 255, 255, 0.15)' : 'rgba(255, 255, 255, 0.6)' // Lighter gradient for metallic highlight
        }, 
              transparent)`,
        boxShadow: '0 1px 2px rgba(0,0,0,0.05)' // Shadow for embossed effect
      }}></div>
      </div>
      {/* Data section with metrics */}
      <div className={`relative z-10 h-[40%] flex flex-col justify-center p-3 ${getTransitionClass()}`} style={{
      borderBottomLeftRadius: '14px',
      borderBottomRightRadius: '14px'
    }}>
        {/* METRICS ROW */}
        <div className="flex justify-between items-center mb-3">
          <div className={`grid ${cardWidth < 160 ? 'grid-cols-2' : 'grid-cols-3'} gap-2.5 w-full`}>
            {/* Turn count - ALWAYS VISIBLE (Tier 1) - ENHANCED EMPHASIS */}
            {config.showTurnCount && <Tippy content={`Turn Count: ${staff.turnCount ?? staff.count ?? 0}`}>
                <div className="flex flex-col items-center justify-center" aria-label={`Turn count: ${staff.turnCount ?? staff.count ?? 0}`}>
                  <div className="font-bold text-lg leading-none mb-0.5" style={{
                color: status.grayOutOverlay ? 'rgba(240, 240, 250, 0.95)' // Lighter text for better contrast
                : 'rgba(40, 47, 60, 0.95)',
                fontWeight: '800',
                letterSpacing: '-0.01em',
                textShadow: status.grayOutOverlay ? '0px 1px 1px rgba(0,0,0,0.2)' // Dark shadow for light text
                : '0px 1px 0px rgba(255,255,255,0.5)' // Light shadow for dark text
              }}>
                    {staff.turnCount ?? staff.count ?? 0}
                  </div>
                  <div className={`${status.grayOutOverlay ? 'text-gray-300' : 'text-gray-600'} text-xs font-semibold flex items-center leading-none`} style={{
                textShadow: status.grayOutOverlay ? '0px 1px 1px rgba(0,0,0,0.2)' // Dark shadow for light text
                : '0px 1px 0px rgba(255,255,255,0.5)' // Light shadow for dark text
              }}>
                    <ClassicIcons.RepeatArrows size={10} color={status.grayOutOverlay ? '#E2E8F0' : '#4B5563'} className="mr-0.5" strokeWidth={2.5} // Slightly thicker icon
                />
                    <span>Turns</span>
                  </div>
                </div>
              </Tippy>}
            {/* Tickets serviced - TIER 3 PERFORMANCE METRIC */}
            {config.showTickets && cardWidth >= 180 && <Tippy content={`Tickets: ${staff.ticketsServicedCount ?? staff.count ?? 0}`}>
                <div className="flex flex-col items-center justify-center" aria-label={`Tickets: ${staff.ticketsServicedCount ?? staff.count ?? 0}`}>
                  <div className="font-semibold text-sm leading-none mb-0.5" style={{
                color: status.grayOutOverlay ? 'rgba(240, 240, 250, 0.95)' // Lighter text for better contrast
                : 'rgba(40, 47, 60, 0.95)',
                textShadow: status.grayOutOverlay ? '0px 1px 1px rgba(0,0,0,0.2)' // Dark shadow for light text
                : '0px 1px 0px rgba(255,255,255,0.5)' // Light shadow for dark text
              }}>
                    {staff.ticketsServicedCount ?? staff.count ?? 0}
                  </div>
                  <div className={`${status.grayOutOverlay ? 'text-gray-300' : 'text-gray-600'} text-xs font-medium flex items-center leading-none`} style={{
                textShadow: status.grayOutOverlay ? '0px 1px 1px rgba(0,0,0,0.2)' // Dark shadow for light text
                : '0px 1px 0px rgba(255,255,255,0.5)' // Light shadow for dark text
              }}>
                    <ClassicIcons.TicketStubClassic size={9} color={status.grayOutOverlay ? '#E2E8F0' : '#4B5563'} className="mr-0.5" strokeWidth={2} />
                    <span>Tix</span>
                  </div>
                </div>
              </Tippy>}
            {/* Sales amount - TIER 3 PERFORMANCE METRIC (higher priority than Tickets) */}
            {config.showSalesAmount && cardWidth >= 160 && <Tippy content={`Total Serviced: ${formatCurrency(staff.totalSalesAmount ?? staff.revenue?.amount ?? 0)}`}>
                <div className="flex flex-col items-center justify-center" aria-label={`Total serviced: ${formatCurrency(staff.totalSalesAmount ?? staff.revenue?.amount ?? 0)}`}>
                  <div className="font-semibold text-sm leading-none mb-0.5" style={{
                color: status.grayOutOverlay ? 'rgba(240, 240, 250, 0.95)' // Lighter text for better contrast
                : 'rgba(40, 47, 60, 0.95)',
                textShadow: status.grayOutOverlay ? '0px 1px 1px rgba(0,0,0,0.2)' // Dark shadow for light text
                : '0px 1px 0px rgba(255,255,255,0.5)' // Light shadow for dark text
              }}>
                    {formatCurrency(staff.totalSalesAmount ?? staff.revenue?.amount ?? 0).replace('$', '')}
                  </div>
                  <div className={`${status.grayOutOverlay ? 'text-gray-300' : 'text-gray-600'} text-xs font-medium flex items-center justify-center leading-none`} style={{
                textShadow: status.grayOutOverlay ? '0px 1px 1px rgba(0,0,0,0.2)' // Dark shadow for light text
                : '0px 1px 0px rgba(255,255,255,0.5)' // Light shadow for dark text
              }}>
                    <span>$</span>
                  </div>
                </div>
              </Tippy>}
          </div>
        </div>
        {/* TIMELINE ROW - Next appointment and Last service */}
        <div className={`flex ${config.showLastService && staff.lastServiceTime && cardWidth >= 240 && config.showNextAppointment && staff.nextAppointmentTime && cardWidth >= 200 ? 'justify-between' : 'justify-center'} items-center gap-1.5`}>
          {/* Last Service - TIER 4 CONTEXT/UTILITY (lowest priority) */}
          {config.showLastService && staff.lastServiceTime && cardWidth >= 240 && <Tippy content={`Last Service Done At: ${staff.lastServiceTime}${staff.lastServiceAgo ? ` (${staff.lastServiceAgo})` : ''}`}>
                <button className={`flex items-center ${status.grayOutOverlay ? 'bg-amber-800/40 text-amber-100' : 'bg-amber-50 text-amber-700'} hover:bg-amber-100 text-xs font-medium px-2.5 py-1 rounded-full shadow-sm transition-colors duration-200`} aria-label={`Last service at ${staff.lastServiceTime}${staff.lastServiceAgo ? ` (${staff.lastServiceAgo})` : ''}`} style={{
            boxShadow: '0 1px 3px rgba(0,0,0,0.1)' // Enhanced shadow
          }}>
                  <ClassicIcons.ClockAnalog size={10} color={status.grayOutOverlay ? '#FBBF24' : '#B45309'} className="mr-1" strokeWidth={2} />
                  <span className="truncate">
                    Last: {formatTime(staff.lastServiceTime)}
                    {staff.lastServiceAgo &&
              // Only show the duration when it's the only timestamp visible
              !(config.showNextAppointment && staff.nextAppointmentTime && cardWidth >= 200) && <span className={`ml-1 ${status.grayOutOverlay ? 'text-amber-200' : 'text-amber-800'} font-medium`}>
                          ({staff.lastServiceAgo})
                        </span>}
                  </span>
                </button>
              </Tippy>}
          {/* Next Appointment - TIER 2 OPERATIONAL TIMING */}
          {config.showNextAppointment && staff.nextAppointmentTime && cardWidth >= 200 && <Tippy content={`Next Appointment: ${staff.nextAppointmentTime}${staff.nextAppointmentEta ? ` (${staff.nextAppointmentEta})` : ''}${staff.nextClientName ? ` - ${staff.nextClientName}` : ''}${staff.nextServiceType ? ` - ${staff.nextServiceType}` : ''}`}>
                <button className={`flex items-center ${status.grayOutOverlay ? 'bg-blue-900/40 text-blue-100' : 'bg-blue-50 text-blue-700'} hover:bg-blue-100 text-xs font-medium px-2.5 py-1 rounded-full shadow-sm transition-colors duration-200`} aria-label={`Next appointment at ${staff.nextAppointmentTime}${staff.nextAppointmentEta ? ` (${staff.nextAppointmentEta})` : ''}${staff.nextClientName ? ` for ${staff.nextClientName}` : ''}${staff.nextServiceType ? ` - ${staff.nextServiceType}` : ''}`} style={{
            boxShadow: '0 1px 3px rgba(0,0,0,0.1)' // Enhanced shadow
          }}>
                  <ClassicIcons.NextAppointment size={10} color={status.grayOutOverlay ? '#60A5FA' : '#1E40AF'} className="mr-1" strokeWidth={2} />
                  <span className="truncate">
                    Next: {formatTime(staff.nextAppointmentTime)}
                    {staff.nextAppointmentEta &&
              // Only show the ETA when it's the only timestamp visible
              !(config.showLastService && staff.lastServiceTime && cardWidth >= 240) && <span className={`ml-1 ${status.grayOutOverlay ? 'text-blue-200' : 'text-blue-800'} font-medium`}>
                          (In {staff.nextAppointmentEta})
                        </span>}
                    {cardWidth >= 300 && <>
                        {staff.nextClientName && cardWidth >= 350 && <span className={`ml-1 ${status.grayOutOverlay ? 'text-blue-200' : 'text-blue-800'} font-semibold whitespace-nowrap`}>
                            • {staff.nextClientName}
                          </span>}
                        {staff.nextServiceType && cardWidth >= 420 && <span className={`ml-1 ${status.grayOutOverlay ? 'text-blue-200' : 'text-blue-700'} italic whitespace-nowrap`}>
                            • {staff.nextServiceType}
                          </span>}
                      </>}
                  </span>
                </button>
              </Tippy>}
        </div>
      </div>
      {/* Selected indicator */}
      {isSelected && <div className="absolute top-0 right-0 m-2 z-30"></div>}
      {/* Hover/active/drag state styling */}
      <style jsx>{`
        .group {
          transform-origin: center center;
          transform: translateZ(0);
          backface-visibility: hidden;
          will-change: transform, box-shadow;
        }
        .group:hover {
          transform: translateY(-3px);
          box-shadow:
            0 8px 16px rgba(0, 0, 0, 0.12),
            0 4px 8px rgba(0, 0, 0, 0.08);
        }
        .group:active {
          transform: translateY(1px);
          box-shadow: 0 2px 4px rgba(0, 0, 0, 0.15);
          cursor: grabbing;
        }
        .group:focus-visible {
          outline: none;
          box-shadow: 0 0 0 3px rgba(0, 180, 255, 0.35);
        }
      `}</style>
    </div>;
}