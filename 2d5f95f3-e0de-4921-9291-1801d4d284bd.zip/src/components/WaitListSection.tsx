import React, { useEffect, useState, useRef } from 'react';
import { ServiceCard } from './ServiceCard';
import { Minimize2, Maximize2, Clock, LayoutGrid, Layers, MoreVertical, Check, Calendar, User, Tag, List, Grid, PlusCircle, ChevronDown, ChevronUp, ChevronRight } from 'lucide-react';
interface WaitListSectionProps {
  isMinimized?: boolean;
  onToggleMinimize?: () => void;
  isMobile?: boolean;
  viewMode?: 'grid' | 'list';
  setViewMode?: (mode: 'grid' | 'list') => void;
  cardViewMode?: 'normal' | 'compact';
  setCardViewMode?: (mode: 'normal' | 'compact') => void;
  minimizedLineView?: boolean;
  setMinimizedLineView?: (minimized: boolean) => void;
  isCombinedView?: boolean;
  hideHeader?: boolean;
}
export function WaitListSection({
  isMinimized = false,
  onToggleMinimize,
  isMobile = false,
  viewMode: externalViewMode,
  setViewMode: externalSetViewMode,
  cardViewMode: externalCardViewMode,
  setCardViewMode: externalSetCardViewMode,
  minimizedLineView: externalMinimizedLineView,
  setMinimizedLineView: externalSetMinimizedLineView,
  isCombinedView = false,
  hideHeader = false
}: WaitListSectionProps) {
  // Get view mode from localStorage, default to 'list'
  const [internalViewMode, setInternalViewMode] = useState<'grid' | 'list'>(() => {
    const saved = localStorage.getItem('waitListViewMode');
    return saved === 'grid' || saved === 'list' ? saved as 'grid' | 'list' : 'list';
  });
  const [activeTab, setActiveTab] = useState(() => {
    const saved = localStorage.getItem('waitListActiveTab');
    return saved || 'waitList';
  });
  // Add card view mode state (normal or compact)
  const [internalCardViewMode, setInternalCardViewMode] = useState<'normal' | 'compact'>(() => {
    const saved = localStorage.getItem('waitListCardViewMode');
    return saved === 'normal' || saved === 'compact' ? saved as 'normal' | 'compact' : 'normal';
  });
  // Add minimized line view state
  const [internalMinimizedLineView, setInternalMinimizedLineView] = useState<boolean>(() => {
    const saved = localStorage.getItem('waitListMinimizedLineView');
    return saved === 'true' ? true : false;
  });
  // Use either external or internal state based on isCombinedView
  const viewMode = isCombinedView && externalViewMode ? externalViewMode : internalViewMode;
  const setViewMode = (newMode: 'grid' | 'list') => {
    if (isCombinedView && externalSetViewMode) {
      externalSetViewMode(newMode);
    } else {
      setInternalViewMode(newMode);
      localStorage.setItem('waitListViewMode', newMode);
    }
  };
  const cardViewMode = isCombinedView && externalCardViewMode ? externalCardViewMode : internalCardViewMode;
  const setCardViewMode = (newMode: 'normal' | 'compact') => {
    if (isCombinedView && externalSetCardViewMode) {
      externalSetCardViewMode(newMode);
    } else {
      setInternalCardViewMode(newMode);
      localStorage.setItem('waitListCardViewMode', newMode);
    }
  };
  const minimizedLineView = isCombinedView && externalMinimizedLineView !== undefined ? externalMinimizedLineView : internalMinimizedLineView;
  const setMinimizedLineView = (newValue: boolean) => {
    if (isCombinedView && externalSetMinimizedLineView) {
      externalSetMinimizedLineView(newValue);
    } else {
      setInternalMinimizedLineView(newValue);
      localStorage.setItem('waitListMinimizedLineView', newValue.toString());
    }
  };
  // State for dropdown menu
  const [showDropdown, setShowDropdown] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  // New state for list type dropdown
  const [showListTypeDropdown, setShowListTypeDropdown] = useState(false);
  const listTypeDropdownRef = useRef<HTMLDivElement>(null);
  // Save active tab to localStorage when it changes
  useEffect(() => {
    localStorage.setItem('waitListActiveTab', activeTab);
  }, [activeTab]);
  // Close dropdowns when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setShowDropdown(false);
      }
      if (listTypeDropdownRef.current && !listTypeDropdownRef.current.contains(event.target as Node)) {
        setShowListTypeDropdown(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
  // Toggle between normal and compact card view
  const toggleCardViewMode = () => {
    const newMode = cardViewMode === 'normal' ? 'compact' : 'normal';
    setCardViewMode(newMode);
  };
  // Toggle minimized line view
  const toggleMinimizedLineView = () => {
    const newValue = !minimizedLineView;
    setMinimizedLineView(newValue);
  };
  // Get the appropriate view mode label
  const getViewModeLabel = () => {
    if (cardViewMode === 'normal') {
      return 'Switch to compact view';
    } else {
      return 'Switch to normal view';
    }
  };
  // Get the appropriate view mode icon
  const getViewModeIcon = () => {
    if (cardViewMode === 'normal') {
      return <LayoutGrid size={16} />;
    } else {
      return <Layers size={16} />;
    }
  };
  const waitlist = [{
    id: 1,
    number: 1,
    clientName: 'Tim Tim GUEST',
    clientType: 'Reward',
    time: '05:30',
    duration: '38m',
    service: 'SIGNATURE MANICURE',
    technician: '',
    techColor: '',
    isWaiting: true
  }, {
    id: 2,
    number: 4,
    clientName: 'AKEY G3',
    clientType: 'Reward',
    time: '05:31',
    duration: '37m',
    service: 'SIGNATURE MANICURE',
    technician: '',
    techColor: '',
    isWaiting: true
  }];
  const tabs = [{
    id: 'waitList',
    label: 'Wait List',
    count: 2
  }, {
    id: 'walkIn',
    label: 'Walk-In',
    count: 2
  }, {
    id: 'appt',
    label: 'Appt',
    count: 0
  }];
  // Enhanced color mappings for more vibrant tech colors
  const techColorMap: Record<string, string> = {
    'bg-[#E5565B]': 'bg-gradient-to-r from-[#FF6B70] to-[#E04146]',
    'bg-[#3F83F8]': 'bg-gradient-to-r from-[#5A9FFF] to-[#3373E8]',
    'bg-[#4CC2A9]': 'bg-gradient-to-r from-[#5EEAD4] to-[#3BB09A]',
    'bg-[#9B5DE5]': 'bg-gradient-to-r from-[#AF6FFF] to-[#8A4AD0]',
    'bg-[#3C78D8]': 'bg-gradient-to-r from-[#4A8EFF] to-[#2A68C8]',
    'bg-white': 'bg-gradient-to-r from-gray-100 to-white text-gray-700'
  };
  // Get active tab label and count
  const getActiveTabInfo = () => {
    const activeTabInfo = tabs.find(tab => tab.id === activeTab);
    return activeTabInfo || tabs[0];
  };
  // Render list view item with bolder paper ticket styling
  const WaitListItem = ({
    service
  }: {
    service: (typeof waitlist)[0];
  }) => {
    return <div className="bg-[#FFF8E8] rounded-lg border-2 border-[#00D0E0]/30 hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1 hover:rotate-[0.2deg] mb-2 relative overflow-hidden group shadow-md" style={{
      backgroundImage: 'url("https://www.transparenttextures.com/patterns/paper-fibers.png")'
    }}>
        {/* Perforation marks - top */}
        <div className="absolute top-0 left-0 w-full h-[6px] overflow-hidden flex items-center">
          <div className="w-full flex justify-between px-4">
            {[...Array(20)].map((_, i) => <div key={i} className="w-1 h-1 bg-[#00D0E0]/30 rounded-full"></div>)}
          </div>
        </div>
        {/* Left ticket notch */}
        <div className="absolute -left-2 top-1/2 w-4 h-4 bg-gray-100 rounded-full border-r-2 border-[#00D0E0]/30"></div>
        {/* Right ticket notch */}
        <div className="absolute -right-2 top-1/2 w-4 h-4 bg-gray-100 rounded-full border-l-2 border-[#00D0E0]/30"></div>
        {/* Status indicator strip */}
        <div className="absolute top-0 left-0 w-2 h-full bg-gradient-to-b from-[#00D0E0] to-[#00A0B0]"></div>
        <div className="flex flex-wrap sm:flex-nowrap items-center p-2 sm:p-3 pl-4 pt-3">
          {/* Left section - Number & Client */}
          <div className="w-[32px] h-[32px] sm:w-[40px] sm:h-[40px] bg-gray-800 text-white rounded-full flex items-center justify-center text-xs sm:text-sm font-bold shadow-lg mr-2 sm:mr-3 flex-shrink-0 transform -rotate-3 ring-2 ring-[#00D0E0]/30">
            {service.number}
          </div>
          <div className="flex flex-col min-w-0 flex-grow pr-2">
            <div className="font-bold text-gray-800 flex items-center flex-wrap">
              <span className="truncate mr-2 text-sm sm:text-base max-w-[120px] sm:max-w-full font-mono">
                {service.clientName}
              </span>
              <span className="text-[10px] sm:text-xs bg-[#00D0E0]/20 text-[#00A0B0] font-bold px-1.5 sm:px-2 py-0.5 rounded-md shadow-sm mt-0.5 sm:mt-0 border border-[#00D0E0]/30 uppercase tracking-wide">
                {service.clientType}
              </span>
            </div>
            <div className="flex items-center mt-0.5 sm:mt-1 text-[10px] sm:text-xs text-gray-700 font-mono font-semibold">
              <div className="flex items-center mr-2 sm:mr-3">
                <Calendar size={10} className="text-[#00A0B0] mr-0.5 sm:mr-1" />
                <span>{service.time}</span>
              </div>
              <div className="flex items-center">
                <Clock size={10} className="text-[#00A0B0] mr-0.5 sm:mr-1" />
                <span>{service.duration}</span>
              </div>
            </div>
          </div>
          {/* Middle section - Service */}
          <div className="hidden sm:flex flex-grow items-center mx-3 max-w-[30%] bg-[#FFF8E8] px-2 py-1 rounded border-l-2 border-[#00D0E0]/30 shadow-sm">
            <Tag size={14} className="text-[#00A0B0] mr-1.5 flex-shrink-0" />
            <span className="text-sm text-gray-800 truncate font-mono font-semibold">
              {service.service}
            </span>
          </div>
          {/* Service for small screens */}
          <div className="sm:hidden text-[10px] text-gray-800 bg-[#00D0E0]/10 px-1.5 py-0.5 rounded-sm mt-1 mb-1 w-full truncate border-l-2 border-[#00D0E0]/30 font-semibold">
            <Tag size={10} className="text-[#00A0B0] mr-1 inline-block" />
            <span className="font-mono">{service.service}</span>
          </div>
          {/* Right section - Status */}
          <div className="text-gray-800 text-[10px] sm:text-xs font-bold bg-[#5EEAD4]/30 px-2 sm:px-3 py-1 sm:py-1.5 rounded-full border-2 border-[#5EEAD4]/40 shadow-md ml-auto mr-1 sm:mr-2 flex-shrink-0" style={{
          clipPath: 'polygon(4% 0%, 100% 0%, 96% 100%, 0% 100%)',
          paddingLeft: '10px',
          paddingRight: '10px'
        }}>
            NEXT AVAILABLE
          </div>
          {/* Actions */}
          <div className="flex items-center flex-shrink-0">
            {/* Add button */}
            <button className="p-1 sm:p-1.5 rounded-full text-[#00A0B0] hover:text-[#008090] hover:bg-[#00D0E0]/20 transition-colors mr-1 shadow-sm border border-[#00D0E0]/30" aria-label="Assign technician">
              <PlusCircle size={16} className="sm:hidden" />
              <PlusCircle size={18} className="hidden sm:block" />
            </button>
            <button className="text-gray-500 hover:text-gray-700 p-1 sm:p-1.5 rounded-full hover:bg-[#00D0E0]/10 transition-colors shadow-sm">
              <MoreVertical size={14} className="sm:hidden" />
              <MoreVertical size={16} className="hidden sm:block" />
            </button>
          </div>
        </div>
        {/* Paper texture overlay */}
        <div className="absolute inset-0 pointer-events-none opacity-10 mix-blend-overlay" style={{
        backgroundImage: 'url("https://www.transparenttextures.com/patterns/cardboard.png")'
      }}></div>
      </div>;
  };
  // Render minimized list view item with bolder paper ticket styling
  const MinimizedWaitListItem = ({
    service
  }: {
    service: (typeof waitlist)[0];
  }) => {
    return <div className="bg-[#FFF8E8] rounded-lg border-2 border-[#00D0E0]/30 hover:shadow-lg transition-all duration-300 transform hover:-translate-y-0.5 hover:rotate-[0.2deg] mb-2 relative overflow-hidden shadow-md" style={{
      backgroundImage: 'url("https://www.transparenttextures.com/patterns/paper-fibers.png")'
    }}>
        {/* Left notch */}
        <div className="absolute -left-2 top-1/2 w-4 h-4 bg-gray-100 rounded-full border-r-2 border-[#00D0E0]/30"></div>
        {/* Right notch */}
        <div className="absolute -right-2 top-1/2 w-4 h-4 bg-gray-100 rounded-full border-l-2 border-[#00D0E0]/30"></div>
        {/* Status indicator strip */}
        <div className="absolute top-0 left-0 w-2 h-full bg-gradient-to-b from-[#00D0E0] to-[#00A0B0]"></div>
        <div className="flex items-center p-2 pl-4">
          {/* Number & Client */}
          <div className="w-[28px] h-[28px] bg-gray-800 text-white rounded-full flex items-center justify-center text-xs font-bold shadow-lg mr-2 flex-shrink-0 transform -rotate-3 ring-1 ring-[#00D0E0]/30">
            {service.number}
          </div>
          <div className="flex flex-col min-w-0 flex-grow">
            <div className="flex items-center">
              <span className="truncate text-xs font-bold text-gray-800 mr-1.5 max-w-[100px] font-mono">
                {service.clientName}
              </span>
              <span className="text-[9px] bg-[#00D0E0]/20 text-[#00A0B0] px-1 py-0.5 rounded-sm border border-[#00D0E0]/30 font-bold uppercase">
                {service.clientType}
              </span>
            </div>
            <div className="flex items-center mt-0.5">
              <Tag size={9} className="text-[#00A0B0] mr-1 flex-shrink-0" />
              <span className="text-[9px] text-gray-700 truncate max-w-[120px] font-mono font-semibold">
                {service.service}
              </span>
            </div>
          </div>
          {/* Status */}
          <div className="text-gray-800 text-[9px] font-bold bg-[#5EEAD4]/30 px-1.5 py-0.5 rounded-full border-2 border-[#5EEAD4]/40 shadow-md ml-auto mr-1 flex-shrink-0" style={{
          clipPath: 'polygon(4% 0%, 100% 0%, 96% 100%, 0% 100%)',
          paddingLeft: '8px',
          paddingRight: '8px'
        }}>
            NEXT
          </div>
          {/* Add button */}
          <button className="p-1 rounded-full text-[#00A0B0] hover:text-[#008090] hover:bg-[#00D0E0]/20 transition-colors flex-shrink-0 shadow-sm border border-[#00D0E0]/30" aria-label="Assign technician">
            <PlusCircle size={14} />
          </button>
        </div>
        {/* Paper texture overlay */}
        <div className="absolute inset-0 pointer-events-none opacity-10 mix-blend-overlay" style={{
        backgroundImage: 'url("https://www.transparenttextures.com/patterns/cardboard.png")'
      }}></div>
      </div>;
  };
  // Render minimized list item with bolder paper ticket styling
  const MinimizedWaitListItem2 = ({
    service
  }: {
    service: (typeof waitlist)[0];
  }) => {
    return <div className="flex items-center bg-[#FFF8E8] rounded-lg border-2 border-[#00D0E0]/30 p-2 mb-1.5 hover:shadow-md transition-all transform hover:-translate-y-0.5 hover:rotate-[0.2deg] relative overflow-hidden" style={{
      backgroundImage: 'url("https://www.transparenttextures.com/patterns/paper-fibers.png")'
    }}>
        <div className="bg-gray-800 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold transform -rotate-3 ring-1 ring-[#00D0E0]/30 shadow-sm">
          {service.number}
        </div>
        <span className="ml-2 text-xs font-bold text-gray-800 truncate max-w-[100px] font-mono">
          {service.clientName}
        </span>
        <div className="ml-auto text-[10px] font-bold bg-[#5EEAD4]/30 text-gray-800 px-1.5 py-0.5 rounded-full border-2 border-[#5EEAD4]/40 shadow-sm" style={{
        clipPath: 'polygon(4% 0%, 100% 0%, 96% 100%, 0% 100%)',
        paddingLeft: '8px',
        paddingRight: '8px'
      }}>
          NEXT
        </div>
        {/* Paper texture overlay */}
        <div className="absolute inset-0 pointer-events-none opacity-10 mix-blend-overlay" style={{
        backgroundImage: 'url("https://www.transparenttextures.com/patterns/cardboard.png")'
      }}></div>
      </div>;
  };
  if (isMinimized) {
    return <div className="bg-white rounded-lg shadow-md border border-gray-200 flex flex-col overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:justify-between border-b border-gray-200 bg-white">
          <div className="flex overflow-x-auto no-scrollbar">
            {tabs.map(tab => <button key={tab.id} className={`flex items-center px-3 py-2.5 text-xs font-medium whitespace-nowrap ${activeTab === tab.id ? 'bg-gradient-to-r from-[#00D0E0] to-[#22A5C9] text-white shadow-md' : 'text-gray-500 hover:text-[#00D0E0]'}`} onClick={() => setActiveTab(tab.id)}>
                {tab.label}
                <span className={`ml-1.5 ${activeTab === tab.id ? 'bg-white text-[#00D0E0]' : 'bg-gray-100 text-gray-600'} text-xs px-1.5 py-0.5 rounded-full`}>
                  {tab.count}
                </span>
              </button>)}
          </div>
          <div className="flex space-x-1 px-3 py-1.5 border-t sm:border-t-0 border-gray-200 sm:border-gray-0">
            <button className="p-1.5 rounded-md text-gray-500 hover:text-[#00D0E0] hover:bg-gray-100 transition-all duration-200 transform hover:scale-105 active:scale-95 touch-manipulation" onClick={onToggleMinimize} aria-label="Expand section">
              <Maximize2 size={isMobile ? 20 : 16} />
            </button>
          </div>
        </div>
        {/* Minimized list view */}
        <div className="p-2 overflow-auto max-h-40">
          {waitlist.slice(0, 3).map(service => <MinimizedWaitListItem2 key={service.id} service={service} />)}
          {waitlist.length > 3 && <button className="w-full text-center text-xs text-gray-500 hover:text-gray-700 mt-1 py-1 touch-manipulation" onClick={onToggleMinimize}>
              + {waitlist.length - 3} more tickets
            </button>}
        </div>
      </div>;
  }
  return <div className="bg-white rounded-lg shadow-md border border-gray-200 flex flex-col overflow-hidden h-full">
      {/* Only show full section header when not in combined view or hideHeader is false */}
      {!hideHeader && <div className="flex flex-col sm:flex-row sm:justify-between border-b border-gray-200 bg-white sticky top-0 z-10">
          <div className="flex items-center">
            {/* List type dropdown */}
            <div className="relative" ref={listTypeDropdownRef}>
              <button className={`flex items-center px-3 py-2.5 text-xs font-medium whitespace-nowrap ${activeTab === 'waitList' ? 'bg-gradient-to-r from-[#00D0E0] to-[#22A5C9] text-white shadow-md' : 'text-gray-500 hover:text-[#00D0E0]'}`} onClick={() => setShowListTypeDropdown(!showListTypeDropdown)}>
                {getActiveTabInfo().label}
                <span className={`ml-1.5 ${activeTab === 'waitList' ? 'bg-white text-[#00D0E0]' : 'bg-gray-100 text-gray-600'} text-xs px-1.5 py-0.5 rounded-full`}>
                  {getActiveTabInfo().count}
                </span>
                <ChevronDown size={14} className="ml-1.5" />
              </button>
              {showListTypeDropdown && <div className="absolute left-0 mt-1 w-40 bg-white rounded-md shadow-lg z-20 border border-gray-200 py-1">
                  {tabs.map(tab => <button key={tab.id} className={`w-full text-left px-3 py-2 text-xs ${activeTab === tab.id ? 'bg-gray-50 text-[#00D0E0] font-medium' : 'text-gray-700 hover:bg-gray-50'} flex items-center`} onClick={() => {
              setActiveTab(tab.id);
              setShowListTypeDropdown(false);
            }}>
                      {tab.label}
                      <span className={`ml-1.5 ${activeTab === tab.id ? 'bg-[#00D0E0]/10 text-[#00D0E0]' : 'bg-gray-100 text-gray-600'} text-xs px-1.5 py-0.5 rounded-full`}>
                        {tab.count}
                      </span>
                      {activeTab === tab.id && <Check size={12} className="ml-auto text-[#00D0E0]" />}
                    </button>)}
                </div>}
            </div>
          </div>
          <div className="flex space-x-1 px-3 py-1.5 border-t sm:border-t-0 border-gray-200 sm:border-gray-0">
            {viewMode === 'list' && <button className="p-1.5 rounded-md text-gray-500 hover:text-[#00D0E0] hover:bg-gray-100 transition-all duration-200 transform hover:scale-105 active:scale-95" onClick={toggleMinimizedLineView} aria-label={minimizedLineView ? 'Expand line view' : 'Minimize line view'}>
                {minimizedLineView ? <ChevronDown size={16} /> : <ChevronUp size={16} />}
              </button>}
            {viewMode === 'grid' && <button className="p-1.5 rounded-md text-gray-500 hover:text-[#00D0E0] hover:bg-gray-100 transition-all duration-200 transform hover:scale-105 active:scale-95" onClick={toggleCardViewMode} aria-label={cardViewMode === 'compact' ? 'Expand card view' : 'Minimize card view'}>
                {cardViewMode === 'compact' ? <ChevronDown size={16} /> : <ChevronUp size={16} />}
              </button>}
            <button className="p-1.5 rounded-md text-gray-500 hover:text-[#00D0E0] hover:bg-gray-100 transition-all duration-200 transform hover:scale-105 active:scale-95" onClick={toggleCardViewMode} aria-label={getViewModeLabel()}>
              {getViewModeIcon()}
            </button>
            <div className="relative" ref={dropdownRef}>
              <button className="p-1.5 rounded-md text-gray-500 hover:text-[#00D0E0] hover:bg-gray-100 transition-all duration-200 transform hover:scale-105 active:scale-95" onClick={() => setShowDropdown(!showDropdown)} aria-label="More options">
                <MoreVertical size={16} />
              </button>
              {showDropdown && <div className="absolute right-0 mt-1 w-48 bg-white rounded-md shadow-lg z-10 border border-gray-200 py-1">
                  <div className="px-3 py-2 border-b border-gray-100 bg-gray-50">
                    <h3 className="text-sm font-medium text-gray-700">
                      View Options
                    </h3>
                  </div>
                  <button className="w-full text-left px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 flex items-center" onClick={() => setViewMode('list')}>
                    <List size={14} className="mr-2 text-gray-500" />
                    Line View
                    {viewMode === 'list' && <Check size={14} className="ml-auto text-gray-500" />}
                  </button>
                  <button className="w-full text-left px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 flex items-center" onClick={() => setViewMode('grid')}>
                    <Grid size={14} className="mr-2 text-gray-500" />
                    Grid View
                    {viewMode === 'grid' && <Check size={14} className="ml-auto text-gray-500" />}
                  </button>
                </div>}
            </div>
          </div>
        </div>}
      {/* Add view controls even when header is hidden in combined view */}
      {hideHeader && isCombinedView}
      {/* Mobile view: Only show dropdown */}
      {isMobile && !hideHeader && <div className="flex justify-between items-center border-b border-gray-200 bg-white px-3 py-2 h-11">
          <div className="relative" ref={listTypeDropdownRef}>
            <button className="flex items-center text-xs font-medium" onClick={() => setShowListTypeDropdown(!showListTypeDropdown)}>
              <span className={`font-medium ${activeTab === 'waitList' ? 'text-[#00D0E0]' : 'text-gray-700'}`}>
                {getActiveTabInfo().label}
              </span>
              <span className={`ml-1.5 ${activeTab === 'waitList' ? 'bg-[#00D0E0]/10 text-[#00D0E0]' : 'bg-gray-100 text-gray-600'} text-[11px] h-[18px] px-[6px] py-0 rounded-full inline-flex items-center justify-center`}>
                {getActiveTabInfo().count}
              </span>
              <ChevronDown size={14} className={`ml-1 ${activeTab === 'waitList' ? 'text-[#00D0E0]' : 'text-gray-500'}`} />
            </button>
            {showListTypeDropdown && <div className="absolute left-0 mt-1 w-40 bg-white rounded-md shadow-lg z-20 border border-gray-200 py-1">
                {tabs.map(tab => <button key={tab.id} className={`w-full text-left px-3 py-2 text-xs ${activeTab === tab.id ? 'bg-gray-50 text-[#00D0E0] font-medium' : 'text-gray-700 hover:bg-gray-50'} flex items-center`} onClick={() => {
            setActiveTab(tab.id);
            setShowListTypeDropdown(false);
          }}>
                    {tab.label}
                    <span className={`ml-1.5 ${activeTab === tab.id ? 'bg-[#00D0E0]/10 text-[#00D0E0]' : 'bg-gray-100 text-gray-600'} text-[11px] h-[18px] px-[6px] py-0 rounded-full inline-flex items-center justify-center`}>
                      {tab.count}
                    </span>
                    {activeTab === tab.id && <Check size={12} className="ml-auto text-[#00D0E0]" />}
                  </button>)}
              </div>}
          </div>
          <div className="flex space-x-2">
            {viewMode === 'list' && <button className="inline-flex items-center justify-center h-10 w-10 rounded-md text-gray-500 hover:text-[#00D0E0] hover:bg-gray-100 transition-all opacity-80 hover:opacity-100" onClick={toggleMinimizedLineView} aria-label={minimizedLineView ? 'Expand line view' : 'Minimize line view'}>
                {minimizedLineView ? <ChevronDown size={20} /> : <ChevronUp size={20} />}
              </button>}
            <button className="inline-flex items-center justify-center h-10 w-10 rounded-md text-gray-500 hover:text-[#00D0E0] hover:bg-gray-100 transition-all opacity-80 hover:opacity-100" onClick={() => setShowDropdown(!showDropdown)} aria-label="More options">
              <MoreVertical size={20} />
            </button>
          </div>
        </div>}
      <div className="flex-1 overflow-auto p-3">
        {viewMode === 'grid' ? <div className={`grid ${viewMode === 'grid' ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4' : 'grid-cols-1'} gap-3`}>
            {waitlist.map(service => <ServiceCard key={service.id} service={service} viewMode={cardViewMode} />)}
          </div> : <div className="space-y-2">
            {waitlist.map(service => minimizedLineView ? <MinimizedWaitListItem key={service.id} service={service} /> : <WaitListItem key={service.id} service={service} />)}
          </div>}
      </div>
    </div>;
}